"""Render the reviewed Markdown manuscripts; content is authored in the manuscripts."""
from pathlib import Path
import base64
import copy
import hashlib
import html
import json
import math
import re
import zipfile

import markdown
from bs4 import BeautifulSoup, NavigableString
from fontTools import subset
from fontTools.ttLib import TTFont
from fontTools.varLib.instancer import instantiateVariableFont

ROOT = Path(__file__).parent
DRAFT = ROOT / "讲稿修订_2026-10-23"
OUT = ROOT / "完整讲义"
ASSETS = DRAFT / "figures"
ASSETS.mkdir(exist_ok=True)
ORDERS = {
    1: list(range(1, 6)),
    2: [6, 7, 8, 9, 10, 11, 12, 15, 16, 13, 14, 17, 18],
    3: [19, 20, 21, 23, 24, 22, 25, 26, 27, 28, 29, 30],
    4: [31, 36, 32, 33, 34, 37, 38, 39, 35, 40],
    5: [44, 45, 41, 42, 43, 46, 47],
}
with zipfile.ZipFile(DRAFT / "修订前网页.zip") as archive:
    BASE = BeautifulSoup(archive.read("index.html"), "html.parser")
OLD = {int(s["id"][1:]): s for s in BASE.select("section[id^=u]")}


def bi(z, e):
    return (f'<span class="zh" lang="zh-CN">{html.escape(z)}</span>'
            f'<span class="en" lang="en">{html.escape(e)}</span>')


BLUE, RED, GREEN, INK = "#315b78", "#a54b3d", "#687f69", "#2a2620"


def text(x, y, label, color=INK, size=14):
    return f'<text x="{x}" y="{y}" fill="{color}" font-size="{size}" font-family="Arial,sans-serif">{html.escape(label)}</text>'


def line(x1, y1, x2, y2, color=INK, dash=""):
    return f'<line x1="{x1}" y1="{y1}" x2="{x2}" y2="{y2}" stroke="{color}" stroke-width="2" stroke-dasharray="{dash}"/>'


def svg(body, width=720, height=340):
    return f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {width} {height}" role="img">{body}</svg>'


def plot(origin, size, bounds, fn, color=BLUE, lo=None, hi=None):
    ox, oy = origin
    w, h = size
    a, b, c, d = bounds
    def point(x, y):
        return ox + (x-a)/(b-a)*w, oy+h-(y-c)/(d-c)*h
    points = []
    for i in range(201):
        x = (a if lo is None else lo) + ((b if hi is None else hi)-(a if lo is None else lo))*i/200
        y = fn(x)
        if c <= y <= d:
            points.append(",".join(f"{v:.2f}" for v in point(x, y)))
    return f'<polyline points="{" ".join(points)}" fill="none" stroke="{color}" stroke-width="2.5"/>', point


def axes(origin, size, bounds, xlabel="x", ylabel="f"):
    _, p = plot(origin, size, bounds, lambda x: bounds[2])
    x0, y0 = p(max(bounds[0], min(0, bounds[1])), max(bounds[2], min(0, bounds[3])))
    ox, oy = origin
    w, h = size
    return line(ox, y0, ox+w, y0)+line(x0, oy, x0, oy+h)+text(ox+w-12, y0+20, xlabel)+text(x0+8, oy+15, ylabel)


def flow(labels, bottom):
    b = ""
    for i, label in enumerate(labels):
        x = 15+i*178
        b += f'<rect x="{x}" y="55" width="150" height="100" rx="8" fill="none" stroke="{BLUE}" stroke-width="2"/>'
        for j, part in enumerate(label.split("|")):
            b += text(x+12, 88+j*25, part)
        if i < len(labels)-1:
            b += text(x+155, 112, "→", RED, 22)
    return svg(b+text(25, 205, bottom), 720, 240)


def custom_figure(uid, index):
    if uid == 1:
        bounds = (0, 4, 0, 6)
        b = axes((50, 25), (590, 265), bounds, "x1", "x2")
        _, p = plot((50,25),(590,265),bounds,lambda x: 0)
        poly = " ".join(",".join(map(str,p(x,y))) for x,y in [(0,4),(0,6),(4,6),(4,0),(2,0)])
        b += f'<polygon points="{poly}" fill="{GREEN}" opacity=".15"/>'
        for f,c in [(lambda x:4-2*x,BLUE),(lambda x:3-1.5*x,RED),(lambda x:4-1.5*x,GREEN)]:
            curve=plot((50,25),(590,265),bounds,f,c)[0]
            if c!=BLUE:curve=curve.replace("<polyline",'<polyline stroke-dasharray="6 4"')
            b += curve
        b += text(400,50,"2x1+x2 ≥ 4",BLUE)+text(80,170,"c=6",RED)+text(200,130,"c=8",GREEN)
        x,y=p(2,0)
        b += f'<circle cx="{x}" cy="{y}" r="5" fill="{RED}"/>'+text(x+8,y-12,"(2,0)")
        b += line(170,125,145,165,RED)+text(75,315,"lower c ↓    minimum cost = 6")
        return svg(b)
    if uid == 4:
        return flow(["p|lamp powers","I = Ap|brightness","u = I / Ides|positive ratios","R = max(u,1/u)|worst score"], "Known: A and Ides. Choose p. Best candidate: p=(2/3,2/3), R=1.")
    if uid == 5 and index == 1:
        bounds=(-2.4,2.4,-.2,4)
        b=axes((45,25),(620,255),bounds,"x","g")
        curve,p=plot((45,25),(620,255),bounds,lambda x:min((x+1)**2+1,(x-1)**2))
        b+=curve
        for x,y,label in [(-1,1,"local (-1,1)"),(1,0,"global (1,0)")]:
            a,c=p(x,y);b+=f'<circle cx="{a}" cy="{c}" r="5" fill="{RED}"/>'+text(a-30,c-14,label)
        return svg(b+text(50,320,"switch: x = -1/4"))
    if uid == 6:
        b='<defs>'+''.join(f'<marker id="vec-{n}" markerWidth="7" markerHeight="7" refX="6" refY="3" orient="auto"><path d="M0,0L6,3L0,6" fill="{c}"/></marker>' for n,c in [("blue",BLUE),("green",GREEN),("red",RED)])+'</defs>'
        b+=line(45,255,400,255)+line(45,255,45,30)
        b+=line(45,255,195,55,BLUE).replace("/>",' marker-end="url(#vec-blue)"/>')+text(200,50,"x=(3,4)",BLUE)
        b+=line(195,55,195,255,GREEN,"5 4")+text(200,275,"(3,0)")
        b+=line(45,295,195,295,RED)+text(70,320,"projection = 3",RED)
        b+=line(45,290,45,300,RED)+line(195,290,195,300,RED)
        b+=line(470,115,520,115,GREEN).replace("/>",' marker-end="url(#vec-green)"/>')+text(470,95,"y=(1,0)",GREEN)
        b+=line(520,205,470,205,RED).replace("/>",' marker-end="url(#vec-red)"/>')+text(440,240,"reverse y: score -3",RED)
        return svg(b)
    if uid == 14:
        b=""
        for j,(curv,slope,title) in enumerate([(2,4,"v=(1,0)"),(4,-4,"v=(1,-1)")]):
            o=(45+j*350,45);sz=(285,225);bd=(-.6,.6,2,12)
            b+=axes(o,sz,bd,"t","q")+text(o[0],25,title)
            b+=plot(o,sz,bd,lambda t:6+slope*t+curv*t*t/2,BLUE)[0]
            b+=plot(o,sz,bd,lambda t:6+slope*t,RED)[0]
        return svg(b+text(45,320,"blue: actual = quadratic prediction     red: linear prediction"))
    if uid == 17:
        return flow(["x in R³|three coordinates","Vᵀ = I3|input coordinates","Σ: 2×3|only 2 x1 survives","U = I2|output (2x1,0)"],"x2,x3 vanish; output component 2 is unreachable. Residual for b=(4,3): (0,-3).")
    if uid == 20:
        b=""
        for i,title in enumerate(["affine hull","convex hull","conic hull"]):
            ox=30+230*i;oy=45
            b+=text(ox,25,title)+line(ox,230,ox+190,230)+line(ox,230,ox,oy)
            if i==2:b+=f'<rect x="{ox}" y="{oy}" width="190" height="185" fill="{GREEN}" opacity=".15"/>'
            else:
                b+=line(ox if i==1 else ox-10,150 if i==1 else 140,ox+80 if i==1 else ox+170,230 if i==1 else 320,BLUE)
            for x,y in [(ox,150),(ox+80,230)]:b+=f'<circle cx="{x}" cy="{y}" r="4" fill="{RED}"/>'
            b+=text(ox,280,"(0,1), (1,0)")
        return svg(b,720,340)
    if uid == 23 and index == 1:
        b=text(40,25,"input R²")+text(470,25,"output R")
        b+=f'<rect x="100" y="50" width="140" height="210" fill="{GREEN}" opacity=".2"/>'
        b+=line(40,160,330,160)+line(170,35,170,280)
        b+=text(90,300,"-1 ≤ x1 ≤ 1; x2 free")
        b+=line(440,160,680,160)+line(490,160,625,160,BLUE)+text(485,190,"-1")+text(620,190,"1")
        for x in (490,625):b+=f'<circle cx="{x}" cy="160" r="4" fill="{BLUE}"/>'
        return svg(b+text(330,125,"A=(1,0)"))
    if uid == 26:
        b=axes((65,30),(570,250),(0,5,0,5),"cost","error")
        _,p=plot((65,30),(570,250),(0,5,0,5),lambda x:0)
        for x,y in [(1,4),(2,2),(4,1),(3,3)]:
            px,py=p(x,y);c=RED if (x,y)==(3,3) else BLUE
            b+=f'<circle cx="{px}" cy="{py}" r="5" fill="{c}"/>'+text(px+8,py-10,f"({x},{y})",c)
        return svg(b+text(65,320,"Only marked points are feasible. (2,2) dominates (3,3)."))
    if uid == 34:
        b=""
        bd=(-2.3,2.3,-.5,5)
        b+=axes((35,30),(300,210),bd,"x","f")
        _,p=plot((35,30),(300,210),bd,lambda x:0)
        coords=[p(-math.sqrt(5),5),p(math.sqrt(5),5)]
        coords += [p(math.sqrt(5)-2*math.sqrt(5)*i/100,(math.sqrt(5)-2*math.sqrt(5)*i/100)**2) for i in range(101)]
        b+=f'<polygon points="{" ".join(f"{x},{y}" for x,y in coords)}" fill="{GREEN}" opacity=".13"/>'
        b+=plot((35,30),(300,210),bd,lambda x:x*x)[0]
        for a,c in [(0,INK),(1,GREEN),(4,RED)]:
            x,y=p(-2.3,a);xx,_=p(2.3,a);b+=line(x,y,xx,y,c,"4 3")+text(40,y-5,f"α={a}",c)
        for i,(a,end,c) in enumerate([(0,0,INK),(1,1,GREEN),(4,2,RED)]):
            y=70+65*i;b+=line(400,y,690,y)+text(405,y-18,f"C{a}",c)
            x1=545-end*60;x2=545+end*60;b+=line(x1,y,x2,y,c)
            for x in [x1,x2]:b+=f'<circle cx="{x}" cy="{y}" r="4" fill="{c}"/>'
        b+=text(40,300,"epi f: all (x,t) above the curve")+text(400,300,"sublevel: x only")
        # An epigraph panel is stated separately; levels above are horizontal cuts.
        return svg(b)
    if uid == 38:
        bd=(-1,3,-1,4);o=(45,25);sz=(620,260)
        b=axes(o,sz,bd,"x","f")
        for f,c in [(lambda x:x,BLUE),(lambda x:2-x,GREEN),(lambda x:max(x,2-x),RED)]:
            b+=plot(o,sz,bd,f,c)[0]
        _,p=plot(o,sz,bd,lambda x:0)
        for x,y in [(0,2),(1,1),(2,2)]:
            a,c=p(x,y);b+=f'<circle cx="{a}" cy="{c}" r="4" fill="{RED}"/>'+text(a+6,c-10,f"({x},{y})")
        return svg(b+text(50,325,"blue: x    green: 2-x    red: max(x,2-x)"))
    if uid == 40 and index == 0:
        return flow(["(x1,t1)=(0,1)|rate=0; cost=0","(x2,t2)=(2,2)|rate=1; cost=2","midpoint=(1,1.5)|rate=2/3","mixed rate|weights 1/3,2/3"],"Perspective cost at midpoint: 2/3 ≤ (0+2)/2 = 1. Mix x and t together.")
    if uid == 44:
        b=axes((40,40),(280,230),(-2.2,1.5,-9,4),"x","x³")
        curve,p=plot((40,40),(280,230),(-2.2,1.5,-9,4),lambda x:x**3)
        b+=curve
        a,c=p(-2,-8);d,e=p(-1,-1);b+=line(a,c,d,e,RED)
        for i,(alpha,end) in enumerate([(-8,-2),(0,0),(1,1)]):
            y=80+i*70;b+=line(390,y,690,y)+text(395,y-18,f"α={alpha}; endpoint={end}")
            q=560+end*55;b+=line(390,y,q,y,BLUE)+f'<circle cx="{q}" cy="{y}" r="4" fill="{BLUE}"/>'
        return svg(b+text(40,320,"curve above chord: not convex")+text(390,320,"Cα = (-∞, cube_root(α)]"))
    if uid == 45 and index == 0:
        b=""
        funcs=[(lambda x:math.exp(x)/x,(.6,3.3,2,11),"f=e^x/x"),(lambda x:x-math.log(x),(.6,3.3,.7,2.6),"g=x-log(x)")]
        points=[]
        for i,(fn,bd,label) in enumerate(funcs):
            o=(40+350*i,40);sz=(280,230)
            b+=axes(o,sz,bd,"x",label)
            curve,p=plot(o,sz,bd,fn);b+=curve;points.append(p)
            for x in [1,2,3]:
                a,c=p(x,fn(x));b+=f'<circle cx="{a}" cy="{c}" r="4" fill="{BLUE}"/>'+text(a-3,290,str(x))
            a,c=p(1,fn(1));d,e=p(3,fn(3));b+=line(a,c,d,e,GREEN)
        p=points[0]
        for y,c in [(math.exp(2)/math.sqrt(3),RED),((math.e+math.exp(3)/3)/2,GREEN)]:
            a,v=p(2,y);b+=f'<circle cx="{a}" cy="{v}" r="4" fill="{c}"/>'
        return svg(b+text(40,325,"at x=2: f=3.695; geometric bound=4.266; arithmetic bound=4.707",size=13))
    return None


def figure(uid, index, caption, lang):
    data = custom_figure(uid, index)
    if data is None:
        originals = OLD[uid].select("figure svg")
        oldindex = index
        if uid in (40,45) and index == 1:
            oldindex = 0
        if oldindex >= len(originals):
            raise ValueError(f"Missing figure: {uid}/{index}")
        data = str(originals[oldindex])
    fig = BeautifulSoup(data, "html.parser").svg
    # Each language has its own inline SVG; keep clip and marker IDs unique.
    suffix = f"-u{uid:02}-{lang}-{index}"
    replacements = {}
    for n in fig.select("[id]"):
        replacements[n["id"]] = n["id"]+suffix
        n["id"] += suffix
    data = str(fig)
    for old,new in replacements.items():
        data = data.replace(f"url(#{old})", f"url(#{new})").replace(f'href="#{old}"',f'href="#{new}"')
    path = ASSETS / f"u{uid:02}-{lang}-{index+1}.svg"
    path.write_text(data,encoding="utf8")
    # A bilingual caption remains in its language wrapper; the SVG labels use symbols.
    return f"<figure>{data}<figcaption>{caption}</figcaption></figure>"


def render_md(source, uid, lang):
    source = re.sub(r"^### .*\n", "", source, count=1, flags=re.M)
    tokens = []
    def math_token(tex, display=False):
        typ = "div" if display else "span"
        klass = "math display" if display else "math"
        tokens.append(f'<{typ} class="{klass}" data-tex="{html.escape(tex.strip(),quote=True)}"></{typ}>')
        return f"MATHPLACEHOLDER{len(tokens)-1}END"
    source = re.sub(r"\$\$(.*?)\$\$", lambda m: "\n\n"+math_token(m[1],True)+"\n\n", source, flags=re.S)
    source = re.sub(r"\$([^$\n]+)\$", lambda m: math_token(m[1]), source)
    raw = markdown.markdown(source,extensions=["tables","sane_lists"])
    for i,t in enumerate(tokens):
        raw = raw.replace(f"<p>MATHPLACEHOLDER{i}END</p>",t).replace(f"MATHPLACEHOLDER{i}END",t)
    doc = BeautifulSoup(raw,"html.parser")
    container = BeautifulSoup('<div></div>',"html.parser").div
    group = container
    exercise = None
    figure_count = 0
    for n in list(doc.contents):
        if isinstance(n,NavigableString) and not n.strip():
            continue
        value = n.get_text(" ",strip=True) if getattr(n,"name",None) else str(n)
        if getattr(n,"name",None) == "p" and value.startswith("【配图】"):
            caption = "".join(str(x) for x in n.contents).replace("【配图】","",1)
            group.append(BeautifulSoup(figure(uid,figure_count,caption,lang),"html.parser"))
            figure_count += 1
            continue
        if getattr(n,"name",None) == "p" and value == "【交互】":
            slot = BeautifulSoup('<div class="interaction-slot"></div>',"html.parser").div
            if lang=="zh":
                slot.append(copy.deepcopy(OLD[10].select_one(".interaction")))
            group.append(slot)
            continue
        heading = getattr(n,"name",None) in ("h3","h4")
        label = n.name=="p" and n.find("strong",recursive=False) and len(n.contents)==1
        supplement = label and value.startswith(("补充阅读","Further reading"))
        help_label = label and value in ("提示","思路提示","关键步骤","解答与核对","展开核对","Hint","Key steps","Solution and check","Check the answer")
        if heading or supplement:
            group = container
            exercise = None
            if supplement:
                group = BeautifulSoup('<details class="supplement"><summary></summary></details>',"html.parser").details
                group.summary.string=value
                container.append(group)
            elif value.startswith(("练习","先独立试一遍","Exercise","Try independently")):
                exercise=BeautifulSoup('<div class="exercise"></div>',"html.parser").div
                n.name="h3";exercise.append(n);container.append(exercise);group=exercise
            else:
                n.name="h3";container.append(n)
            continue
        if help_label:
            details=BeautifulSoup('<details><summary></summary></details>',"html.parser").details
            details.summary.string=value
            (exercise if exercise is not None else container).append(details)
            group=details
            continue
        group.append(n)
    for t in container.find_all("table"):
        wrap=BeautifulSoup('<div class="table-wrap"></div>',"html.parser").div
        t.wrap(wrap)
    return container


def manuscripts():
    combined=["# 凸优化 · 修订讲稿\n\n2026-10-23。双语原稿，按学习顺序排列。生成网页之前先维护本稿对应的逐节Markdown。\n"]
    units={}
    for chapter,ids in ORDERS.items():
        combined.append(f"\n# 第{chapter}讲\n")
        for uid in ids:
            path=DRAFT/f"u{uid:02}.md"
            draft=path.read_text(encoding="utf-8-sig")
            assert draft.count("## 中文")==1 and draft.count("## English")==1,path
            combined.append(draft)
            z,e=draft.split("## 中文",1)[1].split("## English",1)
            title_z=re.search(r"^### (.*)",z,re.M)[1]
            title_e=re.search(r"^### (.*)",e,re.M)[1]
            sec=BeautifulSoup(f'<section id="u{uid:02}"><h2>{bi(title_z,title_e)}</h2><div class="full-copy"></div></section>',"html.parser").section
            for lang,src in [("zh",z),("en",e)]:
                content=render_md(src,uid,lang)
                content["class"]=[lang,"manuscript-language"]
                content["lang"]="zh-CN" if lang=="zh" else "en"
                sec.select_one(".full-copy").append(content)
            # Reattach verified source images without converting them into prose.
            original=OLD[uid].select_one("details.original")
            if original:
                sec.select_one(".full-copy").append(copy.deepcopy(original))
            # Old public/evidence anchors remain attached to the corresponding unit.
            for n in OLD[uid].select("[id]"):
                ident=n["id"]
                if ident in ("support-graph","norm-choice","angle","angle-out","sweep","sweep-out","support-readout"):
                    continue
                if sec.find(id=ident):
                    continue
                alias=BeautifulSoup(f'<span class="anchor-alias" id="{html.escape(ident,quote=True)}"></span>',"html.parser").span
                exercises=sec.select(".zh .exercise")
                if ident.startswith(("ex","gate-")) and exercises:
                    old_exercises=OLD[uid].select(".exercise")
                    idx=next((i for i,x in enumerate(old_exercises) if x.get("id")==ident or x.find(id=ident)),0)
                    idx += {7:1,14:1,16:1,17:1,39:1,47:1}.get(uid,0)
                    exercises[min(idx,len(exercises)-1)].insert(0,alias)
                elif ident in ("lse-gradient","lse-hessian","least-squares-hessian","quadratic-method","induced-method","induced-proof","soc-proof","soc-dual-method","scalar-curvature","jensen-proof"):
                    needles={"lse-gradient":"指数","lse-hessian":"继续计算","least-squares-hessian":"从拟合模型","quadratic-method":"用已有工具",
                             "induced-method":"输入、输出都用","induced-proof":"连续经过","soc-proof":"例：二阶",
                             "soc-dual-method":"二阶锥为何","scalar-curvature":"三个一元","jensen-proof":"归纳到"}
                    target=next((h for h in sec.select(".zh h3") if needles[ident] in h.get_text()),None)
                    (target if target is not None else sec.h2).insert_before(alias)
                else:
                    sec.h2.insert_before(alias)
            for old_ex in OLD[uid].select(".exercise[data-gate]"):
                anchor=sec.find(id=old_ex.get("id"))
                if anchor is not None and anchor.find_parent(class_="exercise"):
                    anchor.find_parent(class_="exercise")["data-gate"]=old_ex["data-gate"]
            units[uid]=sec
    (DRAFT/"完整修订讲稿.md").write_text("\n\n".join(combined),encoding="utf8")
    return units


def relink_terms(page):
    term_script=next(s.get_text() for s in page.find_all("script") if s.get_text().startswith("const TERMS="))
    terms=json.loads(term_script[len("const TERMS="):].rstrip(";"))
    for uid in page.select("section[id^=u]"):
        for language in ("zh","en"):
            used=set()
            root=uid.select_one(".manuscript-language."+language)
            for n in list(root.find_all(string=True)):
                if n.find_parent(["h2","h3","summary","svg","figcaption","button"]) or n.find_parent(class_="math"):
                    continue
                value=str(n)
                for key,t in terms.items():
                    word=t[0 if language=="zh" else 1]
                    if key in used or len(word)<2:continue
                    match=re.search(re.escape(word) if language=="zh" else r"(?<![A-Za-z])"+re.escape(word)+r"(?![A-Za-z])",value)
                    if not match:continue
                    btn=page.new_tag("button",attrs={"class":"term","data-term":key})
                    btn.string=word
                    n.replace_with(NavigableString(value[:match.start()]),btn,NavigableString(value[match.end():]))
                    used.add(key);break


def relocate_terms(page):
    """Keep glossary destinations aligned with operations moved in this revision."""
    script=next(n for n in page.find_all("script") if n.get_text().startswith("const TERMS="))
    terms=json.loads(script.get_text()[len("const TERMS="):].rstrip(";"))
    for key,target in {"basis":"u12","relative":"u22"}.items():
        terms[key][5]=target
        button=page.select_one(f'#glossary [data-term="{key}"]')
        if button:
            a=button.find_parent("tr").find("a")
            if a:a["href"]=("#" if page.find(id=target) else "index.html#")+target
    script.string="const TERMS="+json.dumps(terms,ensure_ascii=False)+";"


def finish(page):
    relocate_terms(page)
    # Remove stale font subsets and use one subset covering the actual new manuscript.
    for style in list(page.find_all("style")):
        if style.string and "@font-face" in style.string and "ChapterSerif" in style.string:
            style.string=re.sub(r"@font-face\{[^}]*font-family:ChapterSerif[^}]*\}","",style.string)
    text_all=page.get_text()+"".join(t.get("data-tex","") for t in page.select("[data-tex]"))
    cache=DRAFT/("font-"+hashlib.sha256("".join(sorted(set(text_all))).encode()).hexdigest()[:12]+".woff2")
    if not cache.exists():
        font=instantiateVariableFont(TTFont("C:/Windows/Fonts/NotoSerifSC-VF.ttf"),{"wght":400},inplace=True)
        opts=subset.Options();ss=subset.Subsetter(options=opts);ss.populate(text=text_all);ss.subset(font)
        font.flavor="woff2";font.save(cache)
    style=page.new_tag("style")
    style.string=("@font-face{font-family:ChapterSerif;src:url(data:font/woff2;base64,"+
                  base64.b64encode(cache.read_bytes()).decode()+");font-weight:100 900;font-display:swap}"
                  ".manuscript-language>h3{margin-top:32px}"
                  ".manuscript-language .table-wrap{overflow-x:auto}"
                  "figure svg text{font-family:Arial,sans-serif}"
                  ".math.display{max-width:100%;overflow-x:auto}"
                  ".revision-note{font-size:15px;color:var(--muted)}")
    page.head.append(style)
    relink_terms(page)
    move=page.new_tag("script")
    move.string="""document.getElementById('language').addEventListener('click',()=>{
const u=document.getElementById('u10');if(!u)return;
const control=u.querySelector('.interaction');const slot=u.querySelector('.'+document.documentElement.dataset.lang+' .interaction-slot');
if(control&&slot)slot.append(control);
});
const originalShowTerm=showTerm;
showTerm=function(k){originalShowTerm(k);const t=TERMS[k];
if(!document.getElementById(t[5]))document.getElementById('term-target').href='index.html#'+t[5];};
document.getElementById('term-target').addEventListener('click',e=>{
const a=e.currentTarget;if(a.getAttribute('href').startsWith('index.html#')){
e.stopImmediatePropagation();e.preventDefault();location.href=a.href;}
},true);
const originalFollowHash=followHash;
followHash=function(hash){
const n=document.getElementById(decodeURIComponent(hash.slice(1)));
if(!n)return;
const source=n.closest('.manuscript-language'),unit=n.closest('section');
if(!source||source.classList.contains(document.documentElement.dataset.lang)){originalFollowHash(hash);return;}
const destination=unit.querySelector('.manuscript-language.'+document.documentElement.dataset.lang);
let target=destination;
const semantic={
'quadratic-method':'Computing the quadratic dual',
'lse-gradient':'Example: sum exponentials',
'lse-hessian':'Continuing log-sum-exp',
'least-squares-hessian':'Complete the least-squares task',
'induced-method':'Using ℓ∞ for both',
'induced-proof':'Applying two matrices',
'soc-proof':'Example: checking the second-order cone',
'soc-dual-method':'Why is the second-order cone self-dual',
'scalar-curvature':'Three one-variable functions',
'jensen-proof':'Induction to any finite number'
};
const exercise=n.closest('.exercise');
if(semantic[n.id]){target=Array.from(destination.querySelectorAll('h3')).find(h=>h.textContent.includes(semantic[n.id]))||destination;}
else if(exercise){const i=Array.from(source.querySelectorAll('.exercise')).indexOf(exercise);
target=destination.querySelectorAll('.exercise')[i]||destination;}
else if(n.nextElementSibling?.tagName==='H3'){
const i=Array.from(source.querySelectorAll('h3')).indexOf(n.nextElementSibling);
target=destination.querySelectorAll('h3')[i]||destination;}
for(let p=target.parentElement;p;p=p.parentElement)if(p.tagName==='DETAILS')p.open=true;
target.scrollIntoView();history.replaceState(null,'',hash);
};"""
    page.body.append(move)
    for footer in page.select("footer"):
        footer.clear()
        footer.append(BeautifulSoup(bi("2026-10-23 · 教学审查修订","2026-10-23 · Teaching review revision")+' · <a href="revision-report.md">'+bi("修订记录","Revision record")+'</a>',"html.parser"))
    ids=[n["id"] for n in page.select("[id]")]
    assert len(ids)==len(set(ids)),[x for x in set(ids) if ids.count(x)>1]
    return page


def build():
    units=manuscripts()
    master=copy.deepcopy(BASE)
    for uid,sec in units.items():
        master.find(id=f"u{uid:02}").replace_with(copy.deepcopy(sec))
    # Reorder within each lecture while keeping the original chapter entry anchors.
    for chapter,order in ORDERS.items():
        anchor=master.find(id=f"lecture-{chapter}")
        cursor=anchor
        for uid in order:
            n=master.find(id=f"u{uid:02}").extract()
            cursor.insert_after(n);cursor=n
    for intro in master.select(".intro-copy"):
        intro.clear()
        intro.append(BeautifulSoup(bi("按目录中的学习顺序阅读；节号保留原课件对应。基础操作在需要前讲解，拓展证明列入补充阅读。","Follow the learning order in the contents; section numbers retain slide references. Core operations precede their use, with extensions in further reading."),"html.parser"))
    hero=master.select_one(".hero")
    for p in hero.find_all("p",recursive=False):
        if p.get("class")==["eyebrow"]:continue
        p.decompose()
    hero.append(BeautifulSoup('<p>'+bi("前五讲连续自学讲义 · 2026-10-23教学审查修订。按任务、例题与推导顺序阅读。","Lectures 1–5 · Revised 2026-10-23 following the teaching review. Read through tasks, examples and derivations.")+'</p><p><a href="revision-report.md">'+bi("修订记录","Revision record")+'</a> · <a href="lecture-source.zip">'+bi("双语讲稿与生成源包","Manuscripts and source archive")+'</a></p>',"html.parser"))
    def nav(page):
        page.nav.clear()
        for sec in page.select("section[id^=u]"):
            page.nav.append(BeautifulSoup('<a href="#'+sec["id"]+'">'+sec.h2.decode_contents()+'</a>',"html.parser"))
        for ident,z,e in [("glossary","名词对照表","Terminology"),("homework","作业路线","Homework"),("source-map","来源地图","Source map")]:
            if page.find(id=ident):
                page.nav.append(BeautifulSoup(f'<a href="#{ident}">'+bi(z,e)+'</a>',"html.parser"))
    nav(master)
    finish(master)
    (OUT/"index.html").write_text(str(master),encoding="utf8")
    for chapter in range(2,6):
        page=copy.deepcopy(master)
        for sec in list(page.select("section[id^=u]")):
            if int(sec["id"][1:]) not in ORDERS[chapter]:sec.decompose()
        for opening in list(page.select(".chapter-opening")):
            if opening.get("id")!=f"lecture-{chapter}":opening.decompose()
        # Full glossary/source-map links lead to the canonical handbook.
        for a in page.select("#glossary a[href^='#'],#source-map a[href^='#']"):
            if not page.find(id=a["href"][1:]):a["href"]="index.html"+a["href"]
        for a in page.select("a[href^='#']"):
            if not page.find(id=a["href"][1:]):a["href"]="index.html"+a["href"]
        page.title.string=f"凸优化 · 第{chapter}讲自学讲义"
        nav(page)
        (OUT/f"chapter-{chapter}.html").write_text(str(page),encoding="utf8")
    route=copy.deepcopy(master)
    route.select_one(".hero h1").clear()
    route.select_one(".hero h1").append(BeautifulSoup(bi("HW1 · 连续阅读路线","HW1 · Continuous reading route"),"html.parser"))
    for op in route.select(".chapter-opening"):op.decompose()
    ids=[6,7,8,9,10,11,12,15,16,13,14,17,18,19,20,21,25,29,30,31,36,32,33]
    ids+= [i for order in ORDERS.values() for i in order if i not in ids]
    cursor=route.select_one(".hero")
    for uid in ids:
        n=route.find(id=f"u{uid:02}").extract();cursor.insert_after(n);cursor=n
    # Keep lecture links and the original readiness anchor resolvable in this route.
    for c in range(1,6):
        route.find(id=f"u{ORDERS[c][0]:02}").insert(0,BeautifulSoup(f'<span class="anchor-alias" id="lecture-{c}"></span>',"html.parser"))
    if not route.find(id="hw1-ready"):
        route.find(id="u33").insert_after(BeautifulSoup('<div id="hw1-ready"><p>'+bi("主要工具已读完。请先独立作答，再用讲义核对条件和步骤。","The main tools are covered. Attempt the tasks independently, then check conditions and steps.")+'</p></div>',"html.parser"))
    nav(route)
    (OUT/"hw1-route.html").write_text(str(route),encoding="utf8")
    summary={"date":"2026-10-23","units":47,"order":ORDERS,"source":"讲稿修订_2026-10-23/u01.md—u47.md","figures":len(list(ASSETS.glob("*.svg")))}
    (DRAFT/"生成记录.json").write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding="utf8")
    print(json.dumps(summary,ensure_ascii=False))


if __name__=="__main__":
    build()
