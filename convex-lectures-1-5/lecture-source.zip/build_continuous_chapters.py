"""Build independently readable chapters from escaped, newly authored prose."""
from pathlib import Path
if (Path(__file__).parent / "讲稿修订_2026-10-23/修订任务表.md").exists():
    from generate_review_revision import build
    build()
    raise SystemExit(0)
import argparse,base64,hashlib,html,importlib,json,re,os
from bs4 import BeautifulSoup,NavigableString
from fontTools.ttLib import TTFont
from fontTools.varLib.instancer import instantiateVariableFont
from fontTools import subset
from chapter2_content import UNITS,INTRO,p,m,bi
import chapter2_analysis,chapter2_linear
from chapter2_editorial import refine
refine(UNITS)
parser=argparse.ArgumentParser();parser.add_argument('--chapter',type=int,default=2);args=parser.parse_args();chapter=args.chapter
CHAPTER_INTROS={2:INTRO}
for number in [3,4,5]:
    if (Path(__file__).parent/f'chapter{number}_content.py').exists():
        module=importlib.import_module(f'chapter{number}_content');CHAPTER_INTROS[number]=module.INTRO
from continuous_practice import apply as add_proof_practice
add_proof_practice(UNITS)

R=Path(__file__).parent;OUT=R/'完整讲义'
backup=R/'结构重写前来源快照.html'
if not backup.exists():backup.write_bytes((OUT/'index.html').read_bytes())
original=BeautifulSoup(backup.read_text(encoding='utf8'),'html.parser')
mapping=json.loads((R/'内容地图.json').read_text(encoding='utf8'))
selected={u['id'] for u in mapping['units'] if u['lecture']==chapter}
UNITS={k:v for k,v in UNITS.items() if k in selected}
assert set(UNITS)==selected,'Chapter content is incomplete'
term_script=next(s.get_text() for s in original.find_all('script') if s.get_text().startswith('const TERMS='))
oldterms=json.loads(term_script.split('const TERMS=')[1].split(';const TERM_NOTES=')[0])
oldnotes=json.loads(term_script.split(';const TERM_NOTES=')[1].rstrip(';'))
term_locations={'norm':'07','ball':'07','inner':'06','sup':'11','max':'11','dual':'10','support':'38','holder':'10','cs':'06','pd':'16','psd':'16','quad':'16','sqrt':'16','argmax':'10','ellipsoid':'16','polar':'29','conjugate':'41','spectral':'17','nuclear':'17','frobenius':'09','svd':'17','cone':'25','sign':'10','diag':'16','trace':'06','basis':'09'}
for key,uid in term_locations.items():
    if key in oldterms:oldterms[key][5]='u'+uid
TERMS={k:[*v[:6],*oldnotes.get(k,['',''])] for k,v in oldterms.items() if v[5] in ['u'+i for i in UNITS]}
# Larger values are introduced in later sections rather than used as prerequisites.
if chapter==2:TERMS['norm']=['范数','norm','‖x‖','满足非负且仅零向量取零、绝对齐次性及三角不等式的长度度量。','A length measure satisfying definiteness, absolute homogeneity and the triangle inequality.','u07','(3,−4) 的 ℓ₁、ℓ₂、ℓ∞ 范数分别是 7、5、4。','The ℓ₁, ℓ₂ and ℓ∞ norms of (3,−4) are 7, 5 and 4.']
if 'covariance' in TERMS:TERMS['covariance'][2]='Cov(a)'
close='<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M4 4L12 12M12 4L4 12" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/></svg>'
def figure(uid):
    if uid=='44':
        from continuous_figures import quasiconvex
        return '<figure>'+quasiconvex()+'<figcaption>'+bi('左图 x³ 在 −2、−1 间的曲线高于弦，中点函数值 −3.375 高于端点平均 −4.5，因此不凸。右图门槛1对应次水平集 (−∞,1]；所有其他门槛也得到区间，所以拟凸。','Left: x³ lies above the chord between −2 and −1; its midpoint value −3.375 exceeds average endpoint value −4.5, disproving convexity. Right: threshold one gives (−∞,1]; every other threshold also gives an interval, proving quasiconvexity.')+'</figcaption></figure>'
    node=original.find(id='u'+uid).find('figure',class_='course-figure')
    if node is None:return ''
    caption=CAPTIONS.get(uid) or ''.join(str(n) for n in node.figcaption.contents)
    return '<figure>'+str(node.svg)+'<figcaption>'+caption+'</figcaption></figure>'
CAPTIONS={
'06':bi('蓝色 x=(3,4)，绿色 y=(1,0) 长度为 1。红色投影在水平轴上，长度 3，等于 xᵀy。','Blue x=(3,4) projects onto unit green y=(1,0). Its red horizontal projection has length three, equal to xᵀy.'),
'07':bi('三个区域依次是 ℓ₁、ℓ₂、ℓ∞ 单位球，横纵比例相同。检查点 (1,1)：它只在正方形内。','The regions are the ℓ₁, ℓ₂ and ℓ∞ unit balls, with equal axis scales. Point (1,1) belongs only to the square.'),
'09':bi('蓝色单位圆盘经过 diag(3,2) 后成为红色椭圆，半轴为 3、2；最大长度放大率是 3。','The blue unit disk becomes the red ellipse under diag(3,2), with semiaxes three and two. Maximum amplification is three.'),
'11':bi('(0,1] 左端空心、右端实心。绿色小邻域完全留在区间内，边界附近的红色邻域会越出。','The left endpoint of (0,1] is excluded; the right is included. A green interior neighborhood stays inside, while a red boundary neighborhood crosses outside.'),
'16':bi('左：单位圆盘经 diag(3,2) 的线性像，半轴 3、2。右：4x₁²+x₂²≤1 的原输入集合，半轴 1/2、1。每图横纵等比例；请分别读取刻度。','Left: the linear image under diag(3,2), with semiaxes three and two. Right: original inputs satisfying 4x₁²+x₂²≤1, with semiaxes one half and one. Each panel uses equal axis scales; read their scales separately.')}

INTERACTION='<div class="interaction"><div class="controls"><label>'+bi('原范数','Original norm')+' <select id="norm-choice"><option value="l1">ℓ₁</option><option value="l2" selected>ℓ₂</option><option value="linf">ℓ∞</option></select></label><label>'+bi('z 的方向','Direction of z')+' <output id="angle-out"></output><input id="angle" type="range" min="0" max="360" value="0" step="1"></label><label>'+bi('相对位置 r','Relative position r')+' <output id="sweep-out"></output><input id="sweep" type="range" min="-1.2" max="1.2" step=".01" value="1"></label></div><svg id="support-graph" viewBox="0 0 520 410" role="img" aria-label="Dual norm supporting line"></svg><p>'+bi('蓝色区域为单位球，蓝箭头为 z；红虚线为支撑线，绿线为当前评分线。','The blue region is the unit ball and the blue arrow is z; the red dashed line is supporting, the green line is the current score line.')+'</p><p class="readout" id="support-readout" aria-live="polite"></p></div>'

def source(uid):
    row=next(t for t in mapping['units'] if t['id']==uid)
    lid=row['lecture']
    return '<details class="original"><summary>'+bi('核对原课件 · 第'+str(lid)+'讲 '+row['page_range']+'页','Original slides · Lecture '+str(lid)+', pp. '+row['page_range'])+'</summary><div class="slide-grid">'+''.join('<figure><a href="pages/L'+str(lid)+'-'+str(i).zfill(3)+'.webp"><img loading="lazy" src="pages/L'+str(lid)+'-'+str(i).zfill(3)+'.webp" alt="Lecture '+str(lid)+' page '+str(i)+'"></a><figcaption>PDF '+str(i)+'</figcaption></figure>' for i in row['pages'])+'</div></details>'

body='<div class="intro-copy">'+CHAPTER_INTROS[chapter]+'</div>'
nav=''
for uid,u in UNITS.items():
    nav+='<a href="#u'+uid+'">'+bi(u['zh'],u['en'])+'</a>'
    full=BeautifulSoup(u['body'],'html.parser')
    for placeholder in full.select('[data-figure]'):
        placeholder.replace_with(BeautifulSoup(figure(placeholder['data-figure']),'html.parser'))
    for placeholder in full.select('[data-interaction]'):
        placeholder.replace_with(BeautifulSoup(INTERACTION,'html.parser'))
    body+='<section id="u'+uid+'"><h2>'+bi(u['zh'],u['en'])+'</h2><div class="full-copy">'+str(full)+source(uid)+'</div></section>'

gloss='<input id="term-search" class="gloss-search" type="search" aria-label="Search glossary" placeholder="Hessian / 范数"><div class="table-wrap"><table><thead><tr><th>'+bi('中文','Chinese')+'</th><th>'+bi('英文','English')+'</th><th>'+bi('符号与解释','Symbol and meaning')+'</th></tr></thead><tbody>'
for key,t in TERMS.items():gloss+='<tr><td><button class="term" data-term="'+key+'">'+html.escape(t[0])+'</button></td><td>'+html.escape(t[1])+'</td><td>'+html.escape(t[2])+p(t[3],t[4])+'<a href="#'+t[5]+'">'+bi('正文','Read')+'</a></td></tr>'
body+='<section id="glossary"><h2>'+bi('名词对照表','Terminology')+'</h2>'+gloss+'</tbody></table></div></section>'
body+='<section id="sources"><h2>'+bi('本章来源与阅读范围','Sources and scope')+'</h2>'+p('本章重写第二讲的13个知识单元。每节保留所对应的原课件页；封面、提纲和总结在全篇来源表中保留。教材参考附录 A 的数学背景及附录 B 的二次优化，二次范数与对偶参见 A.1.6 和 A.1.7；页码以课件 PDF 从1开始计数。','This chapter rewrites the thirteen units of Lecture 2. Each retains its original-slide links; covers, outlines and the summary remain in the full source map. Textbook references include mathematical background in Appendix A and quadratic optimization in Appendix B; see A.1.6 and A.1.7 for norms and dual norms. Slide page numbers are one-based PDF pages.')+'<p><a href="index.html#source-map">'+bi('全篇来源地图','Full source map')+'</a> · <a href="chapter-rewrite-review.md">'+bi('本轮审阅与修订记录','Review and revision record')+'</a></p></section>'
nav+='<a href="#glossary">'+bi('名词对照表','Terminology')+'</a><a href="#sources">'+bi('来源与审阅记录','Sources and review')+'</a>'
soup=BeautifulSoup(body,'html.parser')
used={'zh':set(),'en':set()}
for node in list(soup.find_all(string=True)):
    lng=node.find_parent(class_=['zh','en'])
    if not lng or node.find_parent(['button','h2','h3','summary','svg','figcaption']) or node.find_parent(id='glossary'):continue
    lang='zh' if 'zh' in lng.get('class',[]) else 'en'
    for key,t in TERMS.items():
        word=t[0 if lang=='zh' else 1]
        if key in used[lang] or len(word)<2 or word not in str(node):continue
        if lang=='en':
            match=re.search(r'(?<![A-Za-z])'+re.escape(word)+r'(?![A-Za-z])',str(node))
            if not match:continue
            a,b=str(node)[:match.start()],str(node)[match.end():]
        else:a,b=str(node).split(word,1)
        btn=soup.new_tag('button',attrs={'class':'term','data-term':key});btn.string=word
        node.replace_with(NavigableString(a),btn,NavigableString(b));used[lang].add(key);break
body=str(soup)
body=body.replace('二次范数与对偶参见 A.1.6 和 A.1.7','范数、诱导范数、对偶范数分别参见 A.1.4、A.1.5、A.1.6').replace('see A.1.6 and A.1.7 for norms and dual norms','see A.1.4–A.1.6 for vector, operator and dual norms')
for math_node in soup.select('.math'):
    math_node['data-tex']=math_node['data-tex'].replace(r'\prime\prime',r'^{\prime\prime}').replace(r'\prime(',r'^{\prime}(')
body=str(soup)
body=body.replace('二次范数与对偶参见 A.1.6 和 A.1.7','范数、诱导范数、对偶范数分别参见 A.1.4、A.1.5、A.1.6').replace('see A.1.6 and A.1.7 for norms and dual norms','see A.1.4–A.1.6 for vector, operator and dual norms')
chars=body+nav+json.dumps(TERMS,ensure_ascii=False)+(R/'chapter_reader.js').read_text(encoding='utf8')+'凸优化第二章完整自学讲义数学基础日间夜间目录返回笔记中英连续正文'
fontcss=''
for weight in [400,700]:
    cache=R/('chapterfont-'+hashlib.sha256((str(weight)+''.join(sorted(set(chars)))).encode()).hexdigest()[:12]+'.woff2')
    if not cache.exists():
        print('Building chapter font:',weight,flush=True)
        font=instantiateVariableFont(TTFont(os.environ.get('CONVEX_CJK_FONT','C:/Windows/Fonts/NotoSerifSC-VF.ttf')),{'wght':weight},inplace=True)
        opts=subset.Options();sub=subset.Subsetter(options=opts);sub.populate(text=chars);sub.subset(font);font.flavor='woff2';font.save(cache)
    fontcss+='@font-face{font-family:ChapterSerif;src:url(data:font/woff2;base64,'+base64.b64encode(cache.read_bytes()).decode()+');font-weight:'+str(weight)+';font-display:swap}'
katex=Path(os.environ.get('CONVEX_KATEX_DIST',str(R/'vendor/katex') if (R/'vendor/katex').exists() else 'E:/CC_Nichijo/notes/llm-principles/src/node_modules/katex/dist'))
kcss=(katex/'katex.min.css').read_text(encoding='utf8')
def inlined(match):
    f=katex/match.group(1);return 'url(data:font/'+f.suffix[1:]+';base64,'+base64.b64encode(f.read_bytes()).decode()+')'
kcss=re.sub(r'url\((fonts/[^)]+)\)',inlined,kcss)
dialog='<dialog id="term-dialog"><button class="icon-button" id="term-close" aria-label="Close">'+close+'</button><h2 id="term-heading"></h2><p class="other-name" id="term-other"></p><p class="term-label">'+bi('如何理解','MEANING')+'</p><p id="term-definition"></p><p class="term-label">'+bi('例子','EXAMPLE')+'</p><p id="term-example"></p><a id="term-target" href="#u07">'+bi('回到正文','Read in context')+'</a></dialog>'
page='<!doctype html><html lang="zh-CN" data-lang="zh" data-mode="full"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>凸优化 · 第二章完整自学讲义</title><style>'+fontcss+kcss+(R/'chapter_reader.css').read_text(encoding='utf8')+'</style></head><body><aside><button class="icon-button sidebar-close" id="sidebar-close" aria-label="Close contents">'+close+'</button><div class="brand">'+bi('凸优化','Convex optimization')+'<small>'+bi('第二章 · 数学基础','Chapter 2 · Mathematical tools')+'</small></div><nav>'+nav+'</nav><p class="aside-note">W ↑ · S ↓ · A ← · D →'+'</p></aside><header><span class="mode-status" id="mode-status">'+bi('完整讲义','Full text')+'</span><div class="toolbar"><button id="toc" aria-expanded="true">'+bi('目录','Contents')+'</button><button id="theme">'+bi('夜间','Dark')+'</button><button id="language">English</button></div></header><main><div class="reading-width"><div class="hero"><p class="eyebrow">CONVEX OPTIMIZATION / CHAPTER 02</p><h1>'+bi('数学基础：长度、变化与矩阵','Mathematical tools: size, change and matrices')+'</h1><p class="meta">'+bi('完整自学正文 · 中英切换 · 13节','Continuous self-study text · Two languages · 13 sections')+'</p><p><a href="index.html">'+bi('返回五讲目录','Back to the five-lecture handbook')+'</a></p></div>'+body+'<footer>'+bi('更新于2026-10-16。审阅记录报告具体检查范围；学习掌握仍需通过独立解题检验。','Updated 2026-10-16. The review record states what was checked; independent problem solving remains the test of understanding.')+'</footer></div></main><a class="home-back" href="../">'+bi('← 返回笔记入口','← Notes home')+'</a>'+dialog+'<script>'+(katex/'katex.min.js').read_text(encoding='utf8')+'</script><script>const TERMS='+json.dumps(TERMS,ensure_ascii=False)+';</script><script>'+(R/'chapter_reader.js').read_text(encoding='utf8')+'</script></body></html>'
page=page.replace('id="term-target" href="#u07"','id="term-target" href="#u'+next(iter(UNITS))+'"')
if chapter!=2:
    titles={3:('凸集：从线段到锥与分离','Convex sets: segments, cones and separation'),4:('凸函数：判定与构造','Convex functions: tests and constructions'),5:('共轭与广义凸性','Conjugacy and generalized convexity')}
    page=page.replace('凸优化 · 第二章完整自学讲义',f'凸优化 · 第{chapter}章完整自学讲义').replace('第二章 · 数学基础',f'第{chapter}章 · 数学基础').replace('Chapter 2 · Mathematical tools',f'Chapter {chapter} · Mathematical tools').replace('CHAPTER 02',f'CHAPTER {chapter:02}').replace('13节',str(len(UNITS))+'节').replace('13 sections',str(len(UNITS))+' sections')
    page=page.replace('数学基础：长度、变化与矩阵',titles[chapter][0]).replace('Mathematical tools: size, change and matrices',titles[chapter][1]).replace('数学基础</span>',''+titles[chapter][0]+'</span>').replace('Mathematical tools</span>',titles[chapter][1]+'</span>')
    # Scope paragraph belongs to this chapter; individual original-page links are already generic.
    parsed=BeautifulSoup(page,'html.parser');scope=parsed.find(id='sources').find('p')
    scope.replace_with(BeautifulSoup(p('本章重写第'+str(chapter)+'讲的'+str(len(UNITS))+'个知识单元；每节保留原课件页。教材主要参考第2章（凸集）、第3章（凸函数）及附录数学背景；以章节号定位，课件页码从1计数。','This rewrites '+str(len(UNITS))+' units of Lecture '+str(chapter)+', retaining original-slide links. Textbook references are Chapter 2 on convex sets, Chapter 3 on convex functions, and the mathematical appendices. Slide PDF pages are one-based.'),'html.parser'));page=str(parsed)
path=OUT/f'chapter-{chapter}.html';path.write_text(page,encoding='utf8')
review=BeautifulSoup(page,'html.parser')
# Review the actual HTML body, formulas and figure captions; omit bundled binary fonts and library code.
for n in review.find_all(['style','script']):n.decompose()
(R/'第三方审稿').mkdir(exist_ok=True)
(R/f'第三方审稿/chapter-{chapter}-review.html').write_text(str(review),encoding='utf8')
print('Built:',path,'units:',len(UNITS),'review HTML chars:',len(str(review)),flush=True)
