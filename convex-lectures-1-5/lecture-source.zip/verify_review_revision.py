"""Verify mathematics, manuscript synchronization and the rendered reading flows."""
from pathlib import Path
from collections import Counter
import hashlib
import json
import re
import zipfile

from bs4 import BeautifulSoup
import sympy as S
from playwright.sync_api import sync_playwright

ROOT=Path(__file__).parent
OUT=ROOT/"完整讲义"
REV=ROOT/"讲稿修订_2026-10-23"
REPORT={"date":"2026-10-23","static":[],"browser":[],"mathematics":{}}


def math_checks():
    x=S.symbols("x",positive=True)
    A=S.Matrix([[1,0],[1,1],[1,2]])
    d=S.Matrix([1,2,6])
    sol=(A.T*A).inv()*A.T*d
    residual=A*sol-d
    assert sol==S.Matrix([S.Rational(1,2),S.Rational(5,2)])
    assert residual.dot(residual)==S.Rational(3,2) and A.T*residual==S.zeros(2,1)
    assert S.diff(x-S.log(x),x,2)==1/x**2
    assert S.diff(3*x-2*S.log(x),x).subs(x,S.Rational(2,3))==0
    assert S.simplify((S.exp(3*x)/x**2).subs(x,S.Rational(2,3)))==9*S.exp(2)/4
    Q=S.Matrix([[1,1],[1,-1]])/S.sqrt(2)
    P=S.Matrix([[2,1],[1,2]])
    v=S.Matrix([2,0]);y=Q.T*v
    assert Q*y==v and (v.T*P*v)[0]==8
    assert (y.T*S.diag(3,1)*y)[0]==8
    B=S.Matrix([[2,0,0],[0,0,0]])
    assert B.pinv()*S.Matrix([4,3])==S.Matrix([2,0,0])
    M=S.Matrix([[1,0,1],[0,4,2],[1,2,2]])
    assert all(t>=0 for t in M.eigenvals())
    x1,x2=S.symbols("x1 x2",real=True)
    F=x1**2+(x1+x2)**2
    grad=S.Matrix([S.diff(F,z) for z in (x1,x2)])
    assert grad.subs({x1:1,x2:1})==S.Matrix([6,4])
    q=x1**2+2*x1*x2+3*x2**2
    H=S.hessian(q,(x1,x2))
    assert H==S.Matrix([[2,2],[2,6]])
    assert (S.Matrix([1,-1]).T*H*S.Matrix([1,-1]))[0]==4
    L=S.log(S.exp(x1)+S.exp(-x1)+S.exp(x2))
    assert S.hessian(L,(x1,x2)).subs({x1:0,x2:0})==S.diag(S.Rational(2,3),S.Rational(2,9))
    yy=S.symbols("y",real=True)
    reduced=S.expand((x-yy)**2+2*yy**2)
    assert S.simplify(reduced.subs(yy,x/3)-2*x*x/3)==0
    assert S.Rational(3,2)**2/2==S.Rational(9,8)
    a,b,c=S.symbols("a b c",real=True)
    assert S.expand((x+1)**2+1-(x-1)**2)==4*x+1
    REPORT["mathematics"]={
        "least_squares":{"parameters":["1/2","5/2"],"residual":["-1/2","1","-1/2"],"squared_error":"3/2","normal_equation":True},
        "log_transform":{"minimum_input":"1","minimum_cost":"e","product_input":"2/3","product_cost":"9e^2/4","derivatives":True},
        "coordinate_change":True,"rectangular_pseudoinverse":True,
        "schur_example":True,"chain_rule":True,"mixed_hessian":True,
        "lse_hessian_at_zero":True,"partial_minimization":True,
        "perspective_weights":True,"unequal_valleys":True,
        "scope":"Exact symbolic checks of listed examples. General claims are checked in the manuscript proofs."
    }


def static_checks():
    canonical=BeautifulSoup((OUT/"index.html").read_text(encoding="utf8"),"html.parser")
    main={s["id"]:s for s in canonical.select("section[id^=u]")}
    for figure in canonical.select(".manuscript-language figure"):
        assert not figure.find_parent("details"),("main figure hidden",figure.find_parent("section")["id"])
    for uid,lang,needle in [(9,"zh","取上确界时"),(9,"en","Collect the output lengths"),
                            (15,"en","Removing it leaves the same range"),(16,"en","The original quadratic value is eight")]:
        paragraph=next(p for p in main[f"u{uid:02}"].select(f".manuscript-language.{lang} p") if needle in p.get_text())
        assert not paragraph.find_parent("details"),("core bridge hidden",uid,lang)
    with zipfile.ZipFile(REV/"修订前网页.zip") as z:
        old=BeautifulSoup(z.read("index.html"),"html.parser")
    oldids={n["id"] for n in old.select("[id]")}
    files=["index.html","hw1-route.html",*[f"chapter-{c}.html" for c in range(2,6)]]
    for filename in files:
        p=BeautifulSoup((OUT/filename).read_text(encoding="utf8"),"html.parser")
        counts=Counter(n["id"] for n in p.select("[id]"))
        assert not [k for k,v in counts.items() if v>1],filename
        for a in p.select("a[href^='#']"):
            assert a["href"][1:] in counts,(filename,a["href"])
        sections=p.select("section[id^=u]")
        assert len(sections)==(47 if filename in files[:2] else {2:13,3:12,4:10,5:7}[int(filename[8])])
        if filename=="index.html":
            assert oldids<=set(counts),(oldids-set(counts))
        for sec in sections:
            assert sec.get_text()==main[sec["id"]].get_text(),(filename,sec["id"])
            for lang in ("zh","en"):
                assert sec.select_one(".manuscript-language."+lang).get_text().strip()
                assert sec.select_one("."+lang+" .exercise"),(filename,sec["id"],lang)
        assert not p.select("[data-level],[data-depth-button],.layer,#mode")
        assert not p.select(".exercise details[open],.supplement[open]")
        REPORT["static"].append({"page":filename,"units":len(sections),"unique_ids":True,"local_links":True,"canonical_unit_text":True,"sha256":hashlib.sha256((OUT/filename).read_bytes()).hexdigest()})
    for row in json.loads((ROOT/"内容地图.json").read_text(encoding="utf8"))["pages"]:
        assert (OUT/f'pages/L{row["lecture"]}-{row["page"]:03}.webp').exists()
    REPORT["source_pages"]=280
    REPORT["source_archive_baseline_preserved"]=True


def browser_checks():
    with sync_playwright() as pw:
        browser=pw.chromium.launch(executable_path="C:/Program Files/Google/Chrome/Application/chrome.exe",headless=True)
        for name in ("index.html","hw1-route.html","chapter-2.html","chapter-5.html"):
            for width in (1360,390):
                ctx=browser.new_context(viewport={"width":width,"height":940},reduced_motion="reduce")
                page=ctx.new_page()
                errors=[]
                page.on("pageerror",lambda e:errors.append(str(e)))
                page.goto((OUT/name).as_uri(),wait_until="networkidle")
                page.evaluate("document.fonts.ready")
                page.wait_for_function("document.querySelectorAll('.math .katex').length>30")
                for lang in ("zh","en"):
                    if page.locator("html").get_attribute("data-lang")!=lang:
                        page.locator("#language").click()
                    assert page.locator(".math-error,.katex-error").count()==0,(name,lang,page.locator(".math-error,.katex-error").evaluate_all("(ns)=>ns.map(n=>n.dataset.tex||n.textContent)"))
                    assert page.evaluate("document.documentElement.scrollWidth<=innerWidth+2"),(name,width,lang)
                    target="u45" if name!="chapter-2.html" else "u14"
                    page.locator("#"+target).evaluate("n=>n.scrollIntoView()")
                    page.screenshot(path=str(REV/f'{name[:-5]}-{width}-{lang}.png'))
                # Open and close a real answer without altering the default saved page.
                details=page.locator(".en .exercise details").first
                details.locator("summary").click()
                assert details.get_attribute("open") is not None
                details.locator("summary").click()
                assert details.get_attribute("open") is None
                term_results=page.evaluate("""()=>Object.keys(TERMS).map(k=>{
showTerm(k);
const d=document.getElementById('term-definition').textContent.trim();
const e=document.getElementById('term-example').textContent.trim();
const href=document.getElementById('term-target').getAttribute('href');
const target=href.startsWith('#')?!!document.getElementById(href.slice(1)):href.startsWith('index.html#');
document.getElementById('term-dialog').close();
return {k,definition:!!d,example:!!e,target};})""")
                assert len(term_results)==78 and all(t["definition"] and t["example"] and t["target"] for t in term_results),term_results
                page.locator(".en .term:visible").first.click()
                assert page.locator("#term-dialog").is_visible()
                page.locator("#term-close").click()
                if name!="chapter-5.html":
                    page.evaluate("followHash('#quadratic-method')")
                    heading=page.locator("#u16 .en h3").filter(has_text="Computing the quadratic dual norm")
                    assert -1<=heading.bounding_box()["y"]<940
                    page.locator("#u10").evaluate("n=>n.scrollIntoView()")
                    page.select_option("#norm-choice","l1")
                    page.locator("#angle").fill("45")
                    page.locator("#angle").dispatch_event("input")
                    assert "0.7071" in page.locator("#support-readout").inner_text()
                    page.locator("#language").click()
                    assert page.locator("#support-graph").is_visible()
                page.locator("#theme").click()
                theme=page.locator("html").get_attribute("data-theme")
                page.reload(wait_until="networkidle")
                assert page.locator("html").get_attribute("data-theme")==theme
                assert not errors,(name,width,errors[:5])
                REPORT["browser"].append({"page":name,"width":width,"languages":["zh","en"],"formula_errors":0,"page_overflow":False,"term_cards":78,"answers_fold":True,"theme_memory":True,"javascript_errors":[]})
                print("Browser verified:",name,width,flush=True)
                ctx.close()
        # Diagram-level screenshots for visual inspection at their actual DOM position.
        page=browser.new_page(viewport={"width":1360,"height":940},reduced_motion="reduce")
        page.goto((OUT/"index.html").as_uri(),wait_until="networkidle")
        for uid in (1,4,5,6,14,17,20,23,26,34,38,40,44,45):
            node=page.locator(f"#u{uid:02} .zh figure").last
            node.screenshot(path=str(REV/f"figure-u{uid:02}.png"))
        browser.close()


if __name__=="__main__":
    math_checks()
    print("Exact mathematics verified.",flush=True)
    static_checks()
    print("Six pages and 280 source resources verified.",flush=True)
    browser_checks()
    REPORT["pending"]=["Real-reader first-pass trials across all units.","Immediate and delayed independent transfer tasks."]
    (REV/"验收记录.json").write_text(json.dumps(REPORT,ensure_ascii=False,indent=2),encoding="utf8")
    print("PASS: mathematics; six synchronized pages; eight browser runs; both languages; 78 term cards.")
