"""Assemble the task-book revision, preserving old unit and exercise anchors."""
from pathlib import Path
import json,copy
from bs4 import BeautifulSoup
from refinement_content import bi,p,m,h,d,exercise,PRELUDE,BLOCKS,GATES,NOTES
R=Path(__file__).parent

STAGES=[
('route-foundations','1 · 证明、向量与长度','1 · Proofs, vectors and lengths',['06','07','11','08']),
('route-norms','2 · 二次型、诱导与对偶范数','2 · Quadratics, induced and dual norms',['15','16','09','10']),
('route-derivatives','3 · 求导、Hessian 与零方向','3 · Derivatives, Hessians and null directions',['12','13','14']),
('route-sets','4 · 凸集与定义证明','4 · Convex sets and proofs from definitions',['19','20','21']),
('route-functions','5 · 凸函数与归纳','5 · Convex functions and induction',['31','32','33','36']),
('route-cones','6 · 锥、对偶锥与序','6 · Cones, dual cones and orders',['25','29','30'])]

# Each evidence row identifies a concrete method, example and transfer exercise.
EVIDENCE=[
('1(a)','quadratic-method','quadratic-proof','gate-norm','可逆平方根换元；上界与取等；z=0 单列。','Invertible square-root substitution; bound and attainment; separate z=0.'),
('1(b)','induced-method','induced-proof','gate-norm','比例归一化、逐行上界、符号输入，允许矩形和零矩阵。','Ratio normalization, row bound and sign input; rectangular and zero matrices.'),
('1(c)','induced-proof','induced-proof','gate-norm','相容中间范数；零向量放大界；不除以 ‖Bx‖。','Compatible middle norm; zero-vector bound; no division by ‖Bx‖.'),
('2(a)','lse-gradient','lse-gradient','gate-derivative','指数、对数与仿射链式法则；列梯度维数。','Exponential, logarithmic and affine chain rules; column dimensions.'),
('2(b)','lse-hessian','lse-hessian','gate-derivative','商法则逐步求 ∇pᵢ；外积与两项中心化展开。','Quotient-rule weight derivative; outer products and centered expansion.'),
('2(c)','hessian-method','lse-hessian','gate-derivative','正权重平方和；全部差向量正交约束；m=1。','Positive weighted squares; all difference-vector constraints; m=1.'),
('3(a)','u19-understand','sets-method','gate-sets','任意点与 θ；线性代入；空集无需可逆性。','Arbitrary points and θ; linear substitution; empty sets without invertibility.'),
('3(b)','sets-method','sets-method','gate-sets','减球心后用齐次性、三角不等式，含 r=0。','Subtract the center, homogeneity and triangle inequality, including r=0.'),
('3(c)','sets-method','sets-method','gate-sets','非负距离允许平方，消去 xᵀx，不对称点核对方向。','Nonnegative distances permit squaring; cancellation; asymmetric-point check.'),
('4(a)(i)','scalar-curvature','scalar-curvature','scalar-practice','固定 a∈R，逐次求导，a=0 时仍凸。','Fixed real a; both derivatives; convex also at a=0.'),
('4(a)(ii)','scalar-curvature','scalar-curvature','scalar-practice','正定义域，负对数一阶和二阶导。','Positive domain; both derivatives of negative logarithm.'),
('4(a)(iii)','scalar-curvature','scalar-curvature','scalar-practice','乘积法则求一阶导，1/x>0；零点延拓不混入主线。','Product-rule first derivative; positive 1/x; no zero-extension distraction.'),
('4(b)','least-squares-hessian','least-squares-hessian','gate-convex','展开矩阵平方、梯度、Hessian、任意 v 平方和，无满秩假设。','Expand the quadratic, gradient, Hessian and directional squares; no rank assumption.'),
('4(c)','jensen-example','jensen-proof','gate-convex','凸组合封闭性先证；完整归纳、t=1 和零权重。','Finite-combination closure first; full induction, t=1 and zero weights.'),
('5(a)','u11-understand','soc-proof','gate-cone','缩放及四性质；序列估计取极限；显式开球；尖性。','Scaling and four properties; sequence estimate and limit; explicit ball; pointedness.'),
('5(b)','soc-dual-method','soc-dual-method','gate-cone','两向包含；先测 (0,1)，再测反方向；覆盖 y=0、s<0。','Both inclusions; test (0,1), then opposite direction; covers y=0 and s<0.'),
('5(c)','soc-order-method','soc-order-method','gate-cone','代差向量写范数式；三点直接使用三角不等式。','Substitute the difference for the norm relation; direct three-point triangle proof.')]

def apply_units(units):
    units['16']['fig']='geometry-pair';units['22']['fig']='simplex';units['42']['fig']='exp-conjugate'
    units['07']['proof']=[['先验证具体长度 √(4x₁²+x₂²)。令线性变换 T(x)=(2x₁,x₂)，这个长度就是 ‖T(x)‖₂；T(x)=0 只在 x=0 成立，因此正定。T(αx)=αT(x) 给齐次性，T(x+y)=T(x)+T(y) 配合欧氏三角不等式给第三条规则。一般矩阵的证明等第16节准备好平方根后再做。','First verify √(4x₁²+x₂²). For the linear map T(x)=(2x₁,x₂), this is ‖T(x)‖₂. Since T(x)=0 only at x=0, definiteness holds. The identities T(αx)=αT(x) and T(x+y)=T(x)+T(y) transfer homogeneity and the Euclidean triangle inequality. The general matrix proof follows after square roots in unit 16.']]
    units['16']['proof'].append(['P≻0 的平方根 P½ 可逆，且 ‖x‖P=‖P½x‖₂。可逆性排除非零的零长度，线性变换配合欧氏范数的齐次性和三角不等式证明另外两条。这就把第7节的对角例子推广到一般正定矩阵。','For P≻0, its square root P½ is invertible and ‖x‖P=‖P½x‖₂. Invertibility excludes nonzero zero-length vectors; linearity and the Euclidean axioms transfer homogeneity and the triangle inequality. This extends unit 7’s diagonal example to general positive definite matrices.'])
    units['11']['under'].insert(0,['这里连续指输入趋近某点时输出也趋近该点的函数值。例如线性评分 x↦zᵀx 对每个固定 z 连续。开球与序列给出了把“趋近”写精确的方法。','Continuity means that approaching an input point makes outputs approach its function value. Linear scoring x↦zᵀx is continuous for each fixed z. Balls and sequences make the idea of approaching precise.'])
    units['26']['under'][0]=['最小元素不大于集合内每一点。极小元素要求：不存在不同的 y∈S 使 y⪯Kx。例 S={(0,1),(1,0)} 两点都极小，却无最小元素。','A minimum is below every member. A minimal x has no distinct y∈S with y⪯Kx. Both points of {(0,1),(1,0)} are minimal but there is no minimum.']
    units['31']['proof'][0]=['在凸可行集上，严格凸函数若有两个不同最优点，中点仍可行，严格凸定义使其中点费用更低，矛盾。仅得到至多一个，不保证存在。','On a convex feasible set, two distinct minimizers of a strictly convex function would have a feasible midpoint of smaller cost. This proves at most one, not existence.']
    units['42']['deep']=['非空闭凸 C 有 δC*=hC、hC*=δC，因此 δC**=δC、hC**=hC；每次都要区分取共轭的对象。','For nonempty closed convex C, δC*=hC and hC*=δC; hence δC**=δC and hC**=hC. Distinguish the object at every conjugation.']
    units['36']['under']=[x for x in units['36']['under'] if '至此' not in x[0]]
    # Keep general first-order/second-order rules and move advanced matrix tests
    # out of introductory layers after assembly.
    units['33']['under']=[units['33']['under'][0],units['33']['under'][-1]]
    units['46']['under']=[units['46']['under'][0]]
    units['38']['under'].insert(0,['本节的函数族及用于定义支撑函数的集合 C 均取非空；允许上确界为 +∞，并单独讨论有效域。','The function family and support set C here are nonempty. Suprema may be +∞, with the effective domain checked separately.'])
    units['27']['under'][1]=['非空闭凸集 C 外的点 z，可用最近点 p 构造法向 z−p。在这个构造中，连接 p、z 的线段垂直于过 p 的支撑超平面。弱分离则可能允许两个集合共享超平面上的点。','For z outside a nonempty closed convex C, a nearest point p provides normal z−p. In this construction the segment joining p,z is perpendicular to the supporting hyperplane through p. Weak separation can allow the sets to share points on the hyperplane.']

def fragment(s):return BeautifulSoup(s,'html.parser')
def append(node,s):
    for child in list(fragment(s).contents):node.append(child)
def replace_body(node,s):
    for child in list(node.contents):
        if getattr(child,'name',None)!='h3':child.extract()
    append(node,s)

def refine_soup(soup):
    # Existing concise layers are the source for stable paragraph anchors.
    # Preserve those anchors as empty aliases when replacing a teaching block.
    for uid,levels in BLOCKS.items():
        unit=soup.find(id='u'+uid)
        for level,content in levels.items():
            suffix={2:'understand',3:'mastery',4:'depth'}[level]
            target=unit.find(id='u'+uid+'-'+suffix)
            if uid=='10':
                target=fragment('<div class="layer" data-level="'+str(level)+'"><h3>'+bi('了解' if level==2 else '掌握','Understand' if level==2 else 'Mastery')+'</h3></div>').div
                original=unit.find('details',id='u10-original');original.insert_before(target)
                append(target,content)
                continue
            # Advanced material becomes deep; foundational material is replaced.
            full=(uid in ['13','14','42','44'] and level==2) or (uid=='42' and level==4)
            if full:
                aliases=[n['id'] for n in target.select('[id]')]
                oldfigure=target.find('figure',class_='course-figure')
                oldfigure=oldfigure.extract() if oldfigure else None
                replace_body(target,''.join('<span id="'+a+'" class="anchor-alias"></span>' for a in aliases if not (oldfigure and oldfigure.find(id=a)))+content)
                if oldfigure:target.append(oldfigure)
            elif level==3 and uid in ['09','14','21','25','29','30','36','40','47']:
                # Retain old proof anchors and exercise, replace compressed proof.
                for para in target.select('div[id^="u'+uid+'-proof-"]'):para.clear()
                exercise_node=target.find('div',class_='observe')
                if exercise_node:exercise_node.insert_before(fragment(content))
                else:append(target,content)
            else:append(target,content)
    for uid,(z,e) in NOTES.items():
        target=soup.find(id=f'u{uid:02}-understand')
        if target:append(target,p(z,e))
    # Move advanced statements out of introductory proof layers.
    for uid in ['33','42','45','46']:
        target=soup.find(id='u'+uid+'-mastery');deep=soup.find(id='u'+uid+'-depth')
        for para in list(target.select('div[id^="u'+uid+'-proof-"]')):
            if (uid not in ['33','42'] or '−logdet' in para.get_text() or 'logdet' in para.get_text() or 'Schur' in para.get_text()):
                deep.append(para.extract())
    append(soup.find(id='u14-depth'),p('一般二阶链式法则：g:Rⁿ→Rᵏ 为 C²，f:Rᵏ→R 为 C²，则 H(f∘g)=Dgᵀ Hf(g)Dg+Σᵢ(∂f/∂uᵢ)(g) H(gᵢ)。Dg 为 k×n，每项结果均为 n×n。g 仿射时各 H(gᵢ)=0，才简化为 AᵀHf A。','For C² maps g:Rⁿ→Rᵏ and f:Rᵏ→R, H(f∘g)=DgᵀHf(g)Dg+Σᵢ(∂f/∂uᵢ)(g)H(gᵢ). Here Dg is k×n and each resulting term n×n. Only for affine g do the inner Hessians vanish, leaving AᵀHf A.'))
    append(soup.find(id='u42-understand'),p('范数给另一类共轭：‖x‖ 的共轭是对偶单位球 {y:‖y‖*≤1} 的示性函数，½‖x‖² 的共轭是 ½‖y‖*²。正定二次型 ½xᵀPx 的共轭是 ½yᵀP⁻¹y。前提分别是有限维范数与对称正定 P；完整上界及取等证明放在掌握层。','A norm conjugates to the indicator of {y:‖y‖*≤1}; half its square conjugates to ½‖y‖*². A positive quadratic ½xᵀPx conjugates to ½yᵀP⁻¹y. These require a finite-dimensional norm and symmetric positive definite P respectively. Mastery supplies the bound and attainment proof.'))
    append(soup.find(id='u42-mastery'),exercise('conjugate-practice','从定义计算 e²ˣ 与 −log(3x)（x>0）的共轭，检查 y=0；再算 C=[−2,2] 的支撑函数及它的共轭。','From the definition conjugate exp(2x) and −log(3x) on x>0, including y=0. Then find the support of C=[−2,2] and its conjugate.',p('指数令 u=2x；负对数先分离常数；支撑函数在区间端点取最大。','For the exponential set u=2x; separate the constant in the logarithm; maximize support at an interval endpoint.'),p('yx−e²ˣ=(y/2)u−eᵘ。−log(3x)=−log x−log 3，共轭目标多出 log 3。','The exponential objective becomes (y/2)u−exp(u). The logarithm objective gains constant log 3.'),p('指数共轭在 y>0 为 (y/2)log(y/2)−y/2，由 x=½log(y/2) 取得；y=0 值 0 不取得；y<0 为 +∞。负对数共轭在 y<0 为 −1−log(−y)+log 3，x=−1/y 取得；y≥0 无界。hC(y)=2|y|，其共轭在 |x|≤2 为 0，外部为 +∞；区间内 y=0 取等，外部沿同号 y 放大。','The exponential conjugate is (y/2)log(y/2)−y/2 for y>0, attained at x=½log(y/2); at 0 it is an unattained 0; for y<0 it is +∞. The logarithm conjugate is −1−log(−y)+log 3 for y<0 at x=−1/y, and unbounded for y≥0. Support is 2|y|, whose conjugate is 0 for |x|≤2 and +∞ outside. Inside choose y=0; outside scale a same-sign y.'),'conjugate-exponential'))
    append(soup.find(id='u42-mastery'),h('quadratic-conjugate-proof','保留 ½ 系数的矩阵配方','Matrix completion of squares with the factor ½')+p('P∈Sⁿ 且 P≻0，定义域为 Rⁿ，固定 y∈Rⁿ。下面的平方项非负，所以给所有 x 的统一上界；取 x=P⁻¹y 时消掉平方项，因此每个 y 都取得有限共轭。','For P∈Sⁿ, P≻0 and domain Rⁿ, fix y∈Rⁿ. The nonnegative square below gives a bound for every x. Choosing x=P⁻¹y eliminates it, so every y has a finite attained conjugate.')+m(r'y^Tx-\tfrac12x^TPx=\tfrac12y^TP^{-1}y-\tfrac12(x-P^{-1}y)^TP(x-P^{-1}y)\le\tfrac12y^TP^{-1}y.'))
    append(soup.find(id='u44-depth'),p('保拟凸运算可从下水平集复核：上确界对应各下水平集的交；非减标量复合通过门槛的原像；仿射原像保持凸；正分母线性分式固定门槛后是半空间条件。联合拟凸 f(x,y) 在凸约束中对 y 取下确界也拟凸，可用 ε-近似点和最大值型混合不等式证明。非负加法一般不保持拟凸，不能仿照凸函数的加和规则。','Quasiconvex preservation follows from sublevel sets: a supremum gives intersections; nondecreasing composition transfers thresholds; affine preimages retain convexity; positive-denominator linear fractions give halfspace thresholds. Partial minimization of jointly quasiconvex f over a convex set is also quasiconvex, using ε-approximate points and the maximum-type mixture bound. Nonnegative sums generally fail to preserve quasiconvexity.'))
    append(soup.find(id='u44-mastery'),exercise('bisection-practice','沿正文分式例子，从区间 [1/4,1/2] 再二分一次；若 ε=1/16，还需要将初始宽度 1/2 减半几次？','Continue the fractional example with interval [1/4,1/2] for one more bisection. For ε=1/16, how many halvings of initial width 1/2 are required?',p('门槛是当前两端平均；检查线性不等式是否有 x∈[0,2] 满足。','Average the endpoints; test whether the resulting linear inequality has a solution in [0,2].'),p('门槛为 3/8，右端 2α−1 为 −1/4。','The threshold is 3/8 and 2α−1=−1/4.'),p('得到 (5/8)x≤−1/4，与 x≥0 矛盾，故新区间 [3/8,1/2]。从初始宽度 1/2 经过三次减半到 1/16；满足停止条件的上界来自保存的可行点 x=0，目标为 1/2。','The constraint (5/8)x≤−1/4 is impossible for x≥0, giving [3/8,1/2]. Three halvings reduce initial width 1/2 to 1/16. The feasible upper bound is retained at x=0 with value 1/2.'),'quasi-bisection'))
    # Explicit regularity for generalized first/second-order criteria.
    append(soup.find(id='u46-depth'),p('本节广义一阶判据要求开放凸定义域及可微性，二阶判据要求 C²；K 为正常锥。每个方向 v 的 D²f(x)[v,v] 是输出向量，须属于 K。','Generalized first-order tests here require an open convex domain and differentiability; second-order tests require C². K is proper. Each D²f(x)[v,v] is an output vector and must belong to K.'))
    # Preserve important non-core topics that no longer interrupt first study.
    append(soup.find(id='u46-depth'),p('复合拓展：X、B 为 m×n，A 为 m×m 对称半正定，C 为 n×n 对称矩阵。g(X)=XᵀAX+BᵀX+XᵀB+C 是 PSD 序凸函数，其混合差为 θ(1−θ)(X−Y)ᵀA(X−Y)⪰0。外层 h(Y)=−logdet(−Y) 在 Y≺0 凸且 PSD 序非减，因此 h(g(X)) 在 g(X)≺0 的凸域上凸。','Extension: X,B are m×n, A is m×m symmetric PSD and C is n×n symmetric. The map g(X)=XᵀAX+BᵀX+XᵀB+C is PSD-order convex, with gap θ(1−θ)(X−Y)ᵀA(X−Y)⪰0. The outer h(Y)=−logdet(−Y) is convex and PSD-order nondecreasing on Y≺0; hence h(g(X)) is convex on its convex domain g(X)≺0.'))
    append(soup.find(id='u18-depth'),p('奇异 Schur 补完整条件：M⪰0 当且仅当 A⪰0、(I−AA†)B=0、C−BᵀA†B⪰0。例 A=diag(1,0)、B=(1,0)ᵀ、C=2，补为 1，整体 PSD；若 B=(0,1)ᵀ，值域条件失败，即使形式上的补非负也不能判 PSD。依据：教材 A.5.5。','For singular A, M⪰0 iff A⪰0, (I−AA†)B=0 and C−BᵀA†B⪰0. For A=diag(1,0), B=(1,0)ᵀ, C=2, the complement is 1 and the block is PSD. With B=(0,1)ᵀ range compatibility fails, so a nonnegative formal complement is insufficient. See A.5.5.'))
    append(soup.find(id='u45-depth'),p('高斯例中 φ(x)=e⁻ˣ²ᐟ²/√(2π)，Φ(x)=∫₋∞ˣφ(u)du，r=φ/Φ>0；前面的估计用于证明 x+r(x)>0。Gamma 的积分域为 u>0、参数 x>0，Hölder 不等式给 Γ(θa+(1−θ)b)≤Γ(a)^θΓ(b)^(1−θ)，端点权重直接取等，故对数凸。det/tr 的迹估计可写成 |tr H|=|tr(XW)|≤√tr(X²)√tr(W²)≤tr(X)√tr(W²)，代回即得非正曲率。上述内容为拓展，教材 §3.5 及练习 3.49、3.52、3.54。','In the Gaussian example φ(x)=exp(−x²/2)/√(2π), Φ(x)=∫₋∞ˣφ(u)du and r=φ/Φ>0; the preceding estimate proves x+r(x)>0. For Gamma, u>0 and parameter x>0; Hölder gives Γ(θa+(1−θ)b)≤Γ(a)^θΓ(b)^(1−θ), with endpoint weights giving equality. For det/tr, |tr H|=|tr(XW)|≤√tr(X²)√tr(W²)≤tr(X)√tr(W²), yielding the claimed nonpositive curvature. These are extensions; see §3.5 and exercises 3.49,3.52,3.54.'))
    # A short proof guide precedes the new route and the use of abstract symbols.
    guide=soup.find(id='guide-text');append(guide,PRELUDE)
    guide.insert(1,fragment(p('<a href="hw1-route.html#guide">首次自学／Homework 1 连续路线</a> · <a href="#homework">逐小问回查</a> · <a href="#u41">进阶拓展入口</a>','<a href="hw1-route.html#guide">First study / continuous HW1 route</a> · <a href="#homework">Subquestion lookup</a> · <a href="#u41">Advanced reading</a>')))
    append(guide,p('首次自学先看建模与最小二乘的具体例子，再从连续路线进入六组基础；读“了解”层及对应“掌握”证明和关卡。作业回查用下方 17 项表。继续学习再回到本页其余单元；SVD、奇异 Schur 补、矩阵幂和特殊函数不列入本次作业门槛。','For first study, start with the modeling and least-squares examples, then follow the continuous six-stage route. Read Understand plus the relevant Mastery proofs and gates. Use the 17-item table for lookup. Return to the remaining units afterward; SVD, singular Schur complements, matrix powers and special functions are outside the HW1 requirements.'))
    # Each existing core exercise gets independently accessible levels of help.
    methods={range(1,6):('先分清变量、可行性和费用；用一个统一界比较所有候选。','Separate variables, feasibility and costs; compare all candidates with a uniform bound.'),range(6,19):('先写维数与定义，再决定用上界、取等、二次型还是求导。','Write dimensions and definitions, then choose a bound, attainment, quadratic form or differentiation.'),range(19,31):('取任意两点和任意混合权重，把集合条件代入；集合相等须两向。','Choose arbitrary points and a weight, substitute the membership condition; equality of sets needs both inclusions.'),range(31,48):('先查定义域，再选择定义、导数或保持规则；不满足前提时用反例。','Check the domain, then choose the definition, derivatives or preservation rules. Test a counterexample if assumptions fail.')}
    for uid in range(1,48):
        if uid==10:continue
        ans=soup.find(id=f'u{uid:02}-answer');obs=ans.parent
        for group,hint in methods.items():
            if uid in group:break
        ans.insert_before(fragment(d(f'u{uid:02}-hint','思路提示','Hint',p(*hint))))
        step=soup.find(id=f'u{uid:02}-mastery').find('p')
        step_text=str(step) if step else p('把问题写成定义中的不等式，检查特殊情况后收尾。','Write the inequality in the definition, check special cases and conclude.')
        special={33:('要反驳半正定，只需找一个二次型为负的方向；尝试两个分量异号，使交叉项变负。','To refute PSD, find one negative quadratic form. Try opposite-sign entries to make the cross term negative.'),42:('固定 y 后对 yx−2x² 配方；指数的零斜率则直接查看 −eˣ 是否能等于 0。','At fixed y complete the square in yx−2x². At zero exponential slope, ask whether −exp(x) can equal 0.'),45:('先写 log f=log x，再计算其一阶导1/x，最后判二阶导符号。','Write log f=log x, calculate first derivative 1/x, then inspect its second derivative.'),46:('正交象限序把向量凸性分成每个分量的凸性；再用非负权重做标量加和。','Orthant order reduces convexity to each component; then form a nonnegative weighted scalar sum.')}
        if uid in special:step_text=p(*special[uid])
        ans.insert_before(fragment(d(f'u{uid:02}-steps','关键步骤','Key steps',step_text)))
    scalar=exercise('scalar-practice','用二阶导判定 e⁻²ˣ（实轴）、−log(2x) 与 (2x)log(2x)（x>0）的凸性。把指数参数改为 0 呢？','Use second derivatives to classify exp(−2x) on R and −log(2x), (2x)log(2x) on x>0. What if the exponential parameter is 0?',p('每次先标明内层的导数；不要省略一阶导。','Keep the derivative of each inner function; write the first derivative as well.'),p('链式法则会带来系数 2；log(2x)=log 2+log x 可核对。','Chain rules contribute factors of 2; use log(2x)=log 2+log x as a check.'),m(r'\begin{array}{c|c|c}f&f^\prime&f^{\prime\prime}\\\hline e^{-2x}&-2e^{-2x}&4e^{-2x}>0\\-\log(2x)&-1/x&1/x^2>0\\2x\log(2x)&2\log(2x)+2&2/x>0\end{array}')+p('三者在各自开放凸域上凸，且严格凸；指数参数为 0 时常数函数仍凸。正定义域保证 log 合法且 1/x 为正。','All are strictly convex on their respective open convex domains. Parameter 0 gives a constant exponential, still convex. The positive domains make log legitimate and 1/x positive.'),'scalar-curvature')
    append(soup.find(id='u33-mastery'),scalar)
    for uid,gate in GATES.items():
        target=soup.find(id='u'+uid+'-mastery')
        if uid=='10':target=soup.find(id='quadratic-proof').parent
        append(target,gate)
    # Full content evidence replaces the previous broad coverage assertion.
    hw=soup.find(id='homework-route');replace_body(hw,coverage_html())
    for uid,z,e in [('05','本讲自检：能否分别给出不可行、无下界和不取得的例子？证明最优时，为什么必须同时检查可行性与全体费用下界？','Lecture check: give examples of infeasibility, unboundedness and nonattainment. Why must optimality check feasibility and a bound for every feasible cost?'),('18','本讲自检：面对长度最大化用哪种范数？哪些问题要构造取等方向，哪些要检查全部零方向？逆矩阵公式的哪条前提最容易漏掉？','Lecture check: which norm describes each length question? When do you construct an attaining direction or characterize all null directions? Which assumption permits an inverse?'),('30','本讲自检：能否从任意两点开始证明球凸？能否用两个包含证明自对偶？极小与弱极小的差别是什么？','Lecture check: prove ball convexity from arbitrary points and self-duality by both inclusions. How do minimal and weakly minimal differ?'),('40','本讲自检：何时用定义，何时用 Hessian 或复合规则？凸性、严格凸、取得最优分别需要什么？Jensen 的归纳在哪里避免除零？','Lecture check: when should you use the definition, Hessian or composition? Distinguish convexity, strict convexity and attainment. Where does Jensen induction avoid division by zero?'),('47','本讲自检：固定 y 后共轭究竟优化哪个变量？值有限是否等于取得？矩阵输出用什么序比较？','Lecture check: which variable is optimized in a conjugate at fixed y? Does finiteness mean attainment? Which order compares matrix outputs?')]:
        append(soup.find(id='u'+uid),d('lecture-check-'+uid,'本讲自检','Lecture self-check',p(z,e)+p('用本讲已给出的例子逐项作答；对不确定的一项，重新写出该定义或证明，而后再继续。','Answer using this lecture’s examples. For an uncertain item, rewrite its definition or proof before proceeding.')))
    # Real slider coordinate is r; algorithm is unchanged.
    sweep=soup.find(id='sweep');label=sweep.find_parent('label')
    for language,z in [('zh','相对位置 r=c/‖z‖*'),('en','Relative position r=c/‖z‖*')]:
        t=label.find(class_=language)
        if t:t.string=z
    instructions=p('滑块控制 r=c/‖z‖*，范围 '+sweep['min']+' 至 '+sweep['max']+'。绿色线为 zᵀx=c；r=0 过原点，r=1 到达红色支撑线，r=−1 是另一侧支撑线，|r|>1 时越过单位球。45° 时依次选择 ℓ₁、ℓ₂、ℓ∞：对偶值分别为 1/√2、1、√2。ℓ₁ 在两分量绝对值并列最大时有整条最优边；ℓ∞ 在 z 某分量为零时有整条最优边，红点仅选择其中一个。','The slider controls r=c/‖z‖*, from '+sweep['min']+' to '+sweep['max']+'. Green shows zᵀx=c: r=0 passes through the origin, r=1 reaches the red support, r=−1 supports the opposite side, and |r|>1 passes beyond the ball. At 45°, ℓ₁,ℓ₂,ℓ∞ give dual values 1/√2,1,√2. The ℓ₁ ball has an optimal edge when maximal magnitudes tie; ℓ∞ has one when a z component is zero. The red point selects one maximizer.')
    exp=sweep.find_parent(class_='experiment');append(exp,instructions)
    # A public report is directly accessible even without running its scripts.
    append(soup.find(id='source-info'),p('<a href="revision-report.md">本次修改与验收</a> · <a href="hw1-coverage.md">17 项作业证据表</a> · <a href="lecture-source.zip">下载可维护源文件</a>','<a href="revision-report.md">Revision and acceptance report</a> · <a href="hw1-coverage.md">17-item HW1 evidence</a> · <a href="lecture-source.zip">Download editable sources</a>'))

def coverage_html():
    result=p('这张表核对讲义是否提供方法、完整示范和训练。它不以阅读进度代替你独立写出证明。4(a) 三个函数原题合计 9 分，没有单独分值。','This table audits methods, worked arguments and practice in the handbook. Reading progress cannot replace an independently written proof. The three functions in 4(a) share 9 points in the original; no individual allocation was specified.')
    result+='<p><a href="hw1-route.html#guide">'+bi('进入六阶段连续路线','Open the continuous six-stage route')+'</a></p>'
    result+='<div class="table-wrap"><table><thead><tr><th>HW1</th><th>'+bi('正文 / 完整算例 / 独立练习','Method / worked example / practice')+'</th><th>'+bi('核验依据','Evidence checked')+'</th></tr></thead><tbody>'
    for item,body,example,train,z,e in EVIDENCE:
        links=' · '.join('<a href="#'+i+'">'+bi(a,b)+'</a>' for i,a,b in [(body,'正文','Method'),(example,'示范','Worked'),(train,'训练','Practice')])
        result+='<tr><td>'+item+'</td><td>'+links+'</td><td>'+bi(z,e)+'</td></tr>'
    result+='</tbody></table></div>'
    result+=h('proof-templates','五种证明组织方式','Five proof-writing patterns')
    for z,e in [('范数公式：任意对象的统一上界 → 构造可行取等对象 → 核对约束与评分 → 单列零情形。','Norm formula: uniform bound for arbitrary inputs → construct an attaining feasible input → check budget and reward → handle zero cases.'),('集合凸性：任意两点与权重 → 混合点 → 验证成员条件 → 用任意性收尾。','Set convexity: arbitrary points and weight → mixture → verify membership → conclude by arbitrariness.'),('半正定：任意方向 v → 二次型 → 非负平方和 → 对所有 v 成立；取零方向继续分析每项等号。','PSD: arbitrary v → quadratic form → nonnegative squares → conclude for all v; analyze every equality for null directions.'),('集合相等：分别证明两个包含；反向可以选测试对象排除不合格候选。','Set equality: prove each inclusion; in reverse choose test objects to exclude invalid candidates.'),('归纳法：基础情形 → 明确归纳假设 → 单列端点 → 归一化分组 → 使用定义与假设 → 恢复原式。','Induction: base case → precise induction hypothesis → endpoints → normalized grouping → definition and hypothesis → restore the expression.')]:result+=p(z,e)
    return result

def make_route(path):
    soup=BeautifulSoup(path.read_text(encoding='utf8'),'html.parser');main=soup.main;nav=soup.nav
    soup.title.string='凸优化 · Homework 1 连续学习路线'
    for n,uid in zip(list(main.select('.lecture-heading')),['01','06','19','31','41']):
        alias=fragment('<span id="'+n['id']+'" class="anchor-alias"></span>').span
        main.find(id='u'+uid).insert(0,alias)
        n.decompose()
    units={n['data-unit']:n.extract() for n in main.select('section[data-unit]')}
    guide=main.find(id='guide');cursor=guide
    nav.clear();append(nav,'<a href="#guide">'+bi('路线与证明入门','Route and proof basics')+'</a>')
    core=[]
    for ident,z,e,ids in STAGES:
        stage=fragment('<div class="lecture-heading" id="'+ident+'"><h2>'+bi(z,e)+'</h2></div>').div
        cursor.insert_after(stage);cursor=stage
        append(nav,'<p class="nav-group">'+bi(z,e)+'</p>')
        for uid in ids:
            cursor.insert_after(units[uid]);cursor=units[uid];core.append(uid)
            append(nav,'<a href="#u'+uid+'">'+units[uid].h2.decode_contents()+'</a>')
    end=fragment('<div id="hw1-ready" class="route-finish" data-anchor="hw1-ready">'+p('至此已具备完成 Homework 1 的知识与证明工具，可先独立尝试作业；后续内容用于继续学习。','The required knowledge and proof tools for HW1 have now been taught. Attempt it independently; the remaining content supports further study.')+p('先完成五个关卡，并能合上答案复写证明。此提示表示教学范围结束，不能替代你的能力自检。','Complete the five gates and rewrite the arguments with answers closed. This marker indicates the end of the teaching scope, not proof of your mastery.')+'</div>').div
    cursor.insert_after(end);cursor=end
    restheading=fragment('<div class="lecture-heading" id="route-more"><h2>'+bi('继续学习：建模、保持规则与拓展','Continue: modeling, preservation and extensions')+'</h2></div>').div
    cursor.insert_after(restheading);cursor=restheading
    append(nav,'<p class="nav-group">'+bi('继续学习','Further study')+'</p>')
    for uid in sorted(units):
        if uid in core:continue
        cursor.insert_after(units[uid]);cursor=units[uid]
        append(nav,'<a href="#u'+uid+'">'+units[uid].h2.decode_contents()+'</a>')
    for ident,z,e in [('homework','17 项作业回查','17-item HW1 lookup'),('glossary','名词对照','Glossary'),('source-map','课件来源','Sources')]:append(nav,'<a href="#'+ident+'">'+bi(z,e)+'</a>')
    # Separate progress memories for the alternative physical reading order.
    for script in soup.find_all('script'):
        if script.string and "KEY='convex-complete-1-5-v1'" in script.string:script.string=script.string.replace("KEY='convex-complete-1-5-v1'","KEY='convex-hw1-route-v1'")
    soup.find('h1').clear();append(soup.find('h1'),bi('Homework 1 · 连续学习路线','Homework 1 · A continuous learning route'))
    (path.parent/'hw1-route.html').write_text(str(soup),encoding='utf8')

def write_coverage(path):
    text='# Homework 1：17 项证据表\n\n本地 hw1.pdf 两页已读取；4(a) 三函数合计9分，未虚构逐项分值。正文推导及变式训练均实际存在。读者能力仍需独立作答检验。\n\n|检查项|正文|完整示范|训练|核验依据|\n|---|---|---|---|---|\n'
    for item,body,ex,train,z,e in EVIDENCE:
        text+='|'+item+'|'+f'[正文](index.html#{body})|[示范](index.html#{ex})|[训练](index.html#{train})|'+z+'|\n'
    path.write_text(text,encoding='utf8')
