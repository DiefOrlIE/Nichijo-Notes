from pathlib import Path
import json,re,html,base64,io,hashlib,os
from bs4 import BeautifulSoup,NavigableString
from fontTools.ttLib import TTFont
from fontTools.varLib.instancer import instantiateVariableFont
from fontTools import subset
import fitz
from course_content import UNITS
import course_background,course_sets,course_functions,course_extensions
import course_supplements
from least_squares_rewrite import rewrite as rewrite_least_squares
rewrite_least_squares(UNITS)
from concise_revision import apply as apply_concise,apply_sample
apply_concise(UNITS)
from task_revision import apply_units,refine_soup,make_route,write_coverage
apply_units(UNITS)
from course_figures import figure,CAPTIONS
from concise_captions import CAPTIONS as CONCISE_CAPTIONS
CAPTIONS.update(CONCISE_CAPTIONS)
from refinement_figures import CAPTIONS as REVISED_CAPTIONS
CAPTIONS.update(REVISED_CAPTIONS)
from course_ui import simplify_headings,UI_CSS,apply_to_existing
R=Path(__file__).parent;OUT=R/'完整讲义';OUT.mkdir(exist_ok=True)
MAP=json.loads((R/'内容地图.json').read_text(encoding='utf8'))
assert len(UNITS)==47
sample=(R/'对偶范数_双语样章.html').read_text(encoding='utf8')
sample_soup=BeautifulSoup(sample,'html.parser')
apply_sample(sample_soup)
TERMS=json.loads(re.search(r'const TERMS=(.*?);const TERM_NOTES=',sample).group(1))
NOTES=json.loads(re.search(r'const TERM_NOTES=(.*?);</script>',sample).group(1))
for k,t in TERMS.items():t[5]='dual-'+t[5]
def bi(z,e):return '<span class="zh" lang="zh-CN">'+z+'</span><span class="en" lang="en">'+e+'</span>'
def m(tex):return '<div class="math display" data-tex="'+html.escape(tex,quote=True)+'"></div>'
def p(pair):return '<p>'+bi(html.escape(pair[0]),html.escape(pair[1]))+'</p>'
def layer(id,n,title,content):return f'<div class="layer" data-level="{n}" id="{id}" data-anchor="{id}"><h3>'+bi(*title)+' <small class="new">'+bi('当前层新增','Added at this level')+'</small></h3>'+content+'</div>'
def detail(id,z,e,content):return f'<details id="{id}"><summary>'+bi(z,e)+'</summary>'+content+'</details>'
def term(key):return '<button class="term" data-term="'+key+'">'+bi(TERMS[key][0],TERMS[key][1])+'</button>'
def paragraphs(pairs,anchor,start=0):
    return ''.join(f'<div id="{anchor}-{i}" data-anchor="{anchor}-{i}">'+p(pair)+'</div>' for i,pair in enumerate(pairs,start))

# Definitions and examples are full sentences, and every glossary item links to its first explanation.
EXTRA=[
('feasible','可行点','feasible point','x',1,'满足模型全部约束的决策。','A decision satisfying every constraint in the model.','食品例子 (2,0) 提供 4 单位蛋白质，是可行点。','Food quantities (2,0) supply four protein units and are feasible.'),
('optimal','最优值','optimal value','p*',1,'目标在可行集上的下确界；可能不被任何点取得。','The infimum of the objective on its feasible set, potentially unattained.','在 x>0 上最小化 x，最优值为 0，却无最优点。','Minimizing x over x>0 has value zero but no optimizer.'),
('ls','最小二乘','least squares','LS',2,'通过最小化残差平方和估计参数。','Parameter estimation by minimizing the sum of squared residuals.','用一个常数拟合 1、2、6，最佳常数为 3。','The best constant fit to 1,2,6 is three.'),
('normal','正规方程','normal equations','AᵀAx=Aᵀb',2,'最小二乘的一阶条件，要求残差与列空间正交。','Least-squares first-order equations requiring orthogonality of the residual to the column space.','常数拟合中，正规方程为 3x=9。','For the constant fit, the equation is 3x=9.'),
('lp','线性规划','linear programming','LP',3,'目标与约束均为仿射表达式的优化模型。','An optimization model with affine objective and constraints.','min t, t≥2x+1, t≥−x+4 是线性规划。','Minimize t subject to t≥2x+1 and t≥−x+4 is an LP.'),
('local','局部极小点','local minimizer','x*',5,'在某个邻域的全部可行点中具有最小目标值的点。','A point minimizing the objective among feasible points in some neighborhood.','(x²−1)² 的 ±1 都是局部极小点。','Both ±1 are local minima of (x²−1)².'),
('induced','诱导范数','induced norm','‖A‖',9,'给定输入输出范数后，矩阵的最大长度放大率。','The largest length amplification of a matrix under specified input and output norms.','diag(3,2) 的欧氏诱导范数为 3。','The Euclidean induced norm of diag(3,2) is three.'),
('interior','内点','interior point','int C',11,'有一个完全包含在集合内的开放邻域的点。','A point possessing an open neighborhood wholly contained in the set.','1/2 是 (0,1] 的内点，1 却不是。','One half is interior to (0,1], while one is not.'),
('closed','闭集','closed set','cl C=C',11,'包含其所有收敛序列极限的集合。','A set containing limits of all its convergent sequences.','[0,1] 闭；(0,1] 缺少极限点 0，非闭。','[0,1] is closed; (0,1] omits limit point zero.'),
('relative','相对内部','relative interior','ri C',11,'在集合仿射包中计算的内部。','The interior taken within the set’s affine hull.','平面中一条直线没有普通内点，但每一点都在其相对内部。','A line in a plane has empty interior but equals its relative interior.'),
('domain','定义域','domain','dom f',12,'函数可以有限求值的输入集合。','The set of inputs where the function has a finite value.','−log x 的实数定义域为 x>0。','The real domain of −log x is x>0.'),
('gradient','梯度','gradient','∇f',13,'标量函数一阶偏导组成的列向量，配对方向给一阶变化。','The column of first partial derivatives, pairing with a direction to give first-order change.','x₁²+3x₂² 在 (1,2) 处梯度为 (2,12)。','The gradient of x₁²+3x₂² at (1,2) is (2,12).'),
('jacobian','Jacobian','Jacobian matrix','Df / J',13,'向量函数一阶偏导构成的矩阵，行对应输出、列对应输入。','The matrix of first derivatives, with output rows and input columns.','g(x)=Ax+b 的 Jacobian 是 A。','The Jacobian of Ax+b is A.'),
('lse','log-sum-exp','log-sum-exp','LSE',13,'先对输入取指数求和，再取对数的平滑凸函数。','A smooth convex function taking the logarithm of a sum of exponentials.','log(eˣ+e⁻ˣ) 在 0 处梯度为 0、曲率为 1。','Log(eˣ+e⁻ˣ) has derivative zero and curvature one at zero.'),
('hessian','Hessian','Hessian matrix','∇²f',14,'标量函数二阶偏导矩阵，其二次型给方向曲率。','The matrix of second partial derivatives, whose quadratic form gives directional curvature.','x₁²+3x₂² 的 Hessian 为 diag(2,6)。','The Hessian of x₁²+3x₂² is diag(2,6).'),
('covariance','协方差','covariance','Σ',14,'用均值中心化后，计算向量外积的加权平均，记录方向波动。','A weighted average of outer products after mean centering, recording directional variation.','等权系数 1、−1 的均值为 0，方差为 1。','Equal-weight values 1 and −1 have mean zero and variance one.'),
('range','值域','range','R(A)',15,'矩阵作用于所有输入时可到达的输出集合。','The set of outputs reachable by applying a matrix to all inputs.','diag(1,0) 的值域是水平轴。','The range of diag(1,0) is the horizontal axis.'),
('null','零空间','nullspace','N(A)',15,'被矩阵映为零的全部输入构成的子空间。','The subspace of inputs mapped to zero.','diag(1,0) 的零空间是竖直轴。','The nullspace of diag(1,0) is the vertical axis.'),
('eigen','特征值','eigenvalue','λ',16,'满足 Av=λv 的方向缩放系数，其中 v 非零。','A directional scale factor satisfying Av=λv for a nonzero vector v.','diag(3,1) 的特征值为 3、1。','The eigenvalues of diag(3,1) are three and one.'),
('pinverse','伪逆','pseudoinverse','A†',17,'通过 SVD 反转非零奇异值并保留零方向为零的矩阵。','The matrix obtained from SVD by inverting nonzero singular values and retaining zeros.','diag(2,0) 的伪逆为 diag(1/2,0)。','The pseudoinverse of diag(2,0) is diag(1/2,0).'),
('schur','Schur 补','Schur complement','C−BᵀA⁻¹B',18,'正定块消元或配方后留下的对称块。','The symmetric block remaining after eliminating a positive definite block.','[[2,1],[1,c]] 对块 2 的 Schur 补为 c−1/2。','For [[2,1],[1,c]], eliminating two leaves c−1/2.'),
('affine','仿射集','affine set','aff C',19,'包含任意两点所在整条直线的集合。','A set containing the whole line through every pair of its points.','x₁+x₂=1 是仿射集，却不是线性子空间。','The set x₁+x₂=1 is affine but not a linear subspace.'),
('convexset','凸集','convex set','C',20,'包含任意两点间线段的集合。','A set containing the segment between every pair of its points.','闭圆盘凸，只有圆周的集合一般不凸。','A closed disk is convex; its circumference alone is not.'),
('hull','凸包','convex hull','conv C',20,'包含原集合的最小凸集，由所有有限凸组合构成。','The smallest convex set containing the original set, consisting of all finite convex combinations.','三个不共线点的凸包是填满的三角形。','Three noncollinear points have a filled triangle as their hull.'),
('hyperplane','超平面','hyperplane','aᵀx=b',21,'非零法向给出的一个仿射等式集合。','An affine equality set defined by a nonzero normal.','二维中 x₁=1 是一条竖直直线。','In two dimensions, x₁=1 is a vertical line.'),
('halfspace','半空间','halfspace','aᵀx≤b',21,'超平面的一侧，闭半空间包括边界。','One side of a hyperplane; a closed halfspace includes its boundary.','x₁≤1 包括直线 x₁=1 及其左侧。','The halfspace x₁≤1 includes the line and its left side.'),
('polyhedron','多面体','polyhedron','Gx≤h',22,'有限个半空间与超平面的交，可以无界。','An intersection of finitely many halfspaces and hyperplanes, possibly unbounded.','第一象限是无界多面体。','The first orthant is an unbounded polyhedron.'),
('simplex','单纯形','simplex','Δ',22,'仿射独立顶点的凸包，标准形式记录非负且和为 1 的权重。','The hull of affinely independent vertices; the standard form represents nonnegative weights summing to one.','三项概率构成二维三角形单纯形。','Three probabilities form a two-dimensional triangular simplex.'),
('preimage','原像','preimage','f⁻¹(C)',23,'输出落入指定集合的全部输入，不要求映射可逆。','All inputs whose outputs belong to a specified set, without requiring invertibility.','{x:‖Ax‖≤1} 是球在 A 下的原像。','The set {x:‖Ax‖≤1} is a ball preimage under A.'),
('perspective','透视映射','perspective map','z/t',24,'在正高度 t 上把水平坐标除以 t 的映射。','The map dividing horizontal coordinates by positive height t.','点 (2,2) 映到水平坐标 1。','Point (2,2) maps to horizontal coordinate one.'),
('propercone','正常锥','proper cone','K',25,'闭、凸、尖且内部非空的锥，可定义偏序。','A closed convex pointed cone with nonempty interior, suitable for defining a partial order.','非负正交象限和二阶锥都是正常锥。','The nonnegative orthant and SOC are proper cones.'),
('pointed','尖性','pointedness','K∩(−K)={0}',25,'锥不包含任何经过原点的非零双向直线。','The absence of any nonzero two-sided line through the origin in a cone.','水平轴不是尖锥，非负水平射线是尖锥。','A horizontal axis is not pointed, but its nonnegative ray is.'),
('minimum','最小元素','minimum element','min',26,'按选定偏序不大于集合全部元素的点。','A point below every element under the chosen order.','加入 (0,0) 后，它是非负点集的最小元素。','Adding (0,0) makes it a minimum of a nonnegative point set.'),
('minimal','极小元素','minimal element','Pareto',26,'没有另一个不同元素按偏序不大于它的点。','A point with no distinct element below it under the order.','(0,1)、(1,0) 都极小，却没有最小元素。','Both (0,1) and (1,0) are minimal, but neither is a minimum.'),
('separating','分离超平面','separating hyperplane','aᵀx=b',27,'将两个集合置于相反两侧的超平面，弱分离允许边界取等。','A hyperplane placing two sets on opposite sides, with boundary equality allowed in weak separation.','x₁=0 分离中心在 ±2 的两个单位圆盘。','The line x₁=0 separates unit disks centered at ±2.'),
('supporting','支撑超平面','supporting hyperplane','aᵀx≤aᵀx₀',28,'通过边界点并将整个集合留在同一侧的超平面。','A hyperplane through a boundary point with the entire set on one side.','x₁=1 支撑单位圆盘于 (1,0)。','The line x₁=1 supports the unit disk at (1,0).'),
('dualcone','对偶锥','dual cone','K*',29,'与原锥所有点内积非负的向量组成的锥。','The cone of vectors pairing nonnegatively with every primal-cone point.','二阶锥在标准内积下等于自己的对偶锥。','The SOC equals its dual under standard inner product.'),
('pareto','Pareto 前沿','Pareto frontier','f(x)',30,'多目标比较下未被其他方案支配的目标点集合。','The set of objective points undominated by other plans.','(1,4) 与 (4,1) 表示费用和误差之间的权衡。','The points (1,4) and (4,1) trade off cost and error.'),
('convexfunction','凸函数','convex function','f',31,'在凸定义域上，混合输入的函数值不超过输出的加权平均。','A function on a convex domain whose mixture value is at most the weighted average of endpoint values.','x² 在任意两点之间都不超过弦。','The curve x² lies below every chord.'),
('indicator','凸示性函数','convex indicator function','δC',31,'在集合内取 0，在集合外取 +∞，用来编码约束。','A function equal to zero inside a set and +∞ outside, encoding a constraint.','δ[0,1](1/2)=0，δ[0,1](2)=+∞。','For [0,1], the indicator is zero at one half and +∞ at two.'),
('subgradient','次梯度','subgradient','∂f',32,'给出全局仿射下界的斜率，适用于不可微凸函数。','A slope defining a global affine lower bound, including at nondifferentiable convex points.','|x| 在 0 的次梯度集合为 [−1,1]。','The subgradient set of |x| at zero is [−1,1].'),
('epigraph','上图集','epigraph','epi f',34,'包含函数图像及上方所有点的集合。','The set consisting of the graph and all points above it.','x² 的上图集为 {(x,t):t≥x²}。','The epigraph of x² is {(x,t):t≥x²}.'),
('sublevel','次水平集','sublevel set','f≤α',34,'函数值不超过固定门槛的输入集合。','The inputs whose function values are no greater than a fixed threshold.','x² 的 4 次水平集为 [−2,2]。','The four-sublevel of x² is [−2,2].'),
('lmi','线性矩阵不等式','Linear Matrix Inequality','LMI',35,'变量以仿射方式出现在对称矩阵中，并要求该矩阵半正定。','A PSD constraint on a symmetric matrix depending affinely on the variables.','[[y,x],[x,4]]⪰0 是关于 x、y 的 LMI。','The constraint [[y,x],[x,4]]⪰0 is an LMI in x and y.'),
('jensen','Jensen 不等式','Jensen inequality','f(E X)≤E f(X)',36,'凸函数在平均输入处的值不超过输出的平均。','Evaluation of a convex function at an average is no greater than averaging its values.','1、3 的均值平方为 4，平方均值为 5。','For one and three, the square of the mean is four, and the mean square is five.'),
('partial','部分最小化','partial minimization','inf_y',40,'对部分变量取下确界，所得值可以不被任何点取得。','Taking an infimum over some variables; the value need not be attained.','对 (x−y)²+y² 消去 y 后得到 x²/2。','Eliminating y from (x−y)²+y² gives x²/2.'),
('fenchel','Fenchel 不等式','Fenchel inequality','f+f*≥〈x,y〉',43,'由共轭定义得到的内积上界，取等表示共轭最大化。','The inner-product bound from conjugacy, with equality at a conjugate maximizer.','½x²+½y²≥xy，等号要求 x=y。','Half x² plus half y² bounds xy, with equality at x=y.'),
('quasi','拟凸','quasiconvex','f(mix)≤max',44,'所有次水平集凸，混合点不超过两端较大值。','Having convex sublevel sets, or mixture values no greater than the larger endpoint value.','x³ 在 R 上拟凸，却不凸。','The function x³ is quasiconvex on R but not convex.'),
('logconvex','对数凸','log-convex','log f convex',45,'正函数的对数为凸函数。','A positive function with convex logarithm.','exp(x²) 的对数为 x²，所以对数凸。','The logarithm of exp(x²) is x², so it is log-convex.'),
('logconcave','对数凹','log-concave','log f concave',45,'正函数的对数为凹函数。','A positive function with concave logarithm.','exp(−x²/2) 为对数凹高斯形状。','The Gaussian shape exp(−x²/2) is log-concave.'),
('kconvex','广义凸性','K-convexity','⪯K',46,'用锥序代替标量不等式的向量值函数凸性。','Convexity of a vector-valued function using cone order in place of scalar order.','xxᵀ 在 PSD 序下凸。','The map xxᵀ is convex in PSD order.'),
('monotonic','广义单调性','generalized monotonicity','Df K⊂L',47,'输入按指定锥序增加时，输出也按其锥序增加。','Preservation of specified input and output cone orders.','x₁+2x₂ 对逐分量增加是非减的。','The map x₁+2x₂ is nondecreasing under componentwise increases.')]
for key,z,e,s,i,d,de,ex,exe in EXTRA:
    TERMS[key]=[z,e,s,d,de,f'u{i:02}'];NOTES[key]=[ex,exe]

def originals(unit):
    return ''.join(f'<figure><img src="pages/L{unit["lecture"]}-{pg:03}.webp" loading="lazy" width="1200" height="900" alt="Lecture {unit["lecture"]}, PDF page {pg}"><figcaption>Lecture {unit["lecture"]} · PDF p.{pg}</figcaption></figure>' for pg in unit['pages'])

nav='';body='';lecture_names=[('优化模型与全局结构','Models and global structure'),('数学背景','Mathematical background'),('凸集与锥','Convex sets and cones'),('凸函数与保持规则','Convex functions and preservation'),('共轭与广义凸性','Conjugacy and generalized convexity')]
guide=p(('默认“了解”适合首次自学：顺序阅读概念、算例和读图说明；“掌握”在此基础上补完整证明与自测；“深入”说明边界及后续联系；“速通”用于复习。四档内容累积显示，切换时会保留当前位置。中文和英文讲解包含相同前提与例子。','Understand is the default for first study: read the concept explanations, worked examples and diagram guides in order. Mastery adds complete proofs and self-checks; In depth adds boundaries and connections; Quick serves review. Depths are cumulative, switching preserves position, and both languages include the same assumptions and examples.'))
guide+=p(('前置知识只需实数运算、基础坐标与矩阵乘法。缺少的内积、范数、求导和矩阵性质在第二讲补齐。建议每节读完盖住答案，用自己的话解释定义，再写出一个例子的计算。阅读记忆仅保存在当前浏览器，不跨设备同步；带 # 的地址优先打开指定章节。','Prerequisites are real arithmetic, basic coordinates and matrix multiplication. Lecture 2 supplies inner products, norms, differentiation and matrix properties. After each unit, hide the answer, explain the definition in your own words and calculate one example. Reading memory stays in this browser without cross-device sync; an address with # takes priority.'))
guide+='<p>'+bi('全课件共 280 页，整理为 47 个教学单元。每节标注课件页码、教材章节和作业联系，原页可展开核对。概念的用途是本讲义的解释；历史事实附一手资料链接。','All 280 slide pages are mapped to 47 teaching units. Each unit identifies slide pages, textbook sections and homework links, with expandable source pages. Conceptual uses are authored explanations; historical facts have primary-source links.')+'</p>'
guide+='<ol>'+''.join('<li><a href="#lecture'+str(i)+'">'+bi(z,e)+'</a></li>' for i,(z,e) in enumerate(lecture_names,1))+'</ol><p><a href="#homework">'+bi('作业 1 导航','HW1 navigation')+'</a> · <a href="#glossary">'+bi('中英名词对照','Bilingual glossary')+'</a> · <a href="#source-map">'+bi('280 页来源地图','280-page source map')+'</a></p>'
body+='<section id="guide"><h2>'+bi('如何使用这份讲义','How to use this handbook')+'</h2>'+layer('guide-text',0,('阅读路线','Reading route'),guide)+'</section>'
nav+='<a href="#guide">'+bi('阅读导引','Reading guide')+'</a>'
for unit in MAP['units']:
    uid=unit['id'];u=UNITS[uid];lid=unit['lecture'];id='u'+uid
    unit=dict(unit)
    unit['title']=u.get('title_z',unit['title'])
    unit['goal']=u.get('goal_z',unit['goal'])
    if uid in ['01','06','19','31','41']:
        z,e=lecture_names[lid-1];body+=f'<div class="lecture-heading" id="lecture{lid}"><p class="eyebrow">LECTURE {lid:02}</p><h2>'+bi(z,e)+'</h2></div>';nav+='<p class="nav-group">'+bi(f'第 {lid} 讲',f'Lecture {lid}')+'</p>'
    nav+=f'<a href="#{id}">'+bi(uid+' · '+unit['title'],uid+' · '+u['en'])+'</a>'
    body+=f'<section id="{id}" data-unit="{uid}"><h2>'+bi(uid+' · '+unit['title'],uid+' · '+u['en'])+'</h2><p class="source">Lecture '+str(lid)+' · PDF pp.'+unit['page_range']+' · Boyd &amp; Vandenberghe §'+unit['book']+' · HW1 '+unit['homework']+'</p><p class="goal">'+bi('学完应能：'+unit['goal']+'。','Learning goal: '+u.get('goal_e','explain '+u['en'].lower()+' and justify the assumptions and calculations in this unit.'))+'</p>'
    if uid=='10':
        body+=layer('u10-motivation',2,('为什么需要一个“对偶”长度','Why introduce a dual measure of length'),p(('误差长度预算如何限制线性响应？对偶范数给出精确系数：‖h‖≤ε 时，|zᵀh|≤ε‖z‖*。下面从单位球与内积解释这个系数。','How does an error budget limit linear response? The dual norm supplies the coefficient: ‖h‖≤ε implies |zᵀh|≤ε‖z‖*. Unit balls and inner products explain why.')))
        for sid in ['prep','definition','common','inequality','quadratic','practice','advanced']:
            node=sample_soup.find('section',id=sid)
            assert node is not None,sid
            node.name='div';node['class']='dual-section'
            for n in [node]+node.find_all(id=True):
                if n.has_attr('id'):n['id']='dual-'+n['id']
                if n.has_attr('data-anchor'):n['data-anchor']='dual-'+n['data-anchor']
            for a in node.select('a[href^="#"]'):a['href']='#dual-'+a['href'][1:]
            for h in node.find_all('h2'):h.name='h3'
            # The original graph element IDs must match the approved graph runtime.
            for n in node.select('input,select,output,svg,[id$="readout"],[id="dual-mini-balls"]'):
                if n.get('id','').startswith('dual-'):n['id']=n['id'][5:]
            body+=str(node)
    else:
        quick=layer(id+'-quick',1,('复习 · 定义与结论','Review · Definition and result'),p(u['quick'])+m(u['formula']))
        if not u.get('first_reading'):body+=quick
        content=paragraphs(u['under'],id+'-read')
        if u['fig']:
            drawing=figure(u['fig'])
            for old in re.findall(r'id="([^"]+)"',drawing):
                drawing=drawing.replace('id="'+old+'"','id="'+id+'-'+old+'"').replace('href="#'+old+'"','href="#'+id+'-'+old+'"').replace('url(#'+old+')','url(#'+id+'-'+old+')')
            diagram='<figure class="course-figure">'+drawing+'<figcaption>'+bi(*CAPTIONS[u['fig']])+'</figcaption></figure>'
            if 'figure_after' in u:
                split=u['figure_after']+1
                content=paragraphs(u['under'][:split],id+'-read')+diagram+paragraphs(u['under'][split:],id+'-read',split)
            else:content+=diagram
        body+=layer(id+'-understand',2,('了解 · 从问题走到例子','Understand · From the question to an example'),content)
        body+=layer(id+'-mastery',3,('掌握 · 写完整论证','Mastery · Write the complete argument'),paragraphs(u['proof'],id+'-proof')+'<div class="observe"><h4>'+bi('先独立试一遍','Try independently first')+'</h4>'+p(u['exercise'])+detail(id+'-answer','展开核对','Check the answer',p(u['answer']))+'</div>')
        body+=layer(id+'-depth',4,('深入 · 条件、用途与联系','In depth · Conditions, uses and connections'),p(u['deep']))
        if u.get('first_reading'):body+=quick
    body+=detail(id+'-original','核对原课件 · '+unit['page_range'],'Check original slides · '+unit['page_range'],originals(unit))+'</section>'

HW=[('1(a)','10','二次对偶范数：换元、上界、取等、z=0','Quadratic dual norm: substitution, bound, attainment, zero'),('1(b)','09','诱导 ℓ∞：最大绝对行和与符号输入','Induced ℓ∞: row sums and sign input'),('1(c)','09','诱导范数次乘性与中间空间相容','Submultiplicativity with compatible middle space'),('2(a)–(c)','13','梯度、Hessian、PSD 与零方向；接着读第 14 节','Gradient, Hessian, PSD and null directions; continue to unit 14'),('3(a)','19','Ax=b 仿射与凸性','Affineness and convexity of Ax=b'),('3(b)–(c)','21','范数球与距离比较半空间','Norm balls and distance-comparison halfspaces'),('4(a)–(b)','33','三个一元函数与平方最小二乘','Three scalar functions and squared least squares'),('4(c)','36','有限 Jensen，归纳与零权重','Finite Jensen, induction and zero weights'),('5(a)','25','二阶锥四个正常性条件','Four properness properties of the SOC'),('5(b)','29','自对偶两向包含与反证向量','Self-duality in both directions and certificate vectors'),('5(c)','30','锥序公式与传递性','Cone-order formula and transitivity')]
hw='<table><thead><tr><th>HW1</th><th>'+bi('需要掌握的论证','Required argument')+'</th><th>'+bi('正文入口','Read')+'</th></tr></thead><tbody>'+''.join('<tr><td>'+a+'</td><td>'+bi(z,e)+'</td><td><a href="#u'+uid+'">'+bi('单元 '+uid,'Unit '+uid)+'</a></td></tr>' for a,uid,z,e in HW)+'</tbody></table>'
hw+=p(('作业导向路线为 07→09→10→13→14→19→21→25→29→30→31→32→33→36。遇到正定、矩阵平方根或维数不熟悉时，补读 15–18。上表覆盖每个小问，但练习是否已经掌握仍需用你独立写出的解答判断。','The homework-focused route is 07→09→10→13→14→19→21→25→29→30→31→32→33→36. Revisit 15–18 for positive definiteness, matrix square roots or dimensions. Every subquestion is covered; your independent written solution is the test of mastery.'))
body+='<section id="homework"><h2>'+bi('作业 1 · 覆盖与自检','HW1 · Coverage and self-check')+'</h2>'+layer('homework-route',0,('逐小问定位','Locate each subquestion'),hw)+'</section>'

gloss='<label class="search-label">'+bi('搜索中英名称、符号或缩写','Search Chinese/English terms, symbols or abbreviations')+'<input id="term-search" type="search" placeholder="Hessian / 对偶 / LMI"></label><div class="table-wrap"><table id="glossary-table"><thead><tr>'+''.join('<th>'+bi(z,e)+'</th>' for z,e in [('中文','Chinese'),('英文','English'),('符号','Symbol'),('解释','Meaning'),('位置','Context')])+'</tr></thead><tbody>'
for key,t in TERMS.items():
    gloss+='<tr data-search="'+html.escape(' '.join(t).lower(),quote=True)+'"><td>'+term(key)+'</td><td>'+t[1]+'</td><td>'+html.escape(t[2])+'</td><td>'+bi(html.escape(t[3]),html.escape(t[4]))+'</td><td><a href="#'+t[5]+'">'+bi('前往讲解','Read')+'</a></td></tr>'
gloss+='</tbody></table></div><p id="term-empty" hidden>'+bi('没有匹配项。','No matching terms.')+'</p>'
body+='<section id="glossary"><h2>'+bi('中英名词对照表','Chinese–English terminology')+'</h2>'+layer('glossary-list',0,('随时查阅','A reading reference'),gloss)+'</section>'
nav+='<a href="#homework">'+bi('作业覆盖','HW1 coverage')+'</a><a href="#glossary">'+bi('名词对照','Glossary')+'</a><a href="#source-map">'+bi('来源地图','Source map')+'</a>'
rows=''.join('<tr><td>'+str(v['lecture'])+'</td><td>'+str(v['page'])+'</td><td>'+html.escape(v['source_heading'])+'</td><td>'+('<a href="#u'+v['unit']+'">'+v['unit']+'</a>' if v['unit'] else bi('封面/提纲/总结','Cover/outline/summary'))+'</td><td><a href="pages/L'+str(v['lecture'])+'-'+str(v['page']).zfill(3)+'.webp">'+bi('原页','Slide')+'</a></td></tr>' for v in MAP['pages'])
sources=p(('正文按照课件知识单元重组，课件 PDF 页码从 1 开始，教材使用章节号，二者不可混用。原课件的封面、提纲与总结页均在下表保留。正文中的推导、数值例子、用途解释和数学图像是新增的教学组织；教材中的定理条件仍按相应章节核对。','The text reorganizes slides into teaching units. Slide PDF pages are one-based; textbook citations use section numbers. Do not mix these systems. Covers, outlines and summaries remain in the map. Derivations, numerical examples, applications and mathematical diagrams are authored expansions, with theorem assumptions checked against the cited textbook sections.'))
sources+='<p>Boyd &amp; Vandenberghe, <em>Convex Optimization</em> (2004). '+bi('本地教材文件：Convex Optimization.pdf；数学背景 A.1–A.5，凸集第 2 章，凸函数第 3 章。','Local textbook: Convex Optimization.pdf; background A.1–A.5, convex sets Chapter 2, convex functions Chapter 3.')+' <a href="https://web.stanford.edu/~boyd/cvxbook/">'+bi('作者官方页面','Authors’ official page')+'</a>。</p>'
sources+='<p>'+bi('历史事实来源：','Historical sources: ')+'<a href="https://www.nobelprize.org/prizes/economic-sciences/1975/press-release/">Nobel Prize · 1975 resource allocation announcement</a>；<a href="https://stanford.edu/~boyd/cvxbook/bv_cvxslides_original.pdf">Boyd · Brief history of convex optimization</a>；<a href="https://web.stanford.edu/~boyd/papers/history_lmi_ctrl.html">Boyd et al. · History of LMIs in control theory (1994)</a>。</p>'
sources+='<p><a href="source-map.md">'+bi('下载逐页对应表','Download the source map')+'</a> · <a href="writing-standard.md">'+bi('讲解语言标准','Writing standard')+'</a></p>'
sources+=detail('all-slide-map','展开全部 280 页对应关系','Expand all 280 page mappings','<div class="table-wrap"><table><thead><tr><th>Lecture</th><th>PDF p.</th><th>'+bi('原页标题','Source heading')+'</th><th>Unit</th><th>'+bi('查看','View')+'</th></tr></thead><tbody>'+rows+'</tbody></table></div>')
body+='<section id="source-map"><h2>'+bi('来源、范围与逐页对应','Sources, scope and page mapping')+'</h2>'+layer('source-info',0,('核对原资料','Check original materials'),sources)+'</section>'

# Link first occurrences without touching formula attributes, nested language spans or glossary text.
soup=BeautifulSoup(body,'html.parser')
refine_soup(soup)
used={'zh':set(),'en':set()}
for node in list(soup.find_all(string=True)):
    if node.find_parent(['button','script','style','svg','summary','h2','h3','h4','figcaption']) or node.find_parent(id='glossary'):continue
    lang=node.find_parent(class_=['zh','en'])
    if lang is None:continue
    lng='zh' if 'zh' in lang.get('class',[]) else 'en';text=str(node)
    for key,t in TERMS.items():
        word=t[0 if lng=='zh' else 1]
        if key in used[lng] or len(word)<2 or word not in text:continue
        a,b=text.split(word,1);button=soup.new_tag('button',attrs={'class':'term','data-term':key});button.string=word
        node.replace_with(NavigableString(a),button,NavigableString(b));used[lng].add(key);break
simplify_headings(soup)
body=str(soup)
css=(R/'sample.css').read_text(encoding='utf8')+'\n.nav-group{font-size:12px;letter-spacing:.08em;color:#315b78;border-top:1px solid var(--line);margin:16px 0 0;padding-top:16px}.lecture-heading{padding:60px 0 10px}.lecture-heading h2{font-size:32px}.dual-section{padding:25px 0;border-top:1px solid var(--line)}.course-figure{margin:28px 0}.course-figure svg{display:block;width:100%;height:auto}.course-figure figcaption{font-size:14px;line-height:1.9;color:var(--muted);margin-top:14px}.home-back{position:fixed;left:14px;bottom:14px;z-index:4;border:1px solid var(--line);border-radius:20px;background:#fffdf7;padding:5px 12px;font-size:12px;text-decoration:none}nav{gap:2px}nav a{font-size:12px;line-height:1.6}.hero h1{font-size:46px}section details>figure img{width:100%;height:auto}@media(max-width:760px){.hero h1{font-size:34px}.lecture-heading h2{font-size:27px}.course-figure{margin:22px 0}}@media print{.home-back{display:none}}'
katex=Path(os.environ.get('CONVEX_KATEX_DIST',str(R/'vendor/katex') if (R/'vendor/katex').exists() else 'E:/CC_Nichijo/notes/llm-principles/src/node_modules/katex/dist'));kcss=(katex/'katex.min.css').read_text(encoding='utf8')
def inlinefont(match):
    f=katex/match.group(1);return 'url(data:font/'+f.suffix[1:]+';base64,'+base64.b64encode(f.read_bytes()).decode()+')'
kcss=re.sub(r'url\((fonts/[^)]+)\)',inlinefont,kcss)
css+='\nmain p,main li,.source{overflow-wrap:anywhere}nav .nav-group{flex-shrink:0}@media(max-width:760px){nav .nav-group{border-top:0;margin:0;padding:6px 0}.home-back{bottom:8px;left:8px}}'
css+=UI_CSS
css+='\n.anchor-alias{display:block;height:0}.route-finish{border-block:1px solid var(--line);padding:18px 0;margin:32px 0;color:var(--muted);font-size:15px}#homework table{min-width:580px}h4[id]{scroll-margin-top:100px}'
js=(R/'sample.js').read_text(encoding='utf8').replace("KEY='convex-dual-sample-v1'","KEY='convex-complete-1-5-v1'").replace('本样章','本讲义').replace('this sample chapter','this handbook')
# Hash links into a hidden layer must raise reading depth before scrolling.
js+=r'''
function openAnchor(hash){const el=document.getElementById(decodeURIComponent(hash.slice(1)));if(!el)return;const group=el.closest('[data-level]');if(group&&depth<Number(group.dataset.level)){depth=Number(group.dataset.level);settings();}el.scrollIntoView();updateNav();persist();}
document.querySelectorAll('a[href^="#"]').forEach(a=>a.addEventListener('click',e=>{if(a.id==='term-target')return;e.preventDefault();const h=a.getAttribute('href');openAnchor(h);history.replaceState(null,'',h);}));
window.addEventListener('hashchange',()=>openAnchor(location.hash));document.fonts.ready.then(()=>requestAnimationFrame(()=>{if(location.hash)openAnchor(location.hash);}));
'''
fontcss='';characters=set(html.unescape(body+nav+css+js+json.dumps(TERMS,ensure_ascii=False)+json.dumps(NOTES,ensure_ascii=False)+'凸优化前五讲双语自学讲义了解掌握深入速通重置进度名词小笺如何理解看一个例子回到正文继续推理前往讲解返回笔记入口最后整理'))
characters|=set((R/'reader_controls.js').read_text(encoding='utf8'))
characters|=set((R/'task_revision.py').read_text(encoding='utf8'))
characters|=set((R/'refinement_content.py').read_text(encoding='utf8'))
for weight in [400,700]:
    digest=hashlib.sha256((''.join(sorted(characters))+str(weight)).encode()).hexdigest()[:12];cache=R/f'font-{digest}.woff2'
    if not cache.exists():
        print('Building readable embedded font',weight,flush=True);font=instantiateVariableFont(TTFont(os.environ.get('CONVEX_CJK_FONT','C:/Windows/Fonts/NotoSerifSC-VF.ttf')),{'wght':weight},inplace=True);opts=subset.Options();opts.flavor='woff2';sub=subset.Subsetter(options=opts);sub.populate(text=''.join(characters));sub.subset(font);font.flavor='woff2';font.save(cache)
    fontcss+=f'@font-face{{font-family:StudySerif;src:url(data:font/woff2;base64,{base64.b64encode(cache.read_bytes()).decode()}) format("woff2");font-weight:{weight};font-style:normal;font-display:swap;}}'
dialog=str(sample_soup.find('dialog'));dialog=dialog.replace('本样章','本讲义')
page='<!doctype html><html lang="zh-CN" data-lang="zh" data-depth="2"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>凸优化 · 前五讲双语自学讲义</title><style>'+fontcss+kcss+css+'</style></head><body><a class="home-back" href="../">'+bi('← 返回笔记入口','← Notes home')+'</a><aside><div class="brand">'+bi('凸优化','Convex optimization')+'<small>'+bi('前五讲 · 完整自学讲义','Lectures 1–5 · Complete handbook')+'</small></div><nav>'+nav+'</nav><p class="aside-note">'+bi('47 单元 · 280 页来源<br>纸笔推演 · 图像理解','47 units · 280 source pages<br>Paper reasoning · Visual understanding')+'</p></aside><header><div class="depths">'+''.join(f'<button data-depth-button="{n}" aria-pressed="{str(n==2).lower()}">'+bi(z,e)+'</button>' for n,z,e in [(1,'速通','Quick'),(2,'了解','Understand'),(3,'掌握','Mastery'),(4,'深入','In depth')])+'</div><div class="tools"><button id="language" aria-label="Switch language">English</button><button id="reset">'+bi('重置进度','Reset progress')+'</button></div></header><main><div class="hero"><p class="eyebrow">CONVEX OPTIMIZATION / LECTURES 01–05</p><h1>'+bi('凸优化 · 自学讲义','Convex optimization · A self-study handbook')+'</h1><p class="subtitle">'+bi('从一个具体问题出发，<br>把定义、图像与证明连起来。','Start with a concrete question;<br>connect definitions, diagrams and proofs.')+'</p><p class="hero-meta">'+bi('中英切换 · 四档深度 · 术语小笺 · 作业导航','Two languages · Four depths · Term notes · Homework routes')+'</p></div>'+body+'<footer>'+bi('最后整理：2026-10-14 · 阅读记忆保存在当前浏览器。','Updated 2026-10-14 · Reading memory stays in this browser.')+'</footer></main>'+dialog+'<script>'+ (katex/'katex.min.js').read_text(encoding='utf8')+'</script><script>const TERMS='+json.dumps(TERMS,ensure_ascii=False)+';const TERM_NOTES='+json.dumps(NOTES,ensure_ascii=False)+';</script><script>'+js+'</script></body></html>'
page=page.replace('最后整理：2026-10-14','最后整理：2026-10-16').replace('Updated 2026-10-14','Updated 2026-10-16')
(OUT/'index.html').write_text(page,encoding='utf8')
apply_to_existing(OUT/'index.html')
make_route(OUT/'index.html')
write_coverage(OUT/'hw1-coverage.md')
for a,b in [('逐页对应表.md','source-map.md'),('自学讲义语言标准.md','writing-standard.md'),('内容地图.json','content-map.json')]: (OUT/b).write_bytes((R/a).read_bytes())
pages=OUT/'pages';pages.mkdir(exist_ok=True)
for lid in range(1,6):
    source=Path(os.environ.get('CONVEX_MATERIALS',str(R.parent.parent)))/f'Lecture_{lid}.pdf'
    if not source.exists():
        count=[43,58,76,65,38][lid-1]
        assert all((pages/f'L{lid}-{i:03}.webp').exists() for i in range(1,count+1)),f'Missing {source}; set CONVEX_MATERIALS or retain all source-page images.'
        print('Existing source images retained:',lid,count,flush=True)
        continue
    doc=fitz.open(source)
    for i,pg in enumerate(doc,1):
        dst=pages/f'L{lid}-{i:03}.webp'
        if not dst.exists():
            from PIL import Image
            pix=pg.get_pixmap(matrix=fitz.Matrix(1200/pg.rect.width,1200/pg.rect.width));im=Image.frombytes('RGB',[pix.width,pix.height],pix.samples);im.save(dst,'WEBP',quality=82)
    print('Source pages ready:',lid,len(doc),flush=True)
print('Complete handbook:',len(UNITS),'units,',len(TERMS),'terms,',len(page),'characters',flush=True)
