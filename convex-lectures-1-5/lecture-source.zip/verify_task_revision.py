"""Acceptance evidence for mathematics, sources and the two physical routes."""
import json,collections,re,hashlib
from pathlib import Path
import fitz,numpy as np,sympy as sp
from bs4 import BeautifulSoup
from playwright.sync_api import sync_playwright
from task_revision import EVIDENCE,STAGES
R=Path(__file__).parent;OUT=R/'完整讲义';WORK=R.parent.parent
report={'date':'2026-10-16','checks':[],'source_pages':[],'coverage':[],'browser':[],'limits':['No real iOS Safari device test.','All 280 slide texts and page assignments checked; not every slide formula visually reread.','Coverage is editorial evidence, not a guarantee of student mastery.']}
def check(name,condition):
    assert condition,name
    report['checks'].append(name)

# Read actual PDFs and verify every mapping in both directions.
mapping=json.loads((R/'内容地图.json').read_text(encoding='utf8'))
for lid,count in enumerate([43,58,76,65,38],1):
    doc=fitz.open(WORK/f'Lecture_{lid}.pdf');assert len(doc)==count
    entries=[v for v in mapping['pages'] if v['lecture']==lid]
    assert sorted(v['page'] for v in entries)==list(range(1,count+1))
    for row in entries:
        text=doc[row['page']-1].get_text()
        assert text.strip()
        lines=[t.strip() for t in text.splitlines() if t.strip()]
        assert row['source_heading']==' / '.join(lines[:2]),(lid,row['page'])
        us=[u['id'] for u in mapping['units'] if u['lecture']==lid and row['page'] in u['pages']]
        assert us==([row['unit']] if row['unit'] else [])
        assert (OUT/f'pages/L{lid}-{row["page"]:03}.webp').exists()
        report['source_pages'].append({'lecture':lid,'page':row['page'],'unit':row['unit'],'text_sha256':hashlib.sha256(text.encode()).hexdigest()})
check('280 source pages: extraction, page bounds, single ownership and image files',len(report['source_pages'])==280)
hw=fitz.open(WORK/'hw1/hw1.pdf');hwtext=''.join(p.get_text() for p in hw)
check('HW1 actual two pages: 5 problems, specified methods and points',len(hw)==2 and all(s in hwtext for s in ['Problem 1','Problem 5','induction','triangle','Hessian']))
book=fitz.open(WORK/'Convex Optimization.pdf')
check('Local Boyd textbook: conjugates and matrix powers checked against text',len(book)==714 and 'Negative logarithm' in book[104].get_text() and 'matrix convex' in book[123].get_text())

# Independent algebra and numerical checks of the authored examples.
x,y,a=sp.symbols('x y a',real=True);xp=sp.symbols('x',positive=True)
check('Three scalar second derivatives',sp.simplify(sp.diff(sp.exp(a*x),x,2)-a*a*sp.exp(a*x))==0 and sp.diff(-sp.log(xp),xp,2)==xp**-2 and sp.diff(xp*sp.log(xp),xp,2)==1/xp)
P=np.array([[2.,1.],[1.,2.]]);z=np.array([1.,-1.]);inv=np.linalg.inv(P);dv=np.sqrt(z@inv@z);star=inv@z/dv
check('Quadratic norm gate: SPD, inverse, feasibility and attainment',np.all(np.linalg.eigvalsh(P)>0) and np.isclose(dv,np.sqrt(2)) and np.isclose(star@P@star,1) and np.isclose(z@star,dv))
P=np.diag([9.,1.]);z=np.array([3.,2.]);dv=np.sqrt(z@np.linalg.solve(P,z));star=np.linalg.solve(P,z)/dv
check('Quadratic norm worked example sqrt(5)',np.isclose(dv,np.sqrt(5)) and np.isclose(star@P@star,1) and np.isclose(z@star,dv))
A=np.array([[1.,-3.,2.],[-2.,0.,1.]]);v=np.array([1.,-1.,1.])
check('Rectangular row-sum gate and attaining input',np.max(np.sum(abs(A),axis=1))==6 and np.max(abs(v))==1 and np.allclose(A@v,[6,-1]))
u,v=sp.symbols('u v',real=True);F=(u+2*v-1)**2+4*(u-v)**2
check('Transfer Hessian [[10,-4],[-4,16]]',sp.hessian(F,(u,v))==sp.Matrix([[10,-4],[-4,16]]))
check('Nonasymmetric distance comparison gate',np.allclose(2*(np.array([3,0])-np.array([-1,2])),[8,-4]) and 3**2-((-1)**2+2**2)==4)
check('Jensen numerical example and normalized weights',sp.Rational(1,2)+sp.Rational(1,3)+sp.Rational(1,6)==1 and (sp.Rational(1,3)*3+sp.Rational(1,6)*6)**2==4 and sp.Rational(1,3)*9+sp.Rational(1,6)*36==9)
check('SOC exterior test vector norm and pairing',np.isclose(np.linalg.norm([-3/5,-4/5]),1) and np.isclose(np.dot([3,4],[-3/5,-4/5])+4,-1))
yn=sp.symbols('yn',negative=True)
check('Negative-log conjugate stationary value on y<0',sp.simplify((yn*xp+sp.log(xp)).subs(xp,-1/yn)-(-1-sp.log(-yn)))==0)
check('Quadratic conjugates retain factors',sp.simplify((y*x-2*x*x).subs(x,y/4)-y*y/8)==0)
coeff=np.array([[1.,0.],[-1.,0.],[0.,1.]])
def lse(xx):
    scores=coeff@xx;ee=np.exp(scores-scores.max());pp=ee/ee.sum();mean=pp@coeff;H=(coeff.T*pp)@coeff-np.outer(mean,mean)
    return np.log(np.exp(scores).sum()),mean,H
rng=np.random.default_rng(216)
for xx in [np.zeros(2),*[rng.normal(size=2) for _ in range(10)]]:
    value,g,H=lse(xx);eps=1e-5
    gn=np.array([(lse(xx+eps*np.eye(2)[j])[0]-lse(xx-eps*np.eye(2)[j])[0])/(2*eps) for j in range(2)])
    Hn=np.column_stack([(lse(xx+eps*np.eye(2)[j])[1]-lse(xx-eps*np.eye(2)[j])[1])/(2*eps) for j in range(2)])
    assert np.allclose(g,gn,atol=1e-7) and np.allclose(H,Hn,atol=1e-7) and np.linalg.eigvalsh(H).min()>0
check('LSE gate: gradient and Hessian finite differences at 11 points, positive definite',np.allclose(lse(np.zeros(2))[2],np.diag([2/3,2/9])))

for filename in ['index.html','hw1-route.html']:
    soup=BeautifulSoup((OUT/filename).read_text(encoding='utf8'),'html.parser')
    check(filename+': 47 units, old anchors retained',len(soup.select('section[data-unit]'))==47)
    counts=collections.Counter(n['id'] for n in soup.select('[id]'))
    check(filename+': unique IDs',not [k for k,n in counts.items() if n>1])
    for link in soup.select('a[href^="#"]'):assert soup.find(id=link['href'][1:]),(filename,link['href'])
    for item,body,example,train,z,e in EVIDENCE:
        for ident in [body,example,train]:assert soup.find(id=ident),(item,ident)
    check(filename+': all 17 evidence rows resolve',len(EVIDENCE)==17)
    for gate in soup.select('.observe[id^="gate-"]'):
        assert len(gate.find_all('details',recursive=False))==3
        assert not gate.select('details[open]')
    check(filename+': five gates with three closed help stages',len(soup.select('.observe[id^="gate-"]'))==5)
    check(filename+': erroneous support biconjugate statement removed','支撑函数双共轭回到 δC' not in soup.get_text())
    # No core theorem necessary condition is hidden only in the advanced layer.
    for ident in ['strict-definition','quadratic-method','lse-gradient','conjugate-exponential','scalar-curvature']:
        assert soup.find(id=ident).find_parent(attrs={'data-level':'2'})
    for uid in range(1,48):
        if uid==10:continue
        assert soup.find(id=f'u{uid:02}-hint') and soup.find(id=f'u{uid:02}-steps') and soup.find(id=f'u{uid:02}-answer')
route=BeautifulSoup((OUT/'hw1-route.html').read_text(encoding='utf8'),'html.parser')
order=[n.get('id') for n in route.main.find_all(id=True)]
check('HW1 marker follows SOC, induction and all five gates',all(order.index(i)<order.index('hw1-ready') for i in ['soc-proof','jensen-proof','gate-cone','gate-convex','gate-norm','gate-derivative','gate-sets']))
check('HW1 sqrt and topology precede formal use',order.index('u16')<order.index('u10') and order.index('u11')<order.index('soc-proof'))

with sync_playwright() as pw:
    browser=pw.chromium.launch(executable_path='C:/Program Files/Google/Chrome/Application/chrome.exe',headless=True)
    for filename in ['index.html','hw1-route.html']:
        for width in [1360,390]:
            ctx=browser.new_context(viewport={'width':width,'height':920},reduced_motion='reduce');page=ctx.new_page();errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
            page.goto((OUT/filename).as_uri());page.wait_for_function('!restoring');page.evaluate('document.fonts.ready')
            popup_count=page.evaluate('''()=>{for(const k of Object.keys(TERMS)){showTerm(k);if(!document.querySelector('#term-definition').textContent.trim()||!document.querySelector('#term-example-text').textContent.trim()||!document.getElementById(TERMS[k][5]))throw Error('Invalid term '+k);document.querySelector('#term-dialog').close();}return Object.keys(TERMS).length}''')
            assert popup_count==78
            assert page.locator('.math-error').count()==0,page.locator('.math-error').all_text_contents()
            assert page.locator('.math').count()==page.locator('.katex').count()
            for lang in ['zh','en']:
                if lang=='en':page.locator('#language').click();page.wait_for_function('!restoring')
                for dep in [1,2,3,4]:
                    page.locator(f'[data-depth-button="{dep}"]').click();page.wait_for_function('!restoring')
                    assert page.evaluate('document.documentElement.scrollWidth<=innerWidth+1'),(filename,width,lang,dep)
                page.locator('[data-depth-button="2"]').click();page.wait_for_function('!restoring')
                assert page.locator('#strict-definition').is_visible()
                assert not page.locator('#gate-norm').is_visible()
            page.locator('#language').click();page.wait_for_function('!restoring')
            # Links reveal the required layer. Open answers are still opt-in.
            page.evaluate("openAnchor('#gate-convex')");assert page.locator('#gate-convex').is_visible()
            assert not page.locator('#gate-convex-answer').get_attribute('open')
            page.locator('#gate-convex-answer summary').click();assert page.locator('#gate-convex-answer').get_attribute('open') is not None
            page.locator('#angle').fill('45');page.locator('#sweep').fill('1')
            for norm,val in [('1','0.7071'),('2','1.0000'),('inf','1.4142')]:
                page.locator('#norm-choice').select_option(norm);text=page.locator('#support-readout').inner_text();assert ' = '+val in text and 'c = '+val in text
            page.locator('#sweep').fill('0.5');assert 'c = 0.7071' in page.locator('#support-readout').inner_text()
            page.locator('#angle').fill('0');page.locator('#norm-choice').select_option('inf');assert 'Dual value = 1.0000' in page.locator('#support-readout').inner_text() or '对偶值 = 1.0000' in page.locator('#support-readout').inner_text()
            page.locator('#theme-toggle').click();assert page.locator('html').get_attribute('data-theme')=='dark'
            page.locator('#sidebar-toggle').click();page.wait_for_function('!restoring');assert not page.locator('aside').is_visible()
            page.locator('#sidebar-toggle').click();page.wait_for_function('!restoring');assert page.locator('aside').is_visible()
            page.evaluate("openAnchor('#lse-hessian')");page.screenshot(path=str(R/f'任务书验收_{filename.split(".")[0]}_{width}.png'))
            page.evaluate("openAnchor('#conjugate-exponential')");page.screenshot(path=str(R/f'共轭重写_{filename.split(".")[0]}_{width}.png'))
            assert not errors,errors
            report['browser'].append({'page':filename,'width':width,'languages':['zh','en'],'depths':[1,2,3,4],'math_errors':0,'js_errors':errors,'overflow':False,'slider_values':[.7071,1,1.4142]})
            ctx.close()
    browser.close()
report['coverage']=[dict(zip(['item','body','example','practice','evidence_zh','evidence_en'],row),status='editorial checks passed') for row in EVIDENCE]
(OUT/'task-verification.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
print(json.dumps({k:v for k,v in report.items() if k not in ['source_pages','coverage']},ensure_ascii=False,indent=2))
