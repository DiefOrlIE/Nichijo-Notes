from pathlib import Path
import argparse,collections,json,hashlib
from bs4 import BeautifulSoup
from playwright.sync_api import sync_playwright
R=Path(__file__).parent;OUT=R/'完整讲义'
parser=argparse.ArgumentParser();parser.add_argument('--chapter',type=int,default=2);args=parser.parse_args()
path=OUT/f'chapter-{args.chapter}.html';soup=BeautifulSoup(path.read_text(encoding='utf8'),'html.parser')
ids=collections.Counter(n['id'] for n in soup.select('[id]'));assert not [i for i,n in ids.items() if n>1]
assert not soup.select('[data-depth-button],.layer,[data-level]')
for a in soup.select('a[href^="#"]'):assert soup.find(id=a['href'][1:]),a['href']
for image in soup.select('img[src]'):assert (OUT/image['src']).exists()
for n in soup.select('.math'):assert not any(c in n['data-tex'] for c in ['\n','\t','\x08','\r']),repr(n['data-tex'])
report={'chapter':args.chapter,'html_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'browser':[],'source_checks':['unique IDs','all internal anchors','source images exist','no depth controls','no Python-escaped math control characters']}
with sync_playwright() as pw:
    browser=pw.chromium.launch(executable_path='C:/Program Files/Google/Chrome/Application/chrome.exe',headless=True)
    for width in [1360,390]:
        context=browser.new_context(viewport={'width':width,'height':940},reduced_motion='reduce');page=context.new_page();errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
        page.goto(path.as_uri());page.evaluate('document.fonts.ready');page.wait_for_function("document.querySelectorAll('.math .katex').length>0")
        for lang in ['zh','en']:
            if page.locator('html').get_attribute('data-lang')!=lang:page.locator('#language').click()
            assert page.locator('.math-error,.katex-error').count()==0
            assert page.evaluate('document.documentElement.scrollWidth<=innerWidth+2')
            assert page.locator('#mode').count()==0
            assert page.locator('.full-copy').first.is_visible()
            for term in list(page.locator('[data-term]').evaluate_all('(ns)=>[...new Set(ns.map(n=>n.dataset.term))]')):
                page.evaluate('(k)=>showTerm(k)',term);assert page.locator('#term-definition').inner_text().strip();assert page.locator('#term-example').inner_text().strip();page.locator('#term-close').click()
            page.locator('#theme').click();assert page.locator('html').get_attribute('data-theme') in ['dark','light']
            report['browser'].append({'width':width,'language':lang,'math_errors':0,'page_overflow':False,'js_errors':list(errors)})
        if args.chapter==2:
            page.locator('#u07').scroll_into_view_if_needed();page.screenshot(path=str(R/f'连续讲义2_范数_{width}.png'))
            page.locator('#u13').scroll_into_view_if_needed();page.screenshot(path=str(R/f'连续讲义2_导数_{width}.png'))
            for norm,value in [('l1',2**-.5),('l2',1),('linf',2**.5)]:
                page.select_option('#norm-choice',norm);page.locator('#angle').evaluate("n=>{n.value=45;n.dispatchEvent(new Event('input'))}")
                assert f'{value:.4f}' in page.locator('#support-readout').inner_text()
            page.locator('#sweep').evaluate("n=>{n.value=.5;n.dispatchEvent(new Event('input'))}");assert 'c = 0.7071' in page.locator('#support-readout').inner_text()
            assert '距离小于 ε' in page.locator('#u11').text_content()
            assert page.locator('#u11 .math[data-tex*="B(c,r)"]').get_attribute('data-tex').endswith('<r\\}.')
        page.evaluate("document.documentElement.classList.remove('toc-hidden')");page.locator('#sidebar-close').click();assert page.locator('html').evaluate("n=>n.classList.contains('toc-hidden')")
        page.locator('#toc').click();assert not page.locator('html').evaluate("n=>n.classList.contains('toc-hidden')")
        if width==390:page.locator('#sidebar-close').click()
        page.evaluate('window.scrollTo(0,2000)');page.keyboard.press('s');assert page.evaluate('scrollY')>2100
        page.keyboard.press('w');assert page.evaluate('scrollY')<2300
        before_y=page.evaluate('scrollY');before_toc=page.locator('html').evaluate("n=>n.classList.contains('toc-hidden')")
        page.keyboard.press('a');page.keyboard.press('d');assert page.evaluate('scrollY')==before_y
        assert page.locator('html').evaluate("n=>n.classList.contains('toc-hidden')")==before_toc
        if width==390:
            wide=page.locator('.math.display').evaluate_all('(ns)=>ns.findIndex(n=>n.checkVisibility()&&!n.closest("details:not([open])")&&n.scrollWidth>n.clientWidth+5)')
            if wide>=0:
                formula=page.locator('.math.display').nth(wide);formula.scroll_into_view_if_needed();formula.hover();formula.evaluate('n=>n.scrollLeft=0');page.keyboard.press('d');assert formula.evaluate('n=>n.scrollLeft')>0
                old_x=formula.evaluate('n=>n.scrollLeft');page.keyboard.press('a');assert formula.evaluate('n=>n.scrollLeft')<old_x
        assert not errors,errors
        context.close()
    browser.close()
(OUT/f'chapter-{args.chapter}-verification.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
print('Continuous chapter verified:',args.chapter,len(report['browser']),'viewport/language cases')
