"""A small scientific diagram separating convexity from quasiconvexity."""
import io,re
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

def quasiconvex():
    with plt.rc_context({'font.family':'DejaVu Serif','svg.fonttype':'path','font.size':10}):
        fig,ax=plt.subplots(1,2,figsize=(8.2,3.3),facecolor='#faf6ee')
        x=np.linspace(-2.1,2.1,350)
        for a in ax:
            a.set_facecolor('#faf6ee');a.spines[['top','right']].set_visible(False);a.grid(alpha=.12)
        ax[0].plot(x,x**3,color='#315b78',lw=2,label=r'$f(x)=x^3$')
        ax[0].plot([-2,-1],[-8,-1],color='#a54b3d',lw=2,label='chord')
        ax[0].scatter([-1.5],[-3.375],color='#315b78',zorder=5)
        ax[0].scatter([-1.5],[-4.5],color='#a54b3d',zorder=5)
        ax[0].set(xlabel='x',ylabel='f(x)',title='Not convex on the negative half-line');ax[0].legend(frameon=False,fontsize=9)
        ax[1].axhline(0,color='#899393',lw=.7);ax[1].axvspan(-3,1,alpha=.25,color='#315b78')
        ax[1].plot([-3,1],[0,0],color='#315b78',lw=3);ax[1].scatter([1],[0],color='#315b78',s=45,zorder=5)
        ax[1].annotate('',xy=(-3,0),xytext=(-2.7,0),arrowprops={'arrowstyle':'->','color':'#315b78'})
        ax[1].set(xlim=(-3,2),ylim=(-.5,.5),yticks=[],xticks=[-2,-1,0,1,2],xlabel='x',title=r'Sublevel $x^3\leq1$: $(-\infty,1]$')
        fig.tight_layout(pad=1.8);out=io.StringIO();fig.savefig(out,format='svg');plt.close(fig)
    svg=out.getvalue();svg=svg[svg.index('<svg'):]
    ids=re.findall(r'id="([^"]+)"',svg)
    for ident in ids:svg=svg.replace('id="'+ident+'"','id="qcv-'+ident+'"').replace('href="#'+ident+'"','href="#qcv-'+ident+'"').replace('url(#'+ident+')','url(#qcv-'+ident+')')
    return svg
