"""Apply reviewed concise prose without altering original source modules."""
import json
from pathlib import Path

R = Path(__file__).parent

def apply(units):
    content = json.loads((R/'精简重写/content.json').read_text(encoding='utf8'))
    for uid, fields in content.items():
        for key, value in fields.items():
            units[uid][key] = value
    # The data-and-cost plot follows the numerical argument.
    units['02']['figure_after'] = min(3, len(units['02']['under'])-1)

def apply_sample(soup):
    from author_concise_dual import apply_sample as author_apply
    author_apply(soup)
