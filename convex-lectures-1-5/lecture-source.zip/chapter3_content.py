"""Convex sets, written as a continuous first-reading chapter."""
from chapter2_content import unit,p,m,h,extra,ex

INTRO=p('一个优化问题先要决定哪些方案允许采用。这些方案形成可行集。本章研究一种特别有用的结构：两个可行方案之间的混合方案仍然可行。我们将把它写成凸集的定义，再逐步认识常见凸集、保持凸性的构造，以及用直线或超平面描述集合的方法。','An optimization problem begins with allowed plans, its feasible set. We study a useful structure: mixing two feasible plans remains feasible. This becomes the definition of a convex set, followed by common examples, constructions preserving convexity, and descriptions using lines and hyperplanes.')+p('本章使用第二章的内积、范数、开球、闭集和正定性。集合的凸性只关心可行性，不涉及目标值的大小；函数的凸性留到第四章。','We use Chapter 2 inner products, norms, balls, closedness and definiteness. Convexity of a set concerns feasibility alone; convexity of objective values is developed in Chapter 4.')

unit('19','3.1 仿射集：沿直线延伸','3.1 Affine sets: extending along lines',
p('给定两个不同的点 x、y，直线上每个点都能写成 (1−θ)x+θy。θ=0、1 给端点，0<θ<1 给中间点，其他实数给向两侧延伸的点。若一个集合包含其中任意两点所在的整条直线，就称为仿射集。','For distinct points x,y, their line consists of (1−θ)x+θy for real θ. Values zero and one give the endpoints, intermediate values give the segment, and other values extend beyond it. A set containing the entire line through any two of its points is affine.')
+m(r'x,y\in C,\quad\theta\in\mathbb R\quad\Longrightarrow\quad(1-\theta)x+\theta y\in C.')
+p('例如 x₁+x₂=1 是一条不经过原点的直线，因此是仿射集。线性子空间还要求包含原点，并对任意线性组合封闭；它比仿射集多了这个原点条件。非空仿射集总可以看成某个线性子空间整体平移。','The line x₁+x₂=1 is affine despite not passing through the origin. A linear subspace contains zero and is closed under arbitrary linear combinations. Every nonempty affine set is a translate of a linear subspace.')
+'<div data-figure="19"></div>'
+h('例：线性方程的解集','Example: solutions of linear equations')
+p('设 C={x:Ax=b}。要证明它仿射，取任意两个解 x、y 及任意实数 θ，直接代入：','Let C={x:Ax=b}. Choose any two solutions x,y and any real θ, then substitute:')
+m(r'A[(1-\theta)x+\theta y]=(1-\theta)Ax+\theta Ay=(1-\theta)b+\theta b=b.')
+p('混合点仍满足同一方程，所以证明完成，不需要 A 可逆或解唯一。无解时 C 为空，条件因没有可选的两点而自动成立。非空时，第二章的 x₀+N(A) 也直接说明它是平移后的子空间。','The mixed point solves the equation, without requiring invertible A or a unique solution. If C is empty, the condition holds vacuously. When nonempty, Chapter 2 representation x₀+N(A) also shows it is a translated subspace.')
+p('含一组点的最小仿射集叫仿射包。它由这些点的仿射组合组成：系数和等于 1，但系数允许为负。','The smallest affine set containing given points is their affine hull. It consists of affine combinations, whose coefficients sum to one but may be negative.')
+m(r'\operatorname{aff}S=\left\{\sum_{i=1}^k\theta_i x_i:x_i\in S,\ \theta_i\in\mathbb R,\ \sum_i\theta_i=1,\ k\geq1\right\}.')
+ex('ex19','两点 (1,0)、(0,1) 的仿射包是什么？其中是否包含原点？','What is the affine hull of (1,0) and (0,1)? Does it contain zero?','写成 (1−θ,θ)，观察坐标之和。','Write the combination as (1−θ,θ) and inspect the coordinate sum.',p('仿射包是整条直线 x₁+x₂=1，θ 可以取任意实数。原点坐标之和为零，故不在其中。','The affine hull is the entire line x₁+x₂=1, for arbitrary real θ. The origin has coordinate sum zero and is excluded.')))

unit('20','3.2 凸集、凸包与锥','3.2 Convex sets, convex hulls and cones',
p('实际方案往往只能按非负比例混合，不能向两侧无限延伸。因此把上一节 θ 的范围限制到 [0,1]：若任意两点之间的整段线段都留在集合内，就称集合凸。','Practical plans are usually mixed in nonnegative proportions rather than extended indefinitely. Restrict θ to [0,1]: a set is convex if it contains the whole segment joining any two of its points.')
+m(r'x,y\in C,\quad0\leq\theta\leq1\quad\Longrightarrow\quad(1-\theta)x+\theta y\in C.')
+p('圆盘是凸的，只有圆周的集合不是：圆周上的两个对径点，其中点是圆心，不在圆周上。每个仿射集都凸，因为它允许更广的 θ；反向一般不成立，例如有限线段凸，却不含向外延长的直线。','A filled disk is convex, but its circumference alone is not: the midpoint of opposite boundary points is the missing center. Every affine set is convex because it permits all real θ. A finite segment shows the converse fails.')
+p('含 S 的最小凸集叫凸包。它由有限个点的凸组合组成，即非负系数、总和为 1。三点不共线时，凸包是填满的三角形。','The convex hull is the smallest convex set containing S. It consists of finite convex combinations: nonnegative coefficients summing to one. Three noncollinear points generate a filled triangle.')
+m(r'\operatorname{conv}S=\left\{\sum_{i=1}^k\theta_i x_i:x_i\in S,\ \theta_i\geq0,\ \sum_i\theta_i=1\right\}.')
+'<div data-figure="20"></div>'
+p('为什么两点定义也允许有限点混合？把前 k−1 项先归一化成一个点，再与第 k 项做两点混合，逐次归纳即可。若最后一项权重为 1，其余都为零，直接就是原点列中的第 k 点。这种分组方法在第四章证明 Jensen 不等式时会详细使用。','Why does the two-point definition allow finite mixtures? Normalize the first k−1 terms to one point, then mix with the last point, using induction. If the last weight is one, all others vanish and the combination is just that point. Chapter 4 uses this grouping method in detail for Jensen inequality.')
+h('只允许放大缩小：锥','Scaling without a fixed total: cones')
+p('集合 K 若对非负缩放封闭，即 x∈K、α≥0 时 αx∈K，就叫锥。非空锥因此包含原点。若它也凸，就叫凸锥；把缩放和两点混合结合起来，可知凸锥对任意非负线性组合封闭。一般锥不自动凸，例如两条不同方向的射线之并。','A cone is closed under nonnegative scaling: x∈K and α≥0 imply αx∈K. A nonempty cone therefore contains zero. A convex cone is also convex; scaling and mixing together make it closed under nonnegative combinations. A cone need not be convex: the union of two distinct rays may fail the segment test.')
+m(r'\operatorname{cone}S=\left\{\sum_{i=1}^k\alpha_i x_i:x_i\in S,\ \alpha_i\geq0\right\}.')
+p('上式的锥包包含原点。比较这四类组合时，只检查系数限制就能分清：线性组合无系数限制；仿射组合要求和为 1；凸组合再要求非负；锥组合只要求非负，不固定总和。','The conic hull above contains zero. The coefficient rules distinguish the constructions: linear combinations have no restrictions; affine combinations sum to one; convex combinations additionally have nonnegative coefficients; conic combinations require nonnegative coefficients without fixing their sum.')
+ex('ex20','S={(1,0),(0,1)}。写出它的凸包和锥包。','For S={(1,0),(0,1)}, describe its convex and conic hulls.','凸包固定系数和为 1，锥包只要求各系数非负。','The convex hull fixes the coefficient sum to one; the conic hull requires only nonnegativity.',p('凸包为 x₁,x₂≥0 且 x₁+x₂=1 的线段。锥包为 x₁,x₂≥0 的整个第一象限，包含原点。','The convex hull is the segment x₁,x₂≥0 with x₁+x₂=1. The conic hull is the entire nonnegative quadrant including zero.')))

unit('21','3.3 常见凸集：从不等式读出形状','3.3 Common convex sets from inequalities',
p('认识凸集时，既可以画图，也要能从约束证明。先看一个非零向量 a：等式 aᵀx=b 给出超平面，a 是法向；在二维它是一条直线。把等号换成 ≤，得到一侧的闭半空间。要求 a≠0，是为了排除整个空间或空集这种退化等式。','To recognize convex sets, combine pictures with proofs from constraints. For nonzero a, aᵀx=b defines a hyperplane with normal a, a line in two dimensions. Replacing equality by ≤ gives a closed halfspace. The condition a≠0 excludes degenerate equations defining all space or nothing.')
+p('若两个点都满足 aᵀx≤b，其凸组合也满足：线性运算把左边变成两项的加权平均，而平均仍不超过 b。所以半空间凸，超平面的证明与 3.1 相同。','If two points satisfy aᵀx≤b, their convex combination also does: linearity makes the left side the weighted average of two values at most b. Thus halfspaces are convex; hyperplanes follow Section 3.1.')
+h('球的证明为什么用三角不等式？','Why use the triangle inequality for balls?')
+p('范数球以 x₀ 为中心、半径 r≥0，条件为 ‖x−x₀‖≤r。取球内 x、y，先从混合点减去球心，再用齐次性和三角不等式：','A norm ball of center x₀ and radius r≥0 has ‖x−x₀‖≤r. For x,y in the ball, subtract the center from their mixture, then apply homogeneity and the triangle inequality:')
+m(r'\|(1-\theta)x+\theta y-x_0\|\leq(1-\theta)\|x-x_0\|+\theta\|y-x_0\|\leq r.')
+p('这对每个 θ∈[0,1] 成立，所以球凸；r=0 时球只有球心，也已包含在证明中。正定 P 定义的椭球 (x−x₀)ᵀP(x−x₀)≤1 是二次范数球，因而也凸。','This holds for all θ∈[0,1], proving convexity, including r=0 where the ball is a singleton. For positive definite P, the ellipsoid (x−x₀)ᵀP(x−x₀)≤1 is a quadratic-norm ball and is therefore convex.')
+h('例：离哪个点更近？','Example: which point is closer?')
+p('给定不同的 a、b，问哪些位置 x 离 a 不比离 b 远。距离本身含平方根，但两边非负，平方不会改变不等号。展开后 xᵀx 消去，留下线性条件：','For distinct a,b, find locations x no farther from a than from b. Both distances are nonnegative, so squaring preserves their comparison. Expand and cancel xᵀx to obtain a linear inequality:')
+m(r'\|x-a\|_2\leq\|x-b\|_2\iff2(b-a)^Tx\leq\|b\|_2^2-\|a\|_2^2.')
+p('b−a≠0，故它确实是半空间。图中 a=(0,0)、b=(2,0)，得到 x₁≤1。边界是垂直平分线，包含边界是因为题目允许距离相等。','Since b−a≠0, this is a genuine halfspace. In the diagram a=(0,0), b=(2,0) give x₁≤1. The boundary is the perpendicular bisector and is included because equal distances are allowed.')
+'<div data-figure="21"></div>'
+ex('ex21','a=(−1,2)，b=(3,0)。把离 a 不比离 b 远的集合写成半空间。','For a=(−1,2), b=(3,0), express the points no farther from a as a halfspace.','分别算 2(b−a) 与 ‖b‖₂²−‖a‖₂²，再检查点 a 应该在内。','Compute 2(b−a) and the squared-length difference. Verify that a is included.',m(r'2(b-a)=(8,-4),\quad\|b\|_2^2-\|a\|_2^2=9-5=4,\quad2x_1-x_2\leq1.')+p('代入 a 得 −4≤1，代入 b 得 6≤1 不成立，与距离含义一致。','Point a gives −4≤1; point b gives the false 6≤1, agreeing with the distance interpretation.')))

unit('22','3.4 多面体、单纯形与半正定锥','3.4 Polyhedra, simplexes and the PSD cone',
p('多个线性约束同时成立时，可行集是多个半空间和超平面的交，称为多面体。有限个约束即可定义它，形状不必有界。例如第一象限由 x₁≥0、x₂≥0 定义，向外无限延伸。','Simultaneous linear constraints give the intersection of finitely many halfspaces and hyperplanes, a polyhedron. It need not be bounded: the quadrant x₁≥0,x₂≥0 extends indefinitely.')
+m(r'C=\{x:Gx\leq h,\ Ax=b\}.')
+p('单纯形是另一种常见形状：把仿射独立的点取凸包。仿射独立指以其中一点为起点的差向量线性独立。二维三个不共线点形成三角形。标准单纯形则直接把凸组合的权重作为坐标：','A simplex is the convex hull of affinely independent points: their differences from one chosen point are linearly independent. Three noncollinear planar points form a triangle. The standard simplex uses mixture weights themselves as coordinates:')
+m(r'\Delta=\{\theta\in\mathbb R^k:\theta_i\geq0,\ \sum_i\theta_i=1\}.')
+p('k=3 时只有两个自由参数，因为 θ₃=1−θ₁−θ₂。图的横纵轴是 θ₁、θ₂；它画的是三维平面中三角形的二维参数图。在 R³ 中这个集合没有普通内点，但在自身平面中有相对内部。','For k=3 there are only two free parameters since θ₃=1−θ₁−θ₂. The plot uses θ₁,θ₂ and parametrizes a triangle in a three-dimensional plane. It has empty ordinary interior in R³ but nonempty relative interior within its plane.')
+'<div data-figure="22"></div>'
+h('矩阵也可以组成凸集','Matrices can form convex sets')
+p('所有 n×n 实对称半正定矩阵组成半正定锥 Sⁿ₊。若 X、Y 半正定，对任意 v，vᵀ[(1−θ)X+θY]v 是两个非负数的非负加权和，所以混合矩阵半正定。非负缩放同样保持非负，因此它也是凸锥。','The real symmetric PSD n×n matrices form the PSD cone Sⁿ₊. For PSD X,Y and any v, the quadratic form of (1−θ)X+θY is a nonnegative weighted sum of nonnegative numbers. Scaling by a nonnegative scalar also preserves the property, so this is a convex cone.')
+ex('ex22','三维标准单纯形的点 (1/4,1/4,1/2) 是相对内点吗？是 R³ 中的内点吗？','Is (1/4,1/4,1/2) relatively interior to the three-coordinate standard simplex? Is it interior in R³?','检查三个坐标是否严格正；然后考虑离开坐标和为 1 的平面。','Check positivity, then consider leaving the plane where coordinates sum to one.',p('它的三个坐标严格正，在平面内足够小的扰动仍能保持非负，故是相对内点。任意三维开球包含坐标和不为 1 的点，故不是 R³ 内点。','All coordinates are positive, so sufficiently small perturbations within the plane remain nonnegative: it is relatively interior. Every three-dimensional ball contains points whose coordinates do not sum to one, so it is not interior in R³.')))

unit('23','3.5 保持凸性的集合运算','3.5 Set operations preserving convexity',
p('遇到复杂可行集，不必每次从头证明。先把它拆成已知凸集及保持凸性的运算。最简单的是交集：如果 x、y 同时满足每一组凸约束，它们的线段也同时满足每组约束。因此任意多个凸集的交仍凸，交集为空也不例外。','For complicated feasible sets, decompose them into known convex sets and convexity-preserving operations. Intersections are simplest: if x,y satisfy every convex constraint, their segment does too. Any intersection of convex sets is convex, including an empty intersection result.')
+'<div data-figure="23"></div>'
+p('并集一般不保持凸性。例如两个分离的圆盘分别凸，跨圆盘取两点，中间线段却可能穿过空白。','Unions generally fail to preserve convexity. Two separated disks are individually convex, but a segment joining them can cross the gap.')
+h('仿射像与原像','Affine images and preimages')
+p('设 f(x)=Ax+b。凸集 C 的像是所有 f(x)，x∈C。两个像点混合后等于原点混合再映射，因为 f((1−θ)x+θy)=(1−θ)f(x)+θf(y)，所以像仍凸。这个证明允许 A 是矩形或不可逆矩阵。','For f(x)=Ax+b, the image of convex C contains all f(x) with x∈C. Mixing two image points equals mapping the mixture, so the image is convex. A may be rectangular or noninvertible.')
+p('原像则反过来问：哪些输入的输出落在给定凸集 D？记号 f⁻¹(D) 在这里表示集合原像，不要求逆函数存在。若 x、y 的输出都在 D，混合输出仍在 D，所以原像也凸。','The preimage asks which inputs produce outputs in a convex target D. The notation f⁻¹(D) does not require an inverse function. Feasible outputs remain in D under mixing, so the preimage is convex too.')
+m(r'f^{-1}(D)=\{x:Ax+b\in D\}.')
+p('例如 {x:‖Ax−b‖₂≤1} 是欧氏球在仿射映射下的原像，故凸。两个凸集的和 C+D={x+y:x∈C,y∈D} 也凸：对两组和作混合时，分别混合 C 中和 D 中的两点即可。','For example, {x:‖Ax−b‖₂≤1} is an affine preimage of a Euclidean ball, hence convex. The sum C+D={x+y:x∈C,y∈D} is convex too: mix the C components and D components separately.')
+ex('ex23','A 不可逆时，{x:‖Ax‖₂≤1} 是否仍凸？','Is {x:‖Ax‖₂≤1} convex when A is singular?','原像证明有没有使用逆矩阵？','Did the preimage proof use an inverse matrix?',p('仍凸。它是线性映射 x↦Ax 下单位球的原像。也可直接用 ‖A((1−θ)x+θy)‖₂≤(1−θ)‖Ax‖₂+θ‖Ay‖₂≤1。不可逆只可能使集合无界，不破坏此证明。','Yes. It is the preimage of the unit ball under x↦Ax. Directly, ‖A((1−θ)x+θy)‖₂≤(1−θ)‖Ax‖₂+θ‖Ay‖₂≤1. Singularity may make the set unbounded but does not affect the proof.')))

unit('24','3.6 透视与线性分式映射','3.6 Perspective and linear-fractional maps',
p('仿射映射保持混合比例。透视映射则把点 (z,t) 沿过原点的射线投到高度 1，得到 z/t。这里必须要求 t>0；分母符号决定后面的混合权重是否仍非负。','Affine maps preserve mixture weights. A perspective map sends (z,t) along its ray from zero to height one, producing z/t. Require t>0: its sign determines whether transformed mixture weights stay nonnegative.')
+m(r'P(z,t)=z/t,\qquad t>0.')
+'<div data-figure="24"></div>'
+p('例如 (0,1)、(2,2) 分别映到 0、1。输入中点 (1,1.5) 却映到 2/3，而非输出中点 1/2。因此透视不是仿射，但它仍会把凸集变成凸集，原因是混合权重发生了可控制的改变。','For (0,1) and (2,2), the images are zero and one. Their midpoint (1,1.5) maps to 2/3 rather than one half. Perspective is not affine, but preserves convexity because the change of weights is controlled.')
+p('记 qᵢ=zᵢ/tᵢ。先混合两个输入，再作透视，得到两个输出的凸组合：','Write qᵢ=zᵢ/tᵢ. Mixing inputs before applying perspective gives a convex combination of outputs:')
+m(r'\frac{(1-\theta)z_1+\theta z_2}{(1-\theta)t_1+\theta t_2}=(1-\lambda)q_1+\lambda q_2,\qquad\lambda=\frac{\theta t_2}{(1-\theta)t_1+\theta t_2}.')
+p('t₁、t₂ 正，故分母正且 λ∈[0,1]。为了证明像凸，还要确认任意输出权重 λ 都能得到。给定 λ，取 θ=λt₁/((1−λ)t₂+λt₁)，它也在 [0,1]，代入即还原 λ。因此输出整段线段都可由凸的输入集产生。','Positive t₁,t₂ make λ∈[0,1]. To prove the image convex, also obtain every desired λ: choose θ=λt₁/((1−λ)t₂+λt₁). This lies in [0,1] and recovers λ, so the entire output segment arises from the convex input set.')
+p('线性分式映射先做仿射映射，再作透视：f(x)=(Ax+b)/(cᵀx+d)，定义域限制 cᵀx+d>0。它保持凸集的像；凸目标集的原像也凸，可由刚才的正权重关系直接核对。正分母条件始终要与映射一起保留。','A linear-fractional map is an affine map followed by perspective: f(x)=(Ax+b)/(cᵀx+d), on cᵀx+d>0. It preserves convexity of images and preimages of convex target sets, using the same positive-weight identity. Always retain the positive-denominator domain.')
+ex('ex24','上面两个输入点要得到输出中点 1/2，输入应如何混合？','How should the two example inputs be mixed to obtain output one half?','令 t₁=1、t₂=2、λ=1/2，代入 θ 的反解。','Use t₁=1, t₂=2 and λ=1/2 in the inverse weight formula.',p('θ=1/3，输入为 (2/3,4/3)，透视后为 1/2。输入不取中点，正说明混合参数发生了改变。','θ=1/3 gives input (2/3,4/3), whose perspective is one half. The input is not the midpoint, demonstrating the change of mixture parameter.')))

unit('25','3.7 正常锥与广义不等式','3.7 Proper cones and generalized inequalities',
p('实数可以比较大小，但向量的某些分量更小、另一些更大时，怎样比较？一种自然选择是先规定哪些差向量表示“非负”。给定锥 K，若 y−x∈K，就记 x⪯Ky。例如 K 为非负正交象限时，它表示每个坐标分别不大于。','Real numbers have an order, but vectors can improve in one component and worsen in another. Specify which difference vectors count as nonnegative. For a cone K, write x⪯Ky when y−x∈K. The nonnegative orthant gives componentwise comparison.')
+m(r'x\preceq_K y\quad\Longleftrightarrow\quad y-x\in K.')
+p('为了让这个比较稳定而有意义，课件使用正常锥（proper cone）：它是闭、凸、内部非空且尖的锥。凸锥的加法封闭保证传递性，尖性 K∩(−K)={0} 保证若两边互相不大于就必须相等；闭性保证极限下不丢失不等式，非空内部则提供严格比较的方向。','The slides use proper cones: closed, convex, with nonempty interior and pointed, K∩(−K)={0}. Closure under addition gives transitivity; pointedness gives antisymmetry. Closedness preserves comparisons under limits, while a nonempty interior provides strict comparison directions.')
+p('例如 x⪯Ky、y⪯Kz 时，两个差向量在 K 中，相加得到 z−x∈K，所以 x⪯Kz。严格锥序写 x≺Ky，定义为 y−x∈int K；它通常比“⪯ 且不相等”更强，不能混用。','If x⪯Ky and y⪯Kz, add the two differences in K to obtain z−x∈K. Strict cone order x≺Ky means y−x∈int K; it is generally stronger than x⪯Ky with x≠y.')
+h('例：二阶锥逐项检查','Example: checking the second-order cone')
+p('二阶锥把一个长度和一个标量比较，定义在 Rⁿ×R 中。t 可以理解为允许的长度上限，必须不小于 ‖x‖₂：','The second-order cone compares a vector length with a scalar in Rⁿ×R. Think of t as an allowance that must be at least ‖x‖₂:')
+m(r'K=\{(x,t):\|x\|_2\leq t\}.')
+'<div data-figure="25"></div>'
+p('先证缩放与凸性。非负缩放时长度与 t 同倍变化，仍满足约束。两个锥内点的凸组合满足下面的三角不等式，因此凸：','For nonnegative scaling, both length and t scale together. For two feasible points, the triangle inequality proves feasibility of their convex combination:')
+m(r'\|(1-\theta)x+\theta y\|_2\leq(1-\theta)\|x\|_2+\theta\|y\|_2\leq(1-\theta)t+\theta s.')
+p('再证闭性。若 (xₖ,tₖ)∈K 且趋于 (x,t)，由三角不等式 ‖x‖₂≤‖x−xₖ‖₂+‖xₖ‖₂≤‖x−xₖ‖₂+tₖ。令 k→∞，得到 ‖x‖₂≤t，所以极限仍在 K。','For closedness, let (xₖ,tₖ) in K converge to (x,t). The triangle inequality gives ‖x‖₂≤‖x−xₖ‖₂+‖xₖ‖₂≤‖x−xₖ‖₂+tₖ. Passing to the limit gives ‖x‖₂≤t, so the limit stays in K.')
+p('内部非空可以直接放入一个环境空间的球：以 (0,1) 为中心、半径 1/2。球内有 ‖x‖₂<1/2 且 |t−1|<1/2，所以 t>1/2>‖x‖₂。最后若 (x,t) 与 (−x,−t) 都在 K，则 ‖x‖₂≤t 且 ‖x‖₂≤−t，只能 t=0、x=0，故锥尖。四项性质全部验证，K 是正常锥。','An ambient Euclidean ball of radius one half centered at (0,1) lies inside K: its points have ‖x‖₂<1/2 and t>1/2. Finally, if both (x,t) and (−x,−t) are in K, then ‖x‖₂≤t and ‖x‖₂≤−t force x=0,t=0. Thus K is pointed. All four properties hold.')
+ex('ex25','对于二阶锥，写出 (x,t)⪯K(y,s) 的范数形式，并直接证明三个点间的传递性。','Express (x,t)⪯K(y,s) using a norm, then prove transitivity directly for three points.','先把差向量代进 K；两次比较相加时用三角不等式。','Substitute the difference in K, then use the triangle inequality for two successive comparisons.',m(r'(x,t)\preceq_K(y,s)\iff\|y-x\|_2\leq s-t.')+p('若另有 ‖z−y‖₂≤r−s，则 ‖z−x‖₂≤‖z−y‖₂+‖y−x‖₂≤r−t，正是 (x,t)⪯K(z,r)。','If also ‖z−y‖₂≤r−s, then ‖z−x‖₂≤‖z−y‖₂+‖y−x‖₂≤r−t, which is (x,t)⪯K(z,r).')))

unit('26','3.8 最小、极小与弱极小','3.8 Minimum, minimal and weakly minimal points',
p('在向量偏序下，一个点可能与许多点不可比较。设两个坐标分别表示费用和误差，都越小越好。方案 (1,4) 费用低，(4,1) 误差低，谁也没有在两个指标上同时胜过对方。因此需要区分“比所有点都小”和“没有点能支配它”。','In a partial order, many vectors are incomparable. If coordinates represent cost and error, both to be minimized, (1,4) is cheaper while (4,1) is more accurate. Neither improves both coordinates. Distinguish being below every point from having no dominating competitor.')
+p('x∈S 是最小元素，要求 x⪯Ky 对所有 y∈S 成立。x 是极小元素，则只要求不存在不同的 y∈S 满足 y⪯Kx。最小元素若存在，由尖性至多一个；极小元素可以很多，也可以没有。','A minimum x∈S satisfies x⪯Ky for every y∈S. A minimal x has no distinct y∈S with y⪯Kx. Pointedness makes a minimum unique if it exists; minimal points can be numerous or absent.')
+'<div data-figure="26"></div>'
+p('例如 S={(0,1),(1,0)} 中两点都极小，但没有最小元素。若加入 (0,0)，它就成为最小元素，也支配原来的两点。图中连线只是帮助看位置，不能据此认定连线上的中间方案可行。','In S={(0,1),(1,0)}, both points are minimal but no minimum exists. Adding (0,0) makes it a minimum, dominating the original points. Connecting lines in a plot do not assert feasibility of intermediate plans.')
+p('弱极小只排除严格改善的点：不存在 y∈S 使 y≺Kx。对非负正交象限，这要求所有坐标都严格更小。它比极小弱；例如 S={(1,1),(1,2)} 中 (1,2) 被 (1,1) 支配，故不极小，但没有点让两个坐标都严格下降，所以它仍弱极小。','Weak minimality excludes y≺Kx, strict improvement in every coordinate for the orthant. This is weaker: in S={(1,1),(1,2)}, point (1,2) is dominated by (1,1) and is not minimal, but is weakly minimal since neither point decreases both coordinates strictly.')
+ex('ex26','S={(1,3),(2,2),(3,3)} 中哪些点极小？是否有最小元素？','Which points are minimal in S={(1,3),(2,2),(3,3)}? Is there a minimum?','逐点寻找是否有另一个点两坐标均不大于它，且至少一项更小。','For each point, seek another no larger in either coordinate and smaller in at least one.',p('(1,3)、(2,2) 极小且不可比较。(3,3) 被它们支配，不极小。没有一个点不大于所有其他点，所以没有最小元素。','Points (1,3) and (2,2) are minimal and incomparable. Both dominate (3,3), which is not minimal. No point lies below all others, so no minimum exists.')))

unit('27','3.9 分离：用一个线性评分区分集合','3.9 Separation by a linear score',
p('凸集虽可能由复杂约束定义，却常能用线性评分描述它与外部点的区别。最简单的图像是两个不相交圆盘：找一条直线，让它们分居两侧。高维中直线换成超平面。','A convex set may have complicated constraints yet admit a linear score distinguishing it from another set or an outside point. Picture two disjoint disks on opposite sides of a line. In higher dimensions the line becomes a hyperplane.')
+m(r'a\ne0,\qquad a^Tx\leq b\ \ (x\in C),\qquad a^Ty\geq b\ \ (y\in D).')
+p('这叫弱分离，允许点落在超平面上；严格分离则要求存在正间隙，例如 supₓ∈C aᵀx < infᵧ∈D aᵀy。两种说法的假设不同，不能只凭两个集合不相交就断言有正间隙。','This is weak separation, allowing points on the hyperplane. Strict separation requires a gap, for example sup over C of aᵀx less than inf over D of aᵀy. Disjointness alone does not guarantee that gap.')
+'<div data-figure="27"></div>'
+p('本章使用有限维分离定理：两个非空、不相交的凸集可以弱分离。若其中一个紧致、另一个闭，则可以严格分离。例如点 z 位于非空闭凸集 C 外面时，点集 {z} 紧致，因此严格分离成立。一般非闭情形如 C=(−∞,0)、D={0}，只能在边界零处接触，无法留出正间隙。','We use the finite-dimensional separation theorem: two nonempty disjoint convex sets can be weakly separated. If one is compact and the other closed, strict separation is possible. Thus an outside point can be strictly separated from a nonempty closed convex set. Nonclosed examples such as C=(−∞,0), D={0} need not have a positive gap.')
+h('外部点的分离方向从哪里来？','Where does the separating direction come from?')
+p('对非空闭凸 C，取离 z 最近的点 p，令 a=z−p≠0。最近点存在：可将搜索限制到一个足够大的闭球内，再用连续函数在紧集取极小值。对任意 x∈C，线段 p+θ(x−p) 留在 C，故距离平方在 θ=0 处不能向右下降。求右导数得','For nonempty closed convex C, choose a nearest point p to z and a=z−p≠0. A nearest point exists by restricting the search to a sufficiently large closed ball and minimizing continuous distance on the resulting compact set. For x∈C, p+θ(x−p) stays feasible, so squared distance cannot decrease to the right at θ=0. Its right derivative gives')
+m(r'-2(z-p)^T(x-p)\geq0\quad\Longrightarrow\quad a^Tx\leq a^Tp<a^Tz,\qquad a^Tz-a^Tp=\|a\|_2^2>0.')
+p('所以最近点提供了明确的法向和正间隙。C 的凸性在这里保证线段可行，闭性负责最近点存在；两者各有作用。','The nearest point supplies both a normal and a positive gap. Convexity keeps the segment feasible; closedness supports nearest-point existence.')
+ex('ex27','C={x∈R²:x₁≤0}，z=(2,1)。求最近点 p 和一个分离法向。','For C={x∈R²:x₁≤0}, z=(2,1), find a nearest p and separating normal.','保持第二坐标不变，只需把第一坐标移到允许边界。','Keep the second coordinate and move the first to the allowed boundary.',p('p=(0,1)，a=(2,0)。所有 x∈C 有 aᵀx≤0，而 aᵀz=4。取评分阈值 2，可把两者严格分开。','p=(0,1), a=(2,0). All x∈C satisfy aᵀx≤0, while aᵀz=4. Score threshold two strictly separates them.')))

unit('28','3.10 支撑超平面：在边界托住集合','3.10 Supporting hyperplanes at a boundary',
p('分离把两个集合分居两侧。若一个超平面通过 C 的边界点 x₀，同时把整个 C 留在同一侧，就称为 C 在 x₀ 的支撑超平面。法向必须非零：','A supporting hyperplane passes through a boundary point x₀ and leaves the whole set C on one side. Its normal must be nonzero:')
+m(r'a\ne0,\qquad a^T(x-x_0)\leq0\quad\text{for every }x\in C.')
+p('例如单位圆盘在 x₀=(1,0) 处由 x₁=1 支撑，法向为 (1,0)。这与第二章对偶范数图中的“最后接触”相同：固定方向 a，使线性评分在单位球上达到最大值。','The unit disk is supported at x₀=(1,0) by x₁=1, with normal (1,0). This is the last contact in the dual-norm diagram: maximize the linear score in direction a over the ball.')
+'<div data-figure="28"></div>'
+p('支撑超平面定理说：非空凸集的每个边界点都存在支撑超平面；边界点即使不属于集合，也可对其闭包理解这个支撑。若想用“在某个可行边界点接触”的说法，就明确取 x₀∈C∩∂C。非凸集合则不保证每个边界点都有全局支撑。','The supporting-hyperplane theorem gives a supporting hyperplane at every boundary point of a nonempty convex set. If a boundary point is excluded, understand support through its closure. For actual feasible contact take x₀∈C∩∂C. Nonconvex sets need not have global support at every boundary point.')
+p('椭球 C={x:xᵀPx≤1}、P≻0，在边界点 x₀ 的一个法向是 Px₀。它非零，因为边界上 x₀≠0 且 P 可逆。换到 P½ 坐标，柯西–施瓦茨给出','For ellipsoid C={x:xᵀPx≤1} with P≻0, a normal at boundary x₀ is Px₀, nonzero since x₀≠0 and P is invertible. Cauchy–Schwarz in transformed coordinates gives')
+m(r'(Px_0)^Tx=(P^{1/2}x_0)^T(P^{1/2}x)\leq1=(Px_0)^Tx_0.')
+p('这验证了整个椭球都在同侧，不能只检查法向是否垂直于局部切线。支撑是一个全局不等式。','This checks the entire ellipsoid lies on one side. Perpendicularity to a local tangent alone is not enough: support is a global inequality.')
+ex('ex28','椭圆 4x₁²+x₂²≤1 在 x₀=(1/2,0) 的支撑直线是什么？','Find a supporting line of 4x₁²+x₂²≤1 at x₀=(1/2,0).','法向取 Px₀，P=diag(4,1)。','Use normal Px₀ for P=diag(4,1).',p('Px₀=(2,0)，所以支撑直线 2x₁=1，即 x₁=1/2；整个椭圆满足 x₁≤1/2。','Px₀=(2,0), giving 2x₁=1, or x₁=1/2. The full ellipse satisfies x₁≤1/2.')))

unit('29','3.11 对偶锥：哪些评分总是非负','3.11 Dual cones: scores nonnegative on a cone',
p('对一个给定锥 K，问哪些系数 y 能让所有 x∈K 都有 yᵀx≥0。这些 y 组成对偶锥 K*。它与对偶范数不同：这里不限制单位长度，也不求最大值，只要求对整个锥内所有点都通过非负测试。','For a given cone K, ask which coefficients y give yᵀx≥0 for every x∈K. They form the dual cone K*. Unlike a dual norm, this is a set defined by nonnegative tests, without a unit-length restriction or maximization.')
+m(r'K^*=\{y:y^Tx\geq0\ \text{for every }x\in K\}.')
+p('每个固定 x 给一个闭半空间，因此 K* 是闭凸锥。非负正交象限的对偶仍是自己：非负坐标内积非负；若 y 某项负，用该坐标单位向量测试就失败。一个子空间的对偶是它的正交补，因为 x 与 −x 同时可选，内积只能为零。','Each fixed x defines a closed halfspace, so K* is a closed convex cone. The nonnegative orthant is self-dual: nonnegative coordinates pair nonnegatively, while a negative coordinate is exposed by its coordinate unit vector. A subspace has dual equal to its orthogonal complement, since both x and −x are allowed.')
+h('二阶锥为何自对偶？','Why is the second-order cone self-dual?')
+p('对 K={(x,t):‖x‖₂≤t}，内积采用 yᵀx+st。证明 K*=K 必须两向进行。先取 (y,s)∈K，即 ‖y‖₂≤s，对任意 (x,t)∈K，','For K={(x,t):‖x‖₂≤t}, use inner product yᵀx+st. Prove both inclusions. If (y,s)∈K, then for every (x,t)∈K,')
+m(r'y^Tx+st\geq-\|y\|_2\|x\|_2+st\geq-\|y\|_2t+st=t(s-\|y\|_2)\geq0.')
+p('这里 t≥0。因此 K⊆K*。反向设 (y,s)∈K*，先用锥内点 (0,1) 测试，得 s≥0，排除负的 s。若 y≠0，再用 (−y/‖y‖₂,1) 测试：','Here t≥0, proving K⊆K*. Conversely take (y,s)∈K*. Testing (0,1) gives s≥0. If y≠0, test (−y/‖y‖₂,1):')
+m(r'0\leq y^T\left(-\frac y{\|y\|_2}\right)+s=s-\|y\|_2.')
+p('于是 s≥‖y‖₂，故该点属于 K。y=0 时，先得到的 s≥0 已给出同样结论，无须除以零。两向合并即自对偶。','Thus s≥‖y‖₂, giving membership in K. For y=0 the initial s≥0 already suffices, without dividing by zero. Both inclusions prove self-duality.')
+'<div data-figure="29"></div>'
+extra('一般范数锥与矩阵锥','General norm cones and matrix cones',p('将欧氏范数换成任意范数 N，锥 K={(x,t):N(x)≤t} 的对偶是 {(y,s):N*(y)≤s}。正向用第二章的 |yᵀx|≤N*(y)N(x)；反向取 N(x)=1 且使 yᵀx=−N*(y) 的方向测试，y=0 时另取 (0,1)。','For any norm N, the dual of K={(x,t):N(x)≤t} is {(y,s):N*(y)≤s}. Sufficiency uses |yᵀx|≤N*(y)N(x); necessity tests a unit vector attaining the negative dual score, with (0,1) handling y=0.')+p('半正定锥在迹内积下也自对偶。若 X,Y⪰0，tr(XY)=tr(X½YX½)≥0，因为后者半正定，迹为非负特征值之和。反向若对称 Y 不是半正定，存在 v 使 vᵀYv<0，取 X=vvᵀ⪰0 就有 tr(XY)<0。','The PSD cone is also self-dual under trace inner product. For X,Y PSD, tr(XY)=tr(X½YX½)≥0, the trace of a PSD matrix. Conversely a symmetric non-PSD Y has vᵀYv<0; X=vvᵀ is PSD and gives tr(XY)<0.'))
+ex('ex29','点 ((3,4),4) 不在二阶锥内。构造一个锥内测试点，使两者内积为负。','For the point ((3,4),4) outside the second-order cone, construct an in-cone point with negative pairing.','取 x 与 (3,4) 反向且长为 1，t=1。','Choose unit x opposite (3,4), with t=1.',m(r'(x,t)=((-3/5,-4/5),1),\qquad(3,4)^Tx+4t=-5+4=-1.')+p('负内积直接证明给定点不属于对偶锥；自对偶性也说明它不属于原锥。','The negative pairing excludes the given point from the dual cone; self-duality also excludes it from K. The point being tested is ((3,4),4).')))

unit('30','3.12 对偶评分与 Pareto 前沿','3.12 Dual scores and Pareto frontiers',
p('现在把锥序与线性评分联系起来。如果 y−x∈K，那么每个 w∈K* 都满足 wᵀx≤wᵀy。所以锥序比较包含一整族线性评分的比较。若 K 闭且凸，分离定理还保证反向成立：若差向量不在 K，就能找到某个对偶评分揭示它。','Cone order implies comparisons of linear scores: y−x∈K gives wᵀx≤wᵀy for every w∈K*. For a closed convex cone the converse follows from separation: a difference outside K is exposed by some dual score.')
+m(r'x\preceq_Ky\quad\Longleftrightarrow\quad w^Tx\leq w^Ty\ \text{for every }w\in K^*\qquad(K\text{ closed convex}).')
+p('因此 x∈S 是最小元素，等价于它同时最小化每个对偶线性评分。只最小化某一个评分通常不足以得到最小元素，因为该评分可能忽略某些方向。','Thus x∈S is a minimum exactly when it minimizes every dual linear score. Minimizing just one score generally does not establish a minimum, since that score may ignore directions.')
+h('多目标问题怎样选择一个方案？','Selecting a plan with multiple objectives')
+p('对费用、误差等多目标，常把它们加权成一个标量再最小化。若所有权重严格正，最优点必极小：倘若另有点各项都不大于它，且至少一项严格更小，正加权和就会严格下降，矛盾。','A common approach is minimizing a weighted sum of cost, error and other objectives. With every weight strictly positive, any minimizer is minimal: a point no worse in every coordinate and strictly better in one would have a strictly smaller weighted score.')
+m(r'\min_{y\in S}\sum_i w_i y_i,\qquad w_i>0.')
+p('若某个权重为零，这个保证会减弱。例如 S={(1,1),(1,2)}、w=(1,0)，两点得分相同，较差的 (1,2) 也能成为加权最优点。所有极小目标点组成 Pareto 前沿，它描述指标之间无法同时改善的权衡。','If a weight is zero, the guarantee weakens. For S={(1,1),(1,2)} and w=(1,0), both scores tie, so even dominated (1,2) is a minimizer. Minimal objective vectors form the Pareto frontier, describing tradeoffs that cannot be improved simultaneously.')
+'<div data-figure="30"></div>'
+extra('权重法的范围','Limits of weighted sums',p('对正常锥，内点权重 w∈int K* 对每个非零 d∈K 都有 wᵀd>0，因此同样保证加权最优点极小。非零边界权重一般只保证弱极小。凸目标集合的极小点可由某个非零非负权重支撑，但不一定由严格正权重取得。非凸目标集合甚至可能有加权和找不到的极小点。','For a proper cone, interior weights w∈int K* have wᵀd>0 for every nonzero d∈K, giving minimal minimizers. Nonzero boundary weights generally guarantee only weak minimality. Minimal points of convex objective sets can have supporting nonzero nonnegative weights, but not necessarily strictly positive ones. Nonconvex sets can have minimal points not found by weighted sums.')+p('例如凸集 S={(x,y):0≤x≤1，y≥(1−x)²} 的 (1,0) 极小。若两个权重都正，从 (1,0) 改成 (1−ε,ε²)，费用减少 w₁ε，误差费用只增加 w₂ε²；足够小 ε 下总分下降，所以该点不能由严格正权重最小化。','For convex S={(x,y):0≤x≤1, y≥(1−x)²}, point (1,0) is minimal. With both weights positive, moving to (1−ε,ε²) reduces the score by w₁ε while adding only w₂ε², so small ε improves the score. Strictly positive weights cannot select that point.'))
+ex('ex30','S={(1,4),(2,2),(4,1)}。权重 (1,1) 选哪一点？(3,1) 呢？','For S={(1,4),(2,2),(4,1)}, which point is selected by weights (1,1)? By (3,1)?','逐点计算加权和，别把坐标分别取最小后拼成不存在的方案。','Compute each weighted score; do not combine separate coordinate minima into an unavailable plan.',p('(1,1) 的得分为 5、4、5，选 (2,2)；(3,1) 的得分为 7、8、13，选 (1,4)。两组权重都正，所以所选点均极小。','Weights (1,1) give 5,4,5 and select (2,2). Weights (3,1) give 7,8,13 and select (1,4). Both weight vectors are positive, so both selected points are minimal.')))

# Round-one editorial responses, applied to the new prose before rendering.
from bs4 import BeautifulSoup
from chapter2_content import UNITS
def _edit(uid,needle,content,replace=False):
    soup=BeautifulSoup(UNITS[uid]['body'],'html.parser')
    target=next(n.find_parent('p') for n in soup.select('p .zh') if needle in n.get_text())
    fragment=BeautifulSoup(content,'html.parser')
    if replace:target.replace_with(fragment)
    else:target.insert_after(fragment)
    UNITS[uid]['body']=str(soup)
_edit('28','换到 P½ 坐标',p('由第二章矩阵平方根恒等式 P½P½=P，上面的内积可这样改写。x₀ 在边界上，故 ‖P½x₀‖₂²=x₀ᵀPx₀=1；x 在椭球内，故 ‖P½x‖₂≤1。把两条长度界代入柯西–施瓦茨，便得到','The square-root identity P½P½=P justifies the rewrite. Boundary membership gives ‖P½x₀‖₂²=x₀ᵀPx₀=1, while x in the ellipsoid has ‖P½x‖₂≤1. Substitute these lengths in Cauchy–Schwarz:')+m(r'(P^{1/2}x_0)^T(P^{1/2}x)\leq\|P^{1/2}x_0\|_2\|P^{1/2}x\|_2\leq1\cdot1=1.'))
_edit('24','记 qᵢ=',p('从像中任取两点 q₁、q₂，分别选择产生它们的输入 (z₁,t₁)、(z₂,t₂)，其中 t₁,t₂>0。这两个高度固定下来后，再混合输入。下式分子是混合后的水平坐标，分母是混合后的高度：','Take any two image points q₁,q₂ and choose preimages (z₁,t₁),(z₂,t₂), with positive heights. Fix these heights and mix the inputs. The numerator below is the mixed horizontal coordinate; the denominator is the mixed height:'),True)
_edit('24','t₁、t₂ 正',p('反解中的分母 (1−λ)t₂+λt₁>0，且减去分子 λt₁ 后为 (1−λ)t₂≥0，故 0≤θ≤1。输入集凸，保证这个反解权重对应的混合输入可行，于是任意指定的输出线段点也可行。','The inverse denominator (1−λ)t₂+λt₁ is positive and exceeds its numerator λt₁ by (1−λ)t₂≥0, so 0≤θ≤1. Input convexity makes this mixture feasible and produces every desired point on the output segment.'))
_edit('26','弱极小只排除',p('这里 y≺Kx 沿用 3.7 的定义，表示 x−y∈int K；正交象限的内部是所有坐标都严格正。因此“不存在严格改善”只排除所有坐标同时严格下降，不排除一项相等、另一项变小的支配。','Here y≺Kx means x−y∈int K as in Section 3.7. The orthant interior has every coordinate strictly positive. Weak minimality therefore excludes improvements strict in every coordinate, but permits domination with a tied coordinate.'))
_edit('29','这里 t≥0',m(r'(0,1)\in K,\qquad0\leq y^T0+s\cdot1=s.'))
_edit('29','于是 s≥',p('y=0 时 ‖y‖₂=0≤s，直接符合 K 的定义；该分支既不需要构造单位方向，也不需要除以 ‖y‖₂。','If y=0, then ‖y‖₂=0≤s directly satisfies the definition of K; no unit direction or division by ‖y‖₂ is needed.'))
UNITS['23']['body']=UNITS['23']['body'].replace('原点混合再映射','原空间中两点混合再映射')
UNITS['29']['body']+=extra('极集与对偶锥的区别','Polar sets versus dual cones',p('非空集合 C 的极集定义为 C°={y:yᵀx≤1 对所有 x∈C}。它限制线性评分的上界为1；对偶锥则要求所有评分非负。若 C 是范数单位球，极集恰是相应对偶范数的单位球，因为这个上界就是对偶范数值。','For nonempty C, the polar is C°={y:yᵀx≤1 for every x∈C}. It bounds scores above by one, whereas a dual cone requires nonnegative scores. The polar of a norm unit ball is the dual-norm unit ball, since the maximum score is the dual norm.'))
_edit('21','这对每个 θ∈[0,1]',p('数值核对一次：球心 c=(1,−1)、半径2，取 x=(3,−1)、y=(1,1)，两点到球心距离都为2。中点为 (2,0)，到球心距离为 √2≤2。这个算例帮助读图，上面的三角不等式才负责所有点与所有混合比例。','For a numerical check, use center c=(1,−1), radius two, and points x=(3,−1), y=(1,1), each at distance two. Their midpoint (2,0) has distance √2≤2. The example aids interpretation; the triangle-inequality proof covers all points and mixture weights.'))
