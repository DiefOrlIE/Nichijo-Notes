"""Package the exact verified revision and synchronize the local preview."""
from pathlib import Path
import hashlib
import json
import shutil
import zipfile

ROOT=Path(__file__).parent
REV=ROOT/"讲稿修订_2026-10-23"
OUT=ROOT/"完整讲义"
PREVIEW=ROOT.parent/"_publish_preview/convex-lectures-1-5"
report=json.loads((REV/"验收记录.json").read_text(encoding="utf8"))
assert len(report["static"])==6 and len(report["browser"])==8
for row in report["static"]:
    assert row["sha256"]==hashlib.sha256((OUT/row["page"]).read_bytes()).hexdigest(),row["page"]
shutil.copy2(REV/"验收记录.json",OUT/"revision-verification.json")
record=json.loads((REV/"生成记录.json").read_text(encoding="utf8"))
mapping=json.loads((OUT/"content-map.json").read_text(encoding="utf8"))
mapping["learning_order"]=record["order"]
mapping["revision_date"]="2026-10-23"
mapping["manuscript_source"]="../讲稿修订_2026-10-23/u01.md—u47.md"
(OUT/"content-map.json").write_text(json.dumps(mapping,ensure_ascii=False,indent=2),encoding="utf8")
historical=OUT/"chapter-rewrite-review.md"
note="> 当前版本：2026-10-23教学审查修订，见 [本轮记录](revision-report.md) 与 [验收结果](revision-verification.json)。下文为此前记录。\n\n"
text=historical.read_text(encoding="utf8")
if not text.startswith(note):
    historical.write_text(note+text,encoding="utf8")
with zipfile.ZipFile(OUT/"lecture-source.zip","w",zipfile.ZIP_DEFLATED) as archive:
    for name in ("generate_review_revision.py","verify_review_revision.py","package_review_revision.py","assemble_continuous_handbook.py","build_continuous_chapters.py"):
        archive.write(ROOT/name,name)
    for file in sorted(REV.rglob("*")):
        if file.is_file() and file.suffix in (".md",".json",".svg",".woff2",".zip"):
            archive.write(file,file.relative_to(ROOT))
    for name in ("README.md","writing-standard.md","revision-report.md","revision-verification.json","content-map.json","source-map.md","hw1-coverage.md"):
        archive.write(OUT/name,Path("完整讲义")/name)
    for file in sorted((OUT/"pages").glob("*.webp")):
        archive.write(file,Path("完整讲义/pages")/file.name)
PREVIEW.mkdir(parents=True,exist_ok=True)
for name in ("index.html","hw1-route.html",*[f"chapter-{i}.html" for i in range(2,6)],
             "README.md","writing-standard.md","revision-report.md","revision-verification.json",
             "chapter-rewrite-review.md","content-map.json","source-map.md","hw1-coverage.md","lecture-source.zip"):
    shutil.copy2(OUT/name,PREVIEW/name)
for file in (OUT/"pages").glob("*.webp"):
    target=PREVIEW/"pages"/file.name
    if not target.exists():
        target.parent.mkdir(exist_ok=True)
        shutil.copy2(file,target)
for row in report["static"]:
    assert (OUT/row["page"]).read_bytes()==(PREVIEW/row["page"]).read_bytes()
(REV/"交付记录.json").write_text(json.dumps({
    "date":"2026-10-23","source_units":47,"html_pages":6,
    "local_preview":str(PREVIEW),"preview_matches_verified_pages":True,
    "source_archive":str(OUT/"lecture-source.zip"),
    "archive_sha256":hashlib.sha256((OUT/"lecture-source.zip").read_bytes()).hexdigest(),
    "online_publish":False
},ensure_ascii=False,indent=2),encoding="utf8")
print("Packaged verified source; six local preview pages match their verified HTML hashes.")
