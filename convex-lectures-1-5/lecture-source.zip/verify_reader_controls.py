from pathlib import Path
import json
from playwright.sync_api import sync_playwright
R=Path(__file__).parent
reports=[]
with sync_playwright() as p:
    browser=p.chromium.launch(executable_path='C:/Program Files/Google/Chrome/Application/chrome.exe',headless=True)
    for width in [1360,390]:
        ctx=browser.new_context(viewport={'width':width,'height':960 if width==1360 else 844},color_scheme='light')
        page=ctx.new_page();errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
        page.goto((R/'完整讲义/index.html').as_uri());page.wait_for_function('!restoring');page.evaluate('document.fonts.ready')
        assert page.locator('aside').is_visible()
        highlight=page.locator('#u02-understand').evaluate('(e)=>({border:getComputedStyle(e).borderLeftColor,background:getComputedStyle(e).backgroundImage})')
        assert highlight['border']=='rgb(29, 78, 216)',highlight
        assert '234, 243, 255' in highlight['background'],highlight
        assert page.locator('#u02-understand').evaluate('(e)=>Boolean(e.compareDocumentPosition(document.querySelector("#u02-quick"))&Node.DOCUMENT_POSITION_FOLLOWING)')
        page.locator('#u02-read-1').scroll_into_view_if_needed();page.evaluate('new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r)))')
        position=page.evaluate('getPosition()')
        b=page.locator('#sidebar-toggle').bounding_box();page.mouse.click(b['x']+b['width']/2,b['y']+b['height']/2);page.wait_for_function('!restoring')
        assert not page.locator('aside').is_visible();assert page.locator('#sidebar-toggle').inner_text()=='展开目录'
        assert page.evaluate('getPosition().id')==position['id']
        page.locator('#theme-toggle').click();assert page.locator('html').get_attribute('data-theme')=='dark'
        assert page.locator('#theme-toggle').inner_text()=='日间模式'
        page.reload();page.wait_for_function('!restoring');assert page.locator('html').get_attribute('data-theme')=='dark';assert not page.locator('aside').is_visible()
        page.locator('#language').click();page.wait_for_function('!restoring');assert page.locator('#sidebar-toggle').inner_text()=='Show contents';assert page.locator('#theme-toggle').inner_text()=='Light mode'
        page.locator('#language').click();page.wait_for_function('!restoring')
        # Diagram fills should change to the night palette without filtering the math renderer.
        night=page.locator('.course-figure svg').first.evaluate('(s)=>({fill:getComputedStyle(s.querySelector("#u01-patch_1 path")).fill,filtered:getComputedStyle(document.querySelector(".katex svg")||document.querySelector(".katex")).filter})')
        assert night['fill']=='rgb(25, 29, 34)',night;assert night['filtered']=='none'
        ratios=page.locator('details[id$="-original"]').evaluate_all('(els)=>els.map(e=>e.getBoundingClientRect().width/e.parentElement.getBoundingClientRect().width)')
        assert len(ratios)==47 and all(abs(r-.5)<.002 for r in ratios)
        assert page.locator('#u02-understand > h3').inner_text()=='了解'
        page.locator('#u01-understand').scroll_into_view_if_needed();page.screenshot(path=str(R/f'阅读界面_夜间_{width}.png'))
        page.evaluate("showTerm('norm')");assert page.locator('#term-dialog').is_visible();page.screenshot(path=str(R/f'术语窗_夜间_{width}.png'));page.locator('#term-close').click()
        page.locator('#theme-toggle').click();assert page.locator('html').get_attribute('data-theme')=='light'
        page.locator('#sidebar-toggle').click();page.wait_for_function('!restoring');assert page.locator('aside').is_visible()
        page.locator('#u02-original summary').click();assert page.locator('#u02-original').get_attribute('open') is not None
        page.locator('#u02-understand').scroll_into_view_if_needed();page.screenshot(path=str(R/f'阅读界面_日间_{width}.png'))
        assert not errors,errors;assert page.locator('.math-error').count()==0;assert page.evaluate('document.documentElement.scrollWidth<=innerWidth+1')
        reports.append({'width':width,'ics_current_layer_style':highlight,'sidebar_toggle_and_memory':True,'theme_toggle_and_memory':True,'language_labels':True,'half_width_boxes':47,'reading_position_preserved':True,'diagram_night_colors':night,'script_errors':errors})
        ctx.close()
    # A fresh browser respects the system color preference until the user chooses a theme.
    ctx=browser.new_context(viewport={'width':390,'height':844},color_scheme='dark');pg=ctx.new_page();pg.goto((R/'完整讲义/index.html').as_uri());pg.wait_for_function('!restoring');assert pg.locator('html').get_attribute('data-theme')=='dark';ctx.close()
    browser.close()
(R/'阅读界面验证.json').write_text(json.dumps(reports,ensure_ascii=False,indent=2),encoding='utf8')
print(json.dumps(reports,ensure_ascii=False))
