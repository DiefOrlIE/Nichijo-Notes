"""Exercise real key events, editing exclusions, contents controls and directory link."""
from pathlib import Path
import json
from playwright.sync_api import sync_playwright
R=Path(__file__).parent
reports=[]
with sync_playwright() as p:
    browser=p.chromium.launch(executable_path='C:/Program Files/Google/Chrome/Application/chrome.exe',headless=True)
    for width in [1360,390]:
        ctx=browser.new_context(viewport={'width':width,'height':900},reduced_motion='reduce')
        page=ctx.new_page();errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
        page.goto((R/'完整讲义/index.html').as_uri());page.wait_for_function('!restoring');page.evaluate('document.fonts.ready')
        page.locator('#sidebar-close').click();page.wait_for_function('!restoring')
        assert not page.locator('aside').is_visible()
        assert page.locator('#sidebar-toggle').get_attribute('aria-expanded')=='false'
        page.reload();page.wait_for_function('!restoring');assert not page.locator('aside').is_visible()
        page.locator('#sidebar-toggle').click();page.wait_for_function('!restoring');assert page.locator('aside').is_visible()
        page.locator('#u02-read-1').scroll_into_view_if_needed();page.evaluate('document.activeElement.blur()')
        page.wait_for_timeout(250)
        start=page.evaluate('scrollY');page.keyboard.press('s');page.wait_for_function('(n)=>scrollY>n+100',arg=start)
        down=page.evaluate('scrollY');page.keyboard.press('w');page.wait_for_function('(n)=>scrollY<n-100',arg=down)
        up=page.evaluate('scrollY');page.keyboard.press('s');page.wait_for_function('(n)=>scrollY>n+100',arg=up)
        page.keyboard.press('W');page.wait_for_timeout(100)
        before=page.evaluate('scrollY');page.keyboard.press('d');page.wait_for_timeout(100)
        assert abs(page.evaluate('scrollY')-before)<2,'D must not page down'
        pane=page.locator('#glossary-table').locator('..');pane.scroll_into_view_if_needed();pane.hover()
        horizontal=pane.evaluate('(e)=>e.scrollWidth>e.clientWidth+2')
        if horizontal:
            pane.evaluate('(e)=>e.scrollLeft=0');before=page.evaluate('scrollY')
            page.keyboard.press('d');page.wait_for_function('document.querySelector("#glossary-table").parentElement.scrollLeft>80')
            right=pane.evaluate('(e)=>e.scrollLeft');page.keyboard.press('a')
            page.wait_for_function('(n)=>document.querySelector("#glossary-table").parentElement.scrollLeft<n-80',arg=right)
            assert abs(page.evaluate('scrollY')-before)<2
        # Search input accepts navigation letters without moving the reading page.
        search=page.locator('#term-search');search.scroll_into_view_if_needed();search.click();page.wait_for_timeout(150)
        before=page.evaluate('scrollY');page.keyboard.type('wasd');assert search.input_value()=='wasd'
        assert abs(page.evaluate('scrollY')-before)<2
        search.fill('');search.blur()
        page.evaluate("showTerm('norm')");before=page.evaluate('scrollY');page.keyboard.press('d')
        assert abs(page.evaluate('scrollY')-before)<2
        centered=page.locator('#term-close').evaluate('e=>{const b=e.getBoundingClientRect(),s=e.querySelector("svg").getBoundingClientRect();return [Math.abs(b.x+b.width/2-s.x-s.width/2),Math.abs(b.y+b.height/2-s.y-s.height/2)]}')
        assert max(centered)<.6,centered
        page.screenshot(path=str(R/f'关闭按钮居中_{width}.png'))
        page.keyboard.press('Escape');assert not page.locator('#term-dialog').is_visible()
        page.locator('#sidebar-close').scroll_into_view_if_needed()
        centered_sidebar=page.locator('#sidebar-close').evaluate('e=>{const b=e.getBoundingClientRect(),s=e.querySelector("svg").getBoundingClientRect();return [Math.abs(b.x+b.width/2-s.x-s.width/2),Math.abs(b.y+b.height/2-s.y-s.height/2)]}')
        assert max(centered_sidebar)<.6,centered_sidebar
        # Native arrows remain available on diagram sliders.
        slider=page.locator('#angle');slider.scroll_into_view_if_needed();slider.focus();value=float(slider.input_value())
        page.keyboard.press('ArrowRight');assert float(slider.input_value())>value
        before=page.evaluate('scrollY');page.keyboard.press('d');assert abs(page.evaluate('scrollY')-before)<2
        back=page.locator('#parent-directory');assert back.get_attribute('href')=='../';assert back.is_visible()
        assert page.locator('a.home-back').count()==1
        assert back.inner_text()=='← 返回上级目录'
        page.locator('#language').click();page.wait_for_function('!restoring')
        assert back.inner_text()=='← Notes directory'
        page.locator('#language').click();page.wait_for_function('!restoring')
        page.locator('#u02').scroll_into_view_if_needed();page.wait_for_timeout(200)
        page.screenshot(path=str(R/f'键盘导航_{width}.png'))
        assert page.evaluate('document.documentElement.scrollWidth<=innerWidth+1')
        assert not errors,errors
        reports.append({'width':width,'W_up_S_down':True,'D_no_vertical_scroll':True,'A_D_horizontal_pane':horizontal,'close_icons_center_error_px':{'term':centered,'sidebar':centered_sidebar},'uppercase_supported':True,'search_typing_untouched':True,'dialog_does_not_scroll_background':True,'slider_native_arrows':True,'sidebar_close_reopen_memory':True,'parent_directory_link':'../','single_fixed_back_button':True,'script_errors':errors})
        ctx.close()
    ctx=browser.new_context(viewport={'width':1360,'height':900},reduced_motion='no-preference');pg=ctx.new_page()
    pg.goto((R/'完整讲义/index.html').as_uri());pg.wait_for_function('!restoring')
    theme=pg.locator('#theme-toggle');theme.hover();pg.wait_for_timeout(220)
    assert theme.evaluate('e=>getComputedStyle(e).transform')!='none'
    theme.click();assert theme.evaluate('e=>e.getAnimations().length')>0
    pg.wait_for_timeout(250);assert pg.locator('html').get_attribute('data-theme')=='dark'
    theme.hover();pg.screenshot(path=str(R/'工具栏动效_1360.png'));ctx.close()
    browser.close()
(R/'键盘导航验证.json').write_text(json.dumps(reports,ensure_ascii=False,indent=2),encoding='utf8')
print(json.dumps(reports,ensure_ascii=False))
