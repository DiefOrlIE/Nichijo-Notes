"""Acceptance of the assembled ordinary-text handbook and updated HW1 route."""
from pathlib import Path
import collections,json,hashlib
from bs4 import BeautifulSoup
from playwright.sync_api import sync_playwright
R=Path(__file__).parent;OUT=R/'完整讲义';old=BeautifulSoup((R/'结构重写前来源快照.html').read_text(encoding='utf8'),'html.parser')
report={'units':47,'terms':78,'source_pages':280,'pages':[],'limits':['Chrome at desktop and mobile viewport sizes; no real iOS Safari test.','Source page mapping and image files checked; not every original slide formula visually reread.','Third-party review and numerical checks do not establish student mastery.']}
mapping=json.loads((R/'内容地图.json').read_text(encoding='utf8'))
assert len(mapping['pages'])==280
for row in mapping['pages']:assert (OUT/f'pages/L{row["lecture"]}-{row["page"]:03}.webp').exists()
for name in ['index.html','hw1-route.html']:
    soup=BeautifulSoup((OUT/name).read_text(encoding='utf8'),'html.parser')
    assert len(soup.select('section[id^="u"]'))==47
    ids=collections.Counter(n['id'] for n in soup.select('[id]'));assert not [k for k,v in ids.items() if v>1],[(k,v) for k,v in ids.items() if v>1]
    assert not soup.select('[data-depth-button],[data-level],.layer,#mode')
    gates=soup.select('.exercise[data-gate]');assert len(gates)==5
    for gate in gates:
        assert len(gate.find_all('details',recursive=False))==3 and not gate.select('details[open]')
    idset=set(ids)
    for n in old.main.select('[id]'):assert n['id'] in idset,(name,n['id'])
    for a in soup.select('a[href^="#"]'):assert a['href'][1:] in idset,(name,a['href'])
    assert '照明设计的任务是' in soup.get_text()
    assert '凸松弛先把难处理' in soup.get_text()
    if name=='hw1-route.html':
        ids=[n['id'] for n in soup.main.find_all(id=True)]
        for ident in ['ex16','ex09','ex14','ex21','ex33','ex36','ex25','ex29']:
            assert ids.index(ident)<ids.index('hw1-ready'),ident
        assert ids.index('u10')<ids.index('u16')
        assert ids.index('u16')<ids.index('u14')
    unit_nodes={n['id']:n for n in soup.select('section[id^="u"]')}
    for lid,unitids in [(2,range(6,19)),(3,range(19,31)),(4,range(31,41)),(5,range(41,48))]:
        standalone=BeautifulSoup((OUT/f'chapter-{lid}.html').read_text(encoding='utf8'),'html.parser')
        stand_nodes={n['id']:n for n in standalone.select('section[id^="u"]')}
        for uid in unitids:
            assert unit_nodes[f'u{uid:02}'].get_text()==stand_nodes[f'u{uid:02}'].get_text(),(name,uid,'stale integrated prose')
with sync_playwright() as pw:
    browser=pw.chromium.launch(executable_path='C:/Program Files/Google/Chrome/Application/chrome.exe',headless=True)
    for name in ['index.html','hw1-route.html']:
        for width in [1360,390]:
            ctx=browser.new_context(viewport={'width':width,'height':940},reduced_motion='reduce');page=ctx.new_page();errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
            page.goto((OUT/name).as_uri());page.evaluate('document.fonts.ready');page.wait_for_function("document.querySelectorAll('.math .katex').length>100")
            for language in ['zh','en']:
                if page.locator('html').get_attribute('data-lang')!=language:page.locator('#language').click()
                assert page.locator('.math-error,.katex-error').count()==0
                assert page.evaluate('document.documentElement.scrollWidth<=innerWidth+2')
                assert not page.locator('[data-level],#mode').count()
            terms=page.evaluate('Object.keys(TERMS)');assert len(terms)==78
            for term in terms:
                page.evaluate('(k)=>showTerm(k)',term)
                assert page.locator('#term-definition').inner_text().strip()
                assert page.locator('#term-example').inner_text().strip()
                href=page.locator('#term-target').get_attribute('href');assert page.locator('[id="'+href[1:]+'"]').count()==1
                page.locator('#term-close').click()
            if page.locator('html').get_attribute('data-lang')!='zh':page.locator('#language').click()
            page.locator('#theme').click();theme=page.locator('html').get_attribute('data-theme');page.reload();page.evaluate('document.fonts.ready');assert page.locator('html').get_attribute('data-theme')==theme
            page.locator('#u07').evaluate('n=>n.scrollIntoView()');page.screenshot(path=str(R/f'连续全篇_{name.replace(".html","")}_{width}.png'))
            page.locator('#u44').evaluate('n=>n.scrollIntoView()');page.screenshot(path=str(R/f'连续全篇_拟凸_{name.replace(".html","")}_{width}.png'))
            page.locator('#u14').evaluate('n=>n.scrollIntoView()');page.screenshot(path=str(R/f'连续全篇_Hessian_{name.replace(".html","")}_{width}.png'))
            assert not errors,errors
            report['pages'].append({'page':name,'html_sha256':hashlib.sha256((OUT/name).read_bytes()).hexdigest(),'width':width,'languages':['zh','en'],'math_errors':0,'overflow':False,'term_cards':78,'theme_memory':True,'js_errors':errors})
            ctx.close()
    browser.close()
(OUT/'continuous-verification.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
print('Assembled handbook verified: 47 units, 78 terms, 280 source files, both routes in both viewport sizes.')
