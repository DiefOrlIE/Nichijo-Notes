(()=>{
 const uiRoot=document.documentElement, uiKey='convex-reading-ui-v1';
 const contentsButton=document.getElementById('sidebar-toggle'),themeButton=document.getElementById('theme-toggle');
 const aside=document.getElementById('course-contents');
 const closeContents=document.getElementById('sidebar-close'),backLink=document.getElementById('parent-directory');
 let preferences={};try{preferences=JSON.parse(localStorage.getItem(uiKey)||'{}')}catch(e){}
 let hidden=preferences.sidebarHidden===true;
 let theme=preferences.theme==='dark'||preferences.theme==='light'?preferences.theme:matchMedia('(prefers-color-scheme: dark)').matches?'dark':'light';
 function save(){try{localStorage.setItem(uiKey,JSON.stringify({theme,sidebarHidden:hidden}))}catch(e){}}
 function labels(){
  const en=uiRoot.dataset.lang==='en';
  contentsButton.textContent=en?(hidden?'Show contents':'Hide contents'):(hidden?'展开目录':'收起目录');
  contentsButton.setAttribute('aria-expanded',String(!hidden));contentsButton.setAttribute('aria-controls','course-contents');
  themeButton.textContent=en?(theme==='dark'?'Light mode':'Dark mode'):(theme==='dark'?'日间模式':'夜间模式');
  themeButton.setAttribute('aria-pressed',String(theme==='dark'));
  closeContents.setAttribute('aria-label',en?'Hide contents':'收起目录');closeContents.title=en?'Hide contents':'收起目录';
  backLink.setAttribute('aria-label',en?'Return to the notes directory':'返回上级目录');backLink.title=en?'Nichijo Notes directory':'返回 Nichijo Notes 笔记目录';
  const hint=document.getElementById('keyboard-hint');
  hint.textContent=en?'Keyboard: W ↑ · S ↓ · A ← · D →':'键盘：W ↑ · S ↓ · A ← · D →';
  hint.title=en?'W: up. S: down. A: left. D: right. Hover a wide formula or table to scroll it horizontally. Disabled while editing or a dialog is open.':'W 上、S 下、A 左、D 右。鼠标放在宽公式或表格上时，A/D 横向滚动该区域；输入或打开弹窗时暂停。';
  contentsButton.title=en?'Show or hide the contents; your preference is saved':'展开或收起目录，自动记住选择';
 }
 function apply(){uiRoot.dataset.sidebar=hidden?'hidden':'shown';uiRoot.dataset.theme=theme;aside.hidden=hidden;labels();save();}
 contentsButton.addEventListener('click',()=>changeReading(()=>{hidden=!hidden;apply();}));
 closeContents.addEventListener('click',()=>{contentsButton.focus({preventScroll:true});contentsButton.click();});
 themeButton.addEventListener('click',()=>{theme=theme==='dark'?'light':'dark';apply();});
 new MutationObserver(labels).observe(uiRoot,{attributes:true,attributeFilter:['data-lang']});
 // Standard WASD directions. Horizontal keys use the focused or hovered overflow pane.
 // Leave native arrows and all editing controls to the browser.
 document.addEventListener('keydown',event=>{
  if(event.defaultPrevented||event.ctrlKey||event.metaKey||event.altKey||event.isComposing)return;
  const target=event.target;
  if(target instanceof Element&&target.closest('input,textarea,select,[contenteditable]:not([contenteditable="false"]),[role="textbox"],[role="searchbox"],[role="combobox"],[role="slider"]'))return;
  if(document.querySelector('dialog[open]'))return;
  const key=event.key.toLowerCase();
  if(!['w','a','s','d'].includes(key))return;
  const behavior=event.repeat||matchMedia('(prefers-reduced-motion: reduce)').matches?'instant':'smooth';
  if(key==='a'||key==='d'){
   const left=key==='a'?-120:120;
   let box=target instanceof Element?target:null;
   while(box&&box!==document.body){
    const style=getComputedStyle(box);
    if(box.scrollWidth>box.clientWidth+1&&/auto|scroll/.test(style.overflowX)){event.preventDefault();box.scrollBy({left,behavior});return;}
    box=box.parentElement;
   }
   const hovered=[...document.querySelectorAll('.display:hover,.table-wrap:hover,pre:hover')].reverse().find(el=>el.scrollWidth>el.clientWidth+1&&/auto|scroll/.test(getComputedStyle(el).overflowX));
   event.preventDefault();(hovered||window).scrollBy({left,behavior});return;
  }
  const headerHeight=document.querySelector('header')?.getBoundingClientRect().height||0;
  const step=Math.max(120,Math.round((innerHeight-headerHeight)*.78));
  event.preventDefault();window.scrollBy({top:key==='w'?-step:step,behavior});
 });
 // Keep feedback local to toolbar buttons so the reading position does not move.
 document.querySelectorAll('header .tools button').forEach(button=>button.addEventListener('click',()=>{
  if(matchMedia('(prefers-reduced-motion: reduce)').matches)return;
  if(button._readingFeedback)button._readingFeedback.cancel();
  button._readingFeedback=button.animate([{transform:'scale(.96)',opacity:.82},{transform:'scale(1)',opacity:1}],{duration:180,easing:'cubic-bezier(.2,.8,.2,1)'});
 }));
 // Recolor diagram colors directly, preserving geometry, mathematical SVGs and source slides.
 const palette={'#faf6ee':'#191d22','#ffffff':'#191d22','#315b78':'#92bfdc','#a54b3d':'#e7a18e','#687f69':'#a6c9ad','#766e61':'#a9b1bc','#b6ae9e':'#6d7c8e','#2a2620':'#e1e3e6','#000000':'#e1e3e6','#dce5e7':'#32495a','#dde6e7':'#32495a','#e0d9cc':'#3e4c5b','#c6beae':'#627284'};
 let colorRules='';
 for(const [light,dark] of Object.entries(palette)){
  for(const group of ['.course-figure svg','.experiment svg','.mini-balls svg']){
   for(const property of ['fill','stroke']){
    colorRules+=`html[data-theme=dark] ${group} [${property}="${light}"],html[data-theme=dark] ${group} [style*="${property}: ${light}"]{${property}:${dark}!important}`;
   }
  }
 }
 const style=document.createElement('style');style.id='diagram-night-colors';style.textContent=colorRules;document.head.append(style);
 apply();
})();
