"""Package the completed authored revision and its actual acceptance evidence."""
from pathlib import Path
import json,zipfile,shutil,re
R=Path(__file__).parent;OUT=R/'完整讲义'
v=json.loads((OUT/'task-verification.json').read_text(encoding='utf8'))
assert len(v['coverage'])==17 and len(v['browser'])==4
report='''# 2026-10-16 修改与验收记录

本轮依据《凸优化讲义修改任务书（Homework 1 对照更新版）》执行，正文由助手撰写，未使用 humanizer。此次没有调用 DeepSeek；第三方意见不能替代数学核算。

## 内容与结构

- 保留前五讲47个来源单元及280页课件图片、旧单元与段落锚点。新增[六阶段连续路线](hw1-route.html#guide)，按证明基础、矩阵与范数、导数、凸集、凸函数、锥的依赖排序。原课件顺序入口仍为[index.html](index.html)。
- 修正δC、hC的一次共轭与双共轭；区别极小、弱极小及严格锥序；补严格凸定义、凸可行集前提及两个反例。
- 将对偶滑块标为r=c/‖z‖*，同时显示r、真实c和直线方程。说明负位置、轴方向、并列取等、z=0以及交互归一化与手算的差别。
- 重画线性像/二次型预算椭球、概率单纯形参数图、指数共轭边界图，避免不同对象共用旧图造成误读。
- 展开诱导范数、二次范数对偶、LSE梯度与Hessian、全部零方向、集合定义证明、最小二乘Hessian、Jensen完整归纳、二阶锥四性质、自对偶与直接传递性。
- 共轭按二次函数、指数、负对数、支撑函数分段教学；补域、无界、端点与取得性。完善复合、部分最小化的ε证明、透视、拟凸二分和矩阵值凸性。
- 其他单元保留已有可读例子，逐节补维数、方法与条件。高级SVD、奇异Schur补、矩阵幂、特殊函数保留，但从作业基础主线分开。
- 五个关卡均有默认折叠的“思路提示—关键步骤—完整核对”，另补标量求导、共轭和二分变式。原单元练习也补分级帮助。每讲末加入方法与易错条件自检。
- [17项证据表](hw1-coverage.md)提供每项的实际正文、完整示范与独立训练链接。原题4(a)合计9分，未将教学均分冒充教师评分。

## 实际完成的检查

- 读取hw1.pdf两页全部题目，对照17项实际方法要求。内部以讲义工具重写核算17项，检查记录保存在源文件包中。
- 读取五份课件全部280页文本，逐页核对页码范围、原页标题、单一归属与图片文件。未映射的封面、提纲、总结保留来源记录。
- 对照本地Boyd–Vandenberghe教材第2、3章和附录，重点复核共轭有效域、拟凸导数条件、矩阵幂范围及Schur补前提。引用优先使用章节号。
- 符号计算核对三种标量二阶导、负对数候选值、二次共轭系数及迁移题Hessian；数值核对二次范数取等、矩形行和输入、距离半空间、Jensen和二阶锥负内积。LSE在原点及10个固定随机点以有限差分复核梯度/Hessian，不能将数值样本当作一般证明。
- 两份页面在1360px与390px Chrome下，逐个检查中英两语、四档深度；公式渲染错误0、脚本错误0、页面横向溢出0。长公式与表格在各自区域横向滚动。
- 全部78个术语卡定义、例子及正文目标有效；17项链接、五个关卡、旧讲次链接、作业结束标记位置通过检查。作业结束标记位于Jensen及二阶锥相关训练之后。
- 支撑交互45°下三种原范数的对偶值为0.7071、1.0000、1.4142；r=1、r=1/2及轴方向检查通过。
- WASD、输入排除、原生方向键、弹窗、关闭图标居中、目录收起与恢复、顶部按钮动效均通过回归检查。阅读模式与原课件半宽框检查见随附记录。
- 已查看桌面与手机的实际截图，核对新增证明和共轭页面的排版。

## 检查边界

- 280页课件的文本与归属已逐页核对；未对全部原课件公式重新逐页作视觉审读，部分PDF公式提取存在乱码。新写的关键公式以教材、独立推导与数值检查为依据。不能将元数据核对描述成全部原页公式已视觉校验。
- 已测试Chrome桌面与手机视口，未做iOS Safari真机测试。字体保留内嵌WOFF2及Songti SC等回退，真机表现仍待实测。
- 没有真实学生试读实验；覆盖表表明教学证据已提供，无法保证每位读者会独立完成或获得特定分数。页面阅读进度不用于替代能力判断。

机器可复查记录：[task-verification.json](task-verification.json)、[reader-verification.json](reader-verification.json)、[keyboard-verification.json](keyboard-verification.json)。

## 维护与取舍

这轮按方法难度展开，不再对每个单元机械维持上一版一半篇幅；通过层级和连续路线限制首次阅读负担。主页面与作业路线由同一源稿生成，避免分别维护两套讲解。下载[源文件包](lecture-source.zip)继续修改。包内含构建说明、生成模块、双语内容、交互、来源映射与本轮验证脚本；教材和原始课件PDF留在用户本地，不上传。
'''
(OUT/'revision-report.md').write_text(report,encoding='utf8')
readme='''# 凸优化 · 前五讲双语自学讲义

2026-10-16 按修改任务书核验与重构。保留47单元、280页原课件、78个术语及双语四档阅读。补齐关键推导与五个变式关卡，纠正共轭、Pareto、严格凸与图文问题。

- [完整讲义](index.html)：课件顺序；[首次自学与HW1连续路线](hw1-route.html#guide)：按六阶段依赖排序，同一内容源。
- [17项作业证据](hw1-coverage.md)：正文、完整示范与独立训练。
- [修改与验收](revision-report.md)：实际检查及待核验范围。
- [源文件](lecture-source.zip)：可维护生成源，构建说明在包内。

四档累积显示：了解含基础定义与完整算例，掌握含一般证明、关键推导和隐藏答案练习，深入含边界与高级拓展，速通用于复习。切换语言与深度保留当前位置。两个阅读入口各自保存阅读进度；目录和夜间偏好共用。

W上S下A左D右；宽公式和表格可悬停后用A/D滚动。输入、滑块和术语弹窗中暂停字母快捷键。目录可隐藏并由顶部按钮恢复。关闭图标居中，工具按钮带动效并尊重减少动画偏好。左下角可返回笔记入口。课件核对框为正文半宽，原页默认折叠。

此前2026-10-15的压缩比例仅描述历史版本。本次以数学正确与可独立学习为准，不宣称新正文仍为该比例。未使用humanizer，本轮未调用第三方写作模型。

Chrome桌面和390px手机视口、中英四档、公式、术语、锚点、图形数值、WASD、目录及暗色已检查。未做iOS Safari真机测试；未逐页视觉重审全部原课件公式，详见验收记录。

字体：Noto Serif SC，SIL Open Font License 1.1；数学排版：KaTeX，MIT License。
'''
(OUT/'README.md').write_text(readme,encoding='utf8')
for source,dest in [('阅读界面验证.json','reader-verification.json'),('键盘导航验证.json','keyboard-verification.json'),('自学讲义语言标准.md','writing-standard.md')]:shutil.copy2(R/source,OUT/dest)
(OUT/'review-notes.md').write_text(report,encoding='utf8')
sources=['build_course.py','course_content.py','course_background.py','course_sets.py','course_functions.py','course_extensions.py','course_supplements.py','least_squares_rewrite.py','concise_revision.py','author_concise_dual.py','concise_captions.py','course_figures.py','course_ui.py','reader_controls.css','reader_controls.js','sample.css','sample.js','task_revision.py','refinement_content.py','refinement_figures.py','verify_task_revision.py','verify_reader_controls.py','verify_keyboard_navigation.py','write_revision_delivery.py','内容地图.json','逐页对应表.md','自学讲义语言标准.md','精简重写/content.json','对偶范数_双语样章.html','任务书执行计划_2026-10-16.md','HW1编辑复核_2026-10-16.md']
buildnotes='''# 构建与维护

双语新增正文在 refinement_content.py，组装和路线在 task_revision.py，原有精简稿在精简重写/content.json。修改生成源后运行 build_course.py，勿只修改生成HTML。

Python依赖：beautifulsoup4、fonttools[woff]、brotli、PyMuPDF、numpy、matplotlib；验证另需sympy与playwright（Chrome）。KaTeX运行资源已随包提供vendor/katex。中文字体默认使用Windows的NotoSerifSC-VF.ttf，可通过CONVEX_CJK_FONT指定同款变量字体路径。

将CONVEX_MATERIALS设为Lecture_1.pdf至Lecture_5.pdf所在目录，运行python build_course.py。输出完整讲义/index.html和hw1-route.html；来源图片首次从课件渲染。如果完整讲义/pages已有完整280张图片，可以不提供原PDF。教材和HW1仅用于编辑核对，验证脚本默认在源目录上两层寻找材料，可按实际位置调整WORK。

python verify_task_revision.py验证数学例子、来源和两个页面；原界面/键盘验证分别见相应脚本。验收记录写入输出目录。write_revision_delivery.py整理交付文档及本源包，需保留本轮原始材料、验证JSON和字体/KaTeX输入。

本包不含教材和原课件PDF，也不含GitHub凭据或上传脚本。仅修改文字可在原工作区重建，或配置上述材料目录后重建。
'''
katex=R/'vendor/katex' if (R/'vendor/katex').exists() else Path('E:/CC_Nichijo/notes/llm-principles/src/node_modules/katex/dist')
with zipfile.ZipFile(OUT/'lecture-source.zip','w',zipfile.ZIP_DEFLATED) as archive:
    for name in sources:archive.write(R/name,name)
    archive.writestr('README_BUILD.md',buildnotes)
    archive.write(katex/'katex.min.js','vendor/katex/katex.min.js');archive.write(katex/'katex.min.css','vendor/katex/katex.min.css')
    for f in (katex/'fonts').iterdir():archive.write(f,'vendor/katex/fonts/'+f.name)
    if (katex/'../LICENSE').resolve().exists():archive.write((katex/'../LICENSE').resolve(),'vendor/katex/LICENSE')
print('Packaged',len(sources),'source files and KaTeX assets; 17-item report and acceptance records ready.')
