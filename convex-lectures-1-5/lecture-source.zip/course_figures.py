"""Exact mathematical diagrams, not decorative or AI-generated drawings."""
import numpy as np, io, re
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Polygon, Circle, Ellipse
from pathlib import Path
R=Path(__file__).parent
BLUE='#315b78';RED='#a54b3d';PAPER='#faf6ee';GREEN='#687f69'
CAPTIONS={
'least-squares':('左图的横轴 i 是观测编号，蓝点为 1、2、6，红线是统一预测 3，竖线长度表示仍然存在的偏差。右图横轴 x 是可选的预测值，蓝线给出平方总分 F(x)，红点 (3,14) 标出最低分。两图使用同一组数据，回答“偏差在哪里”和“选哪个 x”。','Left: horizontal i indexes observations; blue points are 1,2,6 and red line is prediction three. Vertical segments show discrepancies. Right: candidate prediction x is horizontal, blue F(x) gives the squared-error score, and red (3,14) marks its minimum. Both panels use the same data, showing remaining errors and which x to choose.'),
'model':('先找横轴 x₁、纵轴 x₂。蓝线是 2x₁+x₂=4，浅色区域在其上方且位于非负象限；红点 (2,0) 取到最低费用 6。虚线是费用等值线。沿费用降低方向移动虚线，最后仍可接触的点为红点。','The axes show x₁ and x₂. The blue line is 2x₁+x₂=4; the shaded feasible region is above it in the nonnegative orthant. Red point (2,0) attains cost six. Dashed lines are cost levels; move them toward lower cost until the last feasible contact.'),
'projection':('蓝线是一个一维列空间，黑点 b=(1,2) 是观测，红点 p=(1,0) 是最近预测。红色竖线为残差方向，和蓝线垂直。此图采用二维数据作几何演示，正文的三观测例子采用另一组数据。','The blue line is a one-dimensional column space, black point b=(1,2) is the observation, and red point p=(1,0) is its nearest prediction. The red residual segment is perpendicular to the line. This two-dimensional illustration uses different data from the three-observation example in the text.'),
'lp':('两条蓝/绿色直线分别是 2x+1 与 −x+4，红色上包络是它们的最大值。红点 (1,3) 是包络最低点；往左右移动都会由其中一项把费用抬高。','The blue and green lines are 2x+1 and −x+4; their red upper envelope is the maximum. Its lowest point is (1,3); moving either way raises one active term.'),
'convex':('蓝色曲线 x² 的红色弦连接 x=−1、3。中点 1 处，曲线值为 1，弦高为 5。竖直间隙说明凸函数在弦下方，和最小值是否存在是两个不同的问题。','The red chord joins −1 and 3 on the blue curve x². At midpoint one, the curve is one and the chord is five. The vertical gap shows convexity; it does not itself establish attainment of an optimum.'),
'nonconvex':('蓝线为 (x²−1)²，红点 ±1 是两个全局极小点，灰点 0 是导数为零的局部极大点。三个点的坡度均为零，因此只看驻点不能识别最优。','The blue curve is (x²−1)². Red points ±1 are global minima; gray point zero is a stationary local maximum. All three have zero slope, so stationarity alone cannot identify optimality.'),
'inner':('蓝箭头 x=(3,4)，绿色箭头为单位方向 y=(1,0)，红线标出沿 y 的投影 3。箭头垂直方向的分量不参与这个内积。','The blue vector is x=(3,4), green is unit direction y=(1,0), and the red segment shows projection three along y. The perpendicular component does not contribute to this inner product.'),
'balls':('三个面板分别为 ℓ₁、ℓ₂、ℓ∞ 闭单位球，轴比例相同。看方向 (1,1)：边界分别在 (1/2,1/2)、(1/√2,1/√2)、(1,1)，直观比较同一方向的预算。','The panels show closed ℓ₁, ℓ₂ and ℓ∞ unit balls with identical axis scales. Along (1,1), their boundaries are (1/2,1/2), (1/√2,1/√2), and (1,1), comparing budgets in one direction.'),
'ellipse':('此图专门画变换 diag(3,2)：蓝圆为输入单位球，红椭圆为输出。最右侧从 1 变到 3，竖直方向从 1 变到 2。它演示方向缩放；正文其他矩阵的特征方向与半径需按各自数据重算。','This diagram specifically uses diag(3,2): blue is the input unit circle and red the output ellipse. Horizontal radius changes from one to three, vertical from one to two. It illustrates directional scaling; other matrices in the text require their own eigenvectors and radii.'),
'topology':('黑线表示 (0,1]。左端空心点 0 被排除，右端实心点 1 被包含。绿色邻域围绕 1/2 并完全位于集合中；围绕 1 的红色邻域会伸出集合。边界是否属于集合与是否为内点要分别判断。','The black interval is (0,1], excluding open-circle zero and including filled one. A green neighborhood around one half stays inside; a red neighborhood around one extends outside. Boundary membership and interior status are separate judgments.'),
'tangent':('蓝线为 x²，红线为切点 a=1 的切线 2x−1。两线间差为 (x−1)²，除接触点外为正。沿曲线观察切线始终在下方。正文多变量梯度使用同一局部近似思想。','The blue curve is x²; the red tangent at a=1 is 2x−1. Their gap is (x−1)², positive except at contact. Follow the curve to see the global lower bound. Multivariate gradients use the same local-approximation idea.'),
'affine':('黑线为 x₁+x₂=1，蓝点是 (1,0)、(0,1)，红色线段连接两点。仿射包含整条黑线，凸包只含红色线段。原点不在黑线上。','The black line is x₁+x₂=1, joining blue points (1,0) and (0,1). The affine hull is the entire black line; the convex hull is only the red segment. Zero is not on the line.'),
'hull':('三点为 (0,0)、(2,0)、(0,2)，浅蓝填充是其凸包。红点 (1/2,1/2) 对应权重 (1/2,1/4,1/4)。边界和内部都由凸组合构成。','The points are (0,0), (2,0), (0,2), and the shaded triangle is their convex hull. Red point (1/2,1/2) uses weights (1/2,1/4,1/4). Both boundary and interior consist of convex combinations.'),
'halfspace':('蓝线 x₁=1 是 a=(0,0)、b=(2,0) 的垂直平分线，左侧阴影为距 a 不比距 b 远的点。挑阴影中的点 (0,1)，两距离分别为 1 与 √5，核对不等式方向。','Blue x₁=1 bisects a=(0,0) and b=(2,0). Left shading marks points no farther from a. Test (0,1): distances are one and √5, confirming the direction.'),
'intersection':('浅蓝圆盘与绿色半空间 x₁≤1/2 相交，较深区域为同时满足两条件的点。红色线段的两个端点都在交集中，整条线段也留在其中。','The light-blue disk intersects green halfspace x₁≤1/2; darker overlap satisfies both. The red segment joins two points in the intersection and remains inside.'),
'perspective':('竖轴是高度 t，横轴是 z。黑点 (0,1)、(2,2) 的连线为输入线段，射线投向 t=1 的截面，输出坐标为 0、1。红色输入中点 (1,1.5) 投影到 2/3，显示权重会改变。','Vertical t is height and horizontal z position. Black points (0,1),(2,2) form an input segment; rays meet t=1 at output coordinates zero and one. Red midpoint (1,1.5) projects to 2/3, showing changed weights.'),
'soc':('横轴是标量 x，纵轴是预算 t，阴影满足 |x|≤t。绿色点 (0,1) 在内部；蓝色边界是 t=|x|；原点是锥顶。对高维 x，这只是二阶锥的一个二维截面。','The horizontal axis is scalar x and vertical is budget t; shading satisfies |x|≤t. Green (0,1) is interior, blue t=|x| is the boundary, and zero is the vertex. For higher-dimensional x this is only a two-dimensional SOC section.'),
'pareto':('横轴为费用，纵轴为误差，两者都希望越小越好。蓝点 (1,4)、(2,2)、(4,1) 互不支配；红点 (3,3) 被 (2,2) 支配。连线只用于读出趋势，没有假设线段内的方案也可达到。','Cost and error both prefer smaller values. Blue (1,4),(2,2),(4,1) are incomparable; red (3,3) is dominated by (2,2). Connecting lines show the trend only and do not assert feasibility of intermediate plans.'),
'separation':('两个蓝圆盘半径 1、中心 (−2,0) 与 (2,0)，红色直线 x₁=0 严格分离它们。两边各有宽度 1 的空隙，说明这个例子比一般弱分离结论更强。','Blue radius-one disks centered at (−2,0) and (2,0) are strictly separated by red x₁=0. A unit gap on each side makes this example stronger than general weak separation.'),
'support':('蓝色单位圆盘在红点 (1,0) 处由 x₁=1 支撑。绿色箭头为法向 (1,0)。圆盘整体在支撑线左侧，线只在边界接触，不穿过内部。','The blue unit disk is supported by x₁=1 at red point (1,0). Green arrow (1,0) is the normal. The disk stays to the left; the line touches its boundary without crossing the interior.'),
'dualcone':('蓝色 V 形锥满足 |x|≤t。红点 (y,s)=(2,1) 在锥外，绿色点 (−1,1) 在锥内，二者内积为 −1。绿色点提供一张证书，说明红点不属于对偶锥。','The blue cone satisfies |x|≤t. Red (y,s)=(2,1) is outside; green (−1,1) is inside and pairs with it to give −1. The green point certifies that the red point is outside the dual cone.'),
'chord':('蓝线 x² 的红弦连接 x=−1、3；混合输入 1 的函数值为 1，函数值平均为 5。沿线段选其他比例，仍可观察图像不超过弦。','The red chord joins −1 and 3 on blue x². The mixed input one has value one, below the averaged value five. Other mixture proportions also keep the graph below the chord.'),
'epigraph':('蓝色边界是 t=x²，浅色区域为上图集 t≥x²。红线段连接两个图像点，除端点外都在函数上方，因此仍在上图集中。','The blue boundary is t=x² and shading is its epigraph t≥x². The red chord joins graph points and lies above the function between them, hence remains in the epigraph.'),
'jensen':('蓝线为平方函数。两点 1、3 的等权平均输入为 2，曲线值 4；红线上的平均输出为 5。绿色竖线标出的差为 1，即这组数据的方差。','The blue square function has endpoint inputs one and three. Their mean two gives value four, while the red averaged output is five. The green gap of one is the variance of these data.'),
'max':('蓝线 x²、绿线 (x−2)² 的红色上包络为逐点最大值。切换发生在 x=1，左右斜率不同，产生尖角，但上包络仍凸。','Blue x² and green (x−2)² have the red pointwise upper envelope. Switching at x=1 creates unequal one-sided slopes, yet the envelope remains convex.'),
'perspective-function':('蓝线为 t=1 时的 x²/t，红线为 t=2 时的 x²/t。增加正预算 t 可降低固定 x 的费用，但这两条截面曲线只演示效果；联合凸性要同时混合 x、t，由正文证明。','Blue and red curves show x²/t at t=1 and t=2. Increasing positive budget lowers cost for fixed x. These sections illustrate the effect; joint convexity mixes x and t and is proved in the text.'),
'conjugate':('蓝线为 x²/2，红线为斜率 2 的支撑线 2x−2，接触点为 (2,2)。截距 −2 对应共轭值 2。任意平行线上移都会超过曲线，所以该线是这一斜率下最高的仿射下界。','Blue is x²/2; red is the slope-two support 2x−2 touching at (2,2). Intercept −2 corresponds to conjugate value two. Any upward parallel shift crosses the curve, so this is the highest affine lower bound with this slope.'),
'logconcave':('蓝线 exp(−x²/2) 在左图呈钟形，右图的对数 −x²/2 为向下抛物线。左图尾部并非凹，右图却处处凹，因此对数凹与函数本身凹不能混用。','The left blue curve exp(−x²/2) is bell-shaped; its logarithm on the right is the concave parabola −x²/2. The original tails are not concave, distinguishing log-concavity from ordinary concavity.')}

def figure(kind):
    if kind in ['geometry-pair','simplex','exp-conjugate']:
        from refinement_figures import figure as revised_figure
        return revised_figure(kind)
    fig,axes=plt.subplots(1,3 if kind=='balls' else 2 if kind in ['logconcave','least-squares'] else 1,figsize=(8.2,3.9),facecolor=PAPER)
    axs=np.atleast_1d(axes);ax=axs[0]
    for a in axs:
        a.set_facecolor(PAPER);a.spines[['top','right']].set_visible(False);a.spines[['bottom','left']].set_color('#b6ae9e');a.tick_params(colors='#766e61',labelsize=10);a.grid(alpha=.13);a.set_xlabel('x');a.set_ylabel('value')
    x=np.linspace(-2.5,3.5,400)
    if kind=='least-squares':
        ax.scatter([1,2,3],[1,2,6],color=BLUE,zorder=4);ax.axhline(3,color=RED,label='prediction = 3')
        for i,y in enumerate([1,2,6],1):ax.plot([i,i],[y,3],color=GREEN,lw=2)
        ax.set_xlabel('Observation i');ax.set_ylabel('Reading / prediction');ax.set_xticks([1,2,3]);ax.set_ylim(0,7);ax.legend(frameon=False,fontsize=9)
        xx=np.linspace(0,6,300);axs[1].plot(xx,3*(xx-3)**2+14,color=BLUE);axs[1].scatter([3],[14],color=RED,zorder=4);axs[1].annotate('(3, 14)',(3,14),xytext=(3.3,18));axs[1].set_xlabel('Candidate x');axs[1].set_ylabel('Score F(x)');axs[1].set_ylim(0,45)
    elif kind in ['convex','chord','epigraph','jensen','tangent','conjugate']:
        x=np.linspace(-1.7,3.5,300);f=x*x/(2 if kind=='conjugate' else 1);ax.plot(x,f,color=BLUE,lw=2)
        if kind in ['tangent','conjugate']:
            a=2 if kind=='conjugate' else 1;scale=2 if kind=='conjugate' else 1;ax.plot(x,2*a*x/scale-a*a/scale,color=RED);ax.scatter([a],[a*a/scale],color=RED);ax.set_ylim(-3,10)
        else:
            ends=[1,3] if kind=='jensen' else [-1,3];ax.plot(ends,np.square(ends),color=RED);ax.scatter(ends,np.square(ends),color=RED);mid=np.mean(ends);ax.plot([mid,mid],[mid*mid,np.mean(np.square(ends))],color=GREEN,lw=3);ax.scatter([mid],[mid*mid],color=BLUE)
            if kind=='epigraph':ax.fill_between(x,x*x,13,color=BLUE,alpha=.1);ax.set_ylabel('t')
    elif kind=='lp':
        x=np.linspace(-1,3,300);a=2*x+1;b=-x+4;ax.plot(x,a,color=BLUE);ax.plot(x,b,color=GREEN);ax.plot(x,np.maximum(a,b),color=RED,lw=3);ax.scatter([1],[3],color=RED);ax.set_ylim(0,8)
    elif kind=='max':
        x=np.linspace(-1,3,300);a=x*x;b=(x-2)**2;ax.plot(x,a,color=BLUE);ax.plot(x,b,color=GREEN);ax.plot(x,np.maximum(a,b),color=RED,lw=3)
    elif kind=='nonconvex':
        x=np.linspace(-1.6,1.6,400);ax.plot(x,(x*x-1)**2,color=BLUE);ax.scatter([-1,1],[0,0],color=RED);ax.scatter([0],[1],color='#766e61')
    elif kind=='perspective-function':
        x=np.linspace(-2,2,300);ax.plot(x,x*x,color=BLUE,label='t=1');ax.plot(x,x*x/2,color=RED,label='t=2');ax.legend(frameon=False)
    elif kind=='logconcave':
        x=np.linspace(-3,3,400);axs[0].plot(x,np.exp(-x*x/2),color=BLUE);axs[0].set_title('f(x)',fontsize=12);axs[1].plot(x,-x*x/2,color=BLUE);axs[1].set_title('log f(x)',fontsize=12)
    elif kind=='topology':
        ax.set_ylim(-.6,.6);ax.plot([0,1],[0,0],color='#2a2620',lw=3);ax.scatter([0],[0],facecolor=PAPER,edgecolor='#2a2620',s=90,zorder=5);ax.scatter([1],[0],color='#2a2620',s=60,zorder=5);ax.plot([.25,.75],[.2,.2],color=GREEN,lw=4);ax.plot([.8,1.2],[-.2,-.2],color=RED,lw=4);ax.set_yticks([])
    else:
        ax.set_xlabel('x₁' if kind not in ['soc','dualcone','perspective'] else 'x' if kind!='perspective' else 'z');ax.set_ylabel('x₂' if kind not in ['soc','dualcone','perspective'] else 't');ax.set_aspect('equal',adjustable='box');ax.set_xlim(-3.5,3.5);ax.set_ylim(-2,4.5)
        if kind=='model':
            xx=np.linspace(0,3,100);ax.fill_between(xx,np.maximum(4-2*xx,0),5,color=BLUE,alpha=.12);ax.plot(xx,4-2*xx,color=BLUE);ax.set_xlim(-.3,3);ax.set_ylim(-.3,5)
            for c in [6,8]:ax.plot(xx,(c-3*xx)/2,color=RED,ls='--',alpha=.6)
            ax.scatter([2],[0],color=RED)
        elif kind=='projection':
            ax.axhline(0,color=BLUE,lw=2);ax.scatter([1,1],[2,0],color=['#2a2620',RED]);ax.plot([1,1],[0,2],color=RED);ax.text(1.1,2,'b');ax.text(1.1,.1,'p');ax.plot([1,1.18,1.18],[.18,.18,0],color=RED)
        elif kind=='inner':
            ax.arrow(0,0,3,4,width=.025,color=BLUE,length_includes_head=True);ax.arrow(0,0,1,0,width=.04,color=GREEN,length_includes_head=True);ax.plot([3,3],[0,4],color='#b6ae9e',ls='--');ax.plot([0,3],[0,0],color=RED,lw=3);ax.set_xlim(-.5,4)
        elif kind=='balls':
            for a,n in zip(axs,['1','2','∞']):
                a.set_aspect('equal');a.set_xlim(-1.3,1.3);a.set_ylim(-1.3,1.3);a.set_xlabel('x₁');a.set_ylabel('x₂');a.set_title('ℓ'+n,fontsize=13)
                patch=Polygon([[1,0],[0,1],[-1,0],[0,-1]],closed=True) if n=='1' else Circle((0,0),1) if n=='2' else Polygon([[-1,-1],[1,-1],[1,1],[-1,1]],closed=True)
                patch.set_facecolor('#dce5e7');patch.set_edgecolor(BLUE);a.add_patch(patch);a.plot([0,1.2],[0,1.2],color=RED,ls='--')
        elif kind=='ellipse':
            for patch,color in [(Circle((0,0),1),BLUE),(Ellipse((0,0),6,4),RED)]:patch.set_fill(False);patch.set_edgecolor(color);patch.set_linewidth(2);ax.add_patch(patch)
            ax.set_ylim(-2.7,2.7)
        elif kind=='affine':
            xx=np.linspace(-2,3,100);ax.plot(xx,1-xx,color='#2a2620');ax.plot([0,1],[1,0],color=RED,lw=4);ax.scatter([0,1],[1,0],color=BLUE)
        elif kind=='hull':
            ax.add_patch(Polygon([[0,0],[2,0],[0,2]],facecolor='#dce5e7',edgecolor=BLUE));ax.scatter([0,2,0],[0,0,2],color=BLUE);ax.scatter([.5],[.5],color=RED);ax.set_xlim(-.5,2.5);ax.set_ylim(-.5,2.5)
        elif kind=='halfspace':
            ax.axvspan(-3.5,1,color=BLUE,alpha=.1);ax.axvline(1,color=BLUE);ax.scatter([0,2],[0,0],color=[GREEN,RED]);ax.text(.1,.15,'a');ax.text(2.1,.15,'b')
        elif kind=='intersection':
            ax.add_patch(Circle((0,0),1,facecolor='#dce5e7',edgecolor=BLUE));ax.axvspan(-3.5,.5,color=GREEN,alpha=.15);ax.axvline(.5,color=GREEN);ax.plot([-.6,.3],[.5,-.7],color=RED,lw=2);ax.set_xlim(-1.6,1.6);ax.set_ylim(-1.3,1.3)
        elif kind=='perspective':
            ax.plot([0,2],[1,2],color='#2a2620');ax.plot([0,0],[0,1],color=BLUE);ax.plot([0,2],[0,2],color=BLUE);ax.plot([0,1],[0,1.5],color=RED);ax.axhline(1,color=GREEN,ls='--');ax.scatter([0,2,1],[1,2,1.5],color=['#2a2620','#2a2620',RED]);ax.scatter([0,1,2/3],[1,1,1],color=[BLUE,BLUE,RED]);ax.set_xlim(-.5,2.5);ax.set_ylim(-.3,2.6)
        elif kind in ['soc','dualcone']:
            xx=np.linspace(-3.5,3.5,300);ax.fill_between(xx,np.abs(xx),4.5,color=BLUE,alpha=.1);ax.plot(xx,np.abs(xx),color=BLUE);ax.scatter([0],[1],color=GREEN);ax.set_ylim(-.4,4)
            if kind=='dualcone':ax.scatter([2],[1],color=RED);ax.scatter([-1],[1],color=GREEN);ax.plot([0,2],[0,1],color=RED,ls='--');ax.plot([0,-1],[0,1],color=GREEN,ls='--')
        elif kind=='pareto':
            ax.plot([1,2,4],[4,2,1],color=BLUE,ls='--');ax.scatter([1,2,4],[4,2,1],color=BLUE);ax.scatter([3],[3],color=RED);ax.arrow(3,3,-.8,-.8,color=RED,head_width=.1);ax.set_xlim(0,5);ax.set_ylim(0,5);ax.set_xlabel('cost');ax.set_ylabel('error')
        elif kind=='separation':
            for c in [-2,2]:ax.add_patch(Circle((c,0),1,facecolor='#dce5e7',edgecolor=BLUE))
            ax.axvline(0,color=RED);ax.set_ylim(-1.6,1.6)
        elif kind=='support':
            ax.add_patch(Circle((0,0),1,facecolor='#dce5e7',edgecolor=BLUE));ax.axvline(1,color=RED);ax.scatter([1],[0],color=RED);ax.arrow(1,.5,.7,0,color=GREEN,head_width=.1);ax.set_xlim(-1.5,2);ax.set_ylim(-1.5,1.5)
    fig.tight_layout();out=io.StringIO();fig.savefig(out,format='svg',facecolor=PAPER);plt.close(fig)
    s=out.getvalue();s=s[s.index('<svg'):];s=re.sub(r'<metadata>.*?</metadata>','',s,flags=re.S)
    return s
