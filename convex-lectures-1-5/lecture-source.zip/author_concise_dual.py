"""Author-written sample revision, retaining formulas, interaction and anchors."""
import html
from bs4 import BeautifulSoup
TEXT={}
def put(key,text):TEXT[key]=[line.split('|||') for line in text.strip().splitlines() if line.strip()]

put('prep-0','''
x,z∈Rⁿ 为列向量，z 固定、x 可选。范数 ‖x‖ 衡量长度，内积 zᵀx 给线性评分，单位球限制 ‖x‖≤1。|||The columns x,z∈Rⁿ play different roles: z is fixed and x chosen. Norm ‖x‖ measures length, inner product zᵀx gives a linear score, and the unit ball restricts ‖x‖≤1.
''')
put('prep-1','''
二维向量 x=(x₁,x₂)ᵀ 表示点或箭头，T 是转置。固定 z=(3,−2)ᵀ 时，评分为 zᵀx=3x₁−2x₂。|||A two-dimensional column x=(x₁,x₂)ᵀ represents a point or arrow; T denotes transpose. Fixing z=(3,−2)ᵀ gives score zᵀx=3x₁−2x₂.
x=(1,−1) 给分数 5。继续增大 x₁ 或减小 x₂ 可使分数无界，因此需要长度预算。|||The choice (1,−1) scores 5. Increasing x₁ or decreasing x₂ makes the score unbounded, motivating a length budget.
常用三种长度如下：ℓ₁ 加绝对值，ℓ₂ 用欧氏距离，ℓ∞ 看最大绝对分量。|||Three common lengths are below: ℓ₁ sums absolute entries, ℓ₂ is Euclidean distance, and ℓ∞ takes the largest absolute entry.
对 (3,−2)，三者为 5、√13、3。它们仅在零向量处为零，满足绝对齐次性和三角不等式，因而都是范数。|||For (3,−2), they give 5,√13,3. All vanish only at zero, scale by |t| under multiplication by t, and satisfy the triangle inequality.
单位球是预算≤1 的选择。ℓ₁ 要求两个坐标共享总预算，ℓ∞ 允许每个坐标各用 1；对应菱形、正方形，ℓ₂ 则为圆盘。|||Unit balls contain choices with budget≤1. ℓ₁ shares a total budget across coordinates; ℓ∞ permits 1 per coordinate. They form a diamond and square, while ℓ₂ gives a disk.
三种球均含 (1,0)、(0,1)，但 (1,1) 只在正方形内。可行选择不同，使同一评分产生不同最大值。|||All contain (1,0),(0,1), but only the square contains (1,1). Different feasible choices produce different maximum scores.
''')
put('definition-0','''
对偶范数 ‖z‖* 是固定 z 在原单位球上的最大线性响应。星号依赖原范数，换球也会换结果。|||The dual norm ‖z‖* is the largest linear response to fixed z over the primal unit ball. It depends on the chosen primal norm.
''')
put('definition-1','''
固定评分系数 z，只能选择长度≤1 的 x，最大能得几分？例如 ℓ∞ 球上 z=(3,−2)，(1,−1) 给 5；还须证明没有更好的选择。|||With fixed score coefficients z, choose x of length≤1. How large can the score be? On the ℓ∞ ball, z=(3,−2) gives 5 at (1,−1); we must still rule out a better choice.
上确界是最小上界，未必取到。0<x<1 上最大化 x，上确界为 1，却没有最大值。|||A supremum is the least upper bound and need not be attained. Maximizing x over 0<x<1 has supremum 1 but no maximum.
有限维极值定理保证：连续函数在非空闭有界集上取得极值。闭表示保留收敛点列的极限，有界表示长度不无限增长。|||In finite dimensions, a continuous function attains extrema on a nonempty closed bounded set. Closed sets retain sequence limits; bounded sets have uniformly bounded lengths.
范数单位球符合这些条件，zᵀx 又连续，故这里 sup 实际为 max。计算时将找出取等向量。|||Norm unit balls satisfy these conditions and zᵀx is continuous. Thus the supremum here is attained, and calculations will exhibit a maximizer.
z 是系数向量，‖z‖* 是最大分数。系数翻倍，分数翻倍；z=0 时结果为零。|||The vector z supplies coefficients; ‖z‖* is a scalar score. Doubling z doubles the maximum, and z=0 gives zero.
二维等值线 zᵀx=c 沿 z 方向随 c 增大而移动。例如 z=(1,0) 时为竖线 x₁=c，单位圆盘上最后接触位置是 c=1。|||In two dimensions, level lines zᵀx=c move along z as c increases. For z=(1,0), x₁=c last touches the unit disk at c=1.
一般地，最后接触单位球的等值线是支撑线，法向为 z，位置为 c=‖z‖*。所以对偶范数就是单位球的支撑函数。|||Generally the last touching level line is a support with normal z and value c=‖z‖*. The dual norm is the unit ball's support function.
交互图固定 ‖z‖₂=1，滑块改变方向。蓝箭头为 z，红点为最优 x；直线位置调到 1 时抵达红色支撑线，超过 1 则无可行接触。其 z 与手算 (3,−2) 长度不同。|||The diagram fixes ‖z‖₂=1 and varies its direction. Blue is z and red the optimal x. Line position 1 reaches the red support; above 1 there is no feasible contact. Its z differs in length from the hand example (3,−2).
单位球关于原点对称，x 与 −x 同时可行，故最大化 zᵀx 与 |zᵀx| 结果相同。不对称集合无此保证。|||The unit ball contains x and −x together, so maximizing zᵀx or |zᵀx| gives the same result. Asymmetric sets need not share this property.
''')
put('definition-2','''
取 x=0 得 ‖z‖*≥0；z≠0 时取 x=z/‖z‖，得正内积 zᵀz/‖z‖，故仅 z=0 的对偶范数为零。|||Taking x=0 gives nonnegativity. For z≠0, x=z/‖z‖ gives positive response zᵀz/‖z‖, proving definiteness.
t≥0 可提出上确界；t<0 再用球的对称性，得到 ‖tz‖*=|t|‖z‖*。|||Nonnegative t factors out of the supremum; symmetry handles negative t, yielding ‖tz‖*=|t|‖z‖*.
每个可行 x 都有 (z+w)ᵀx≤‖z‖*+‖w‖*，取上确界即三角不等式。有限性由极值定理保证，因此定义确实给出范数。|||Each feasible x satisfies (z+w)ᵀx≤‖z‖*+‖w‖*. Taking the supremum proves the triangle inequality. Attainment ensures finiteness, completing the norm axioms.
''')
put('common-0','''
第一列指定 x 的预算，第二列计算 z 的对偶值；ℓ₂ 的对偶仍为 ℓ₂，称自对偶。|||The first column specifies the budget for x; the second computes z's dual length. ℓ₂ is self-dual.
''')
put('common-1','''
ℓ∞ 约束让两坐标各自≤1。对 3x₁−2x₂，取 x=(1,−1) 得 5；任意可行 x 的两项至多为 3、2，故最大值确为 5。|||Under ℓ∞, each coordinate has magnitude≤1. The choice (1,−1) scores 5, and the two terms can never exceed 3 and 2, so 5 is the maximum.
ℓ₁ 预算要求 |x₁|+|x₂|≤1，原选择已不可行。第一坐标单位预算收益 3，大于第二的 2，故全投第一坐标，取 (1,0)。|||Under ℓ₁, |x₁|+|x₂|≤1, so the old choice is infeasible. A unit of first-coordinate budget yields 3 versus 2 in the second; choose (1,0).
严格上界为 3x₁−2x₂≤3|x₁|+2|x₂|≤3(|x₁|+|x₂|)≤3，且上述选择取等。|||The bound 3x₁−2x₂≤3|x₁|+2|x₂|≤3(|x₁|+|x₂|)≤3 is attained by that choice.
ℓ₂ 球上，Cauchy–Schwarz 给 zᵀx≤‖z‖₂‖x‖₂≤√13。选与 z 同向的单位向量 x=z/√13 可取等。|||On the ℓ₂ ball, Cauchy–Schwarz gives zᵀx≤‖z‖₂‖x‖₂≤√13, attained by unit vector x=z/√13.
下式分别检查所选点可行、目标达到上界。|||The two substitutions below verify feasibility and attainment.
''')
put('common-2','''
z≠0 取 x=z/‖z‖₂ 达到上界；z=0 取 x=0。故 ℓ₂ 自对偶。|||For z≠0, x=z/‖z‖₂ attains the bound; use zero for z=0. Thus ℓ₂ is self-dual.
取 xᵢ=sgn(zᵢ) 使各项达到 |zᵢ|，得到 ℓ₁ 总和。符号函数对正、负、零分别返回 1、−1、0。|||Choosing xᵢ=sgn(zᵢ) makes each product |zᵢ|, attaining the ℓ₁ sum. The sign function returns 1,−1,0 for positive, negative and zero inputs.
选最大 |zₖ| 的坐标，取 x=sgn(zₖ)eₖ；标准基 eₖ 仅第 k 项为 1。这达到 ‖z‖∞，并列时可任选。z=0 另取零。|||Choose a coordinate maximizing |zₖ| and set x=sgn(zₖ)eₖ, where eₖ has only its kth entry equal to 1. This attains ‖z‖∞; ties allow any maximizing coordinate. Use zero for z=0.
''')
put('inequality-0','''
原范数与对应对偶范数给任意 x,z 的内积界，无须 x 已归一化。|||A primal norm and its dual bound the inner product for arbitrary x,z, without requiring unit x.
''')
put('inequality-1','''
x≠0 时令 r=‖x‖、u=x/r，则 ‖u‖=1，由定义及对称性得 |zᵀu|≤‖z‖*。|||For x≠0, let r=‖x‖ and u=x/r. Then ‖u‖=1 and the definition plus symmetry gives |zᵀu|≤‖z‖*.
把 x=ru 代回并乘 r，得到下式。x=0 时两边均零，无须除法。|||Substitute x=ru and multiply by r to obtain the bound below. At x=0 both sides vanish, with no division needed.
例如原范数 ℓ∞、z=(3,−2)、x=(2,−2)，上界为 2×5=10，实际内积也为 10；取等仅对某些方向成立。|||With primal ℓ∞, z=(3,−2),x=(2,−2), the bound is 2×5=10, equal to the actual product. Other directions need not attain it.
''')
put('inequality-2','''
v 是单位球中的临时变量。先处理 x≠0 的归一化，再单列零向量，便覆盖全部情况。|||The symbol v is a temporary unit-ball variable. Normalize nonzero x, then handle zero separately to cover all cases.
''')
put('quadratic-0','''
实对称正定 P 定义二次范数；标准内积下，其对偶把权重换成 P⁻¹。|||A real symmetric positive definite P defines a quadratic norm; its dual under the standard inner product replaces P by P⁻¹.
z≠0 时下式达到上界；z=0 取 x=0，值为零。|||The following vector attains the bound for z≠0. For z=0, choose x=0 and obtain value zero.
''')
put('quadratic-1','''
P=diag(4,1) 表示对角为 4、1，其余为零。长度为 √(4x₁²+x₂²)，第一方向代价较高。|||The notation diag(4,1) places 4,1 on the diagonal and zeros elsewhere. Length √(4x₁²+x₂²) charges the first direction more heavily.
单位球沿两轴半径为 1/2、1，形成椭圆。同样预算下，较高权重允许较短位移。|||Its unit ball is an ellipse with axis radii 1/2,1. Higher weight permits less displacement under the same budget.
令 u₁=2x₁、u₂=x₂，把椭圆变为圆盘。目标同时变为 (z₁/2)u₁+z₂u₂，第一项系数减半。|||Set u₁=2x₁,u₂=x₂ to obtain the unit disk. The objective becomes (z₁/2)u₁+z₂u₂, halving the first coefficient.
欧氏对偶公式给 √(z₁²/4+z₂²)。逆权重来自反解坐标 x₁=u₁/2，而非另加的规则。|||Euclidean duality gives √(z₁²/4+z₂²). Inverse weighting comes from recovering x₁=u₁/2.
取 z=(2,1)，圆上最优 u=(1,1)/√2，换回 x=(1/(2√2),1/√2)。原约束左边为 4/8+1/2=1，目标为 √2。|||For z=(2,1), the disk optimizer is u=(1,1)/√2, giving x=(1/(2√2),1/√2). The constraint's left side is 4/8+1/2=1 and the score √2.
此时 x 与 z 不同向；直接用 z/‖z‖₂ 会使原约束为 17/5>1，因而不可行。|||Here x is not parallel to z. Directly using z/‖z‖₂ gives constraint value 17/5>1 and is infeasible.
交互图的 z 固定欧氏长度 1，蓝色为 z、红色为最优 x，虚线是支撑线；与手算 z=(2,1) 的长度不同。权重滑块保持 P 正定。|||The diagram fixes ‖z‖₂=1: blue is z, red the optimizer, and the dashed line its support. This differs in length from z=(2,1). Positive weight sliders keep P positive definite.
''')
put('quadratic-2','''
作业 P∈Sⁿ、P≻0 表示 n×n 实对称正定矩阵。正特征值保证可逆，并有对称可逆平方根 P½。|||In the homework, P∈Sⁿ,P≻0 means a real symmetric positive definite n×n matrix. Positive eigenvalues give an inverse and a symmetric invertible square root P½.
特征向量满足 Pv=λv，即变换只沿该方向缩放。实对称矩阵可选正交单位特征向量作为坐标。|||An eigenvector satisfies Pv=λv, so the map scales that direction. A real symmetric matrix has orthonormal eigenvector coordinates.
写 P=QΛQᵀ，则 P½=QΛ½Qᵀ，对特征值开平方。例如 diag(4,1) 的平方根为 diag(2,1)。|||For P=QΛQᵀ, set P½=QΛ½Qᵀ by square-rooting eigenvalues. Thus diag(4,1) has square root diag(2,1).
令 u=P½x，反解 x=P⁻½u。这是双向可逆换元，恰好把椭球可行集换成圆球。|||Set u=P½x and x=P⁻½u. This invertible substitution maps the feasible ellipsoid exactly onto the Euclidean ball.
新的目标系数为 w=P⁻½z，约束为 ‖u‖₂≤1。|||The new coefficient is w=P⁻½z and the constraint ‖u‖₂≤1.
Cauchy–Schwarz 和单位约束给上界 d=√(zᵀP⁻¹z)。接着须找取等点。|||Cauchy–Schwarz and the unit constraint give bound d=√(zᵀP⁻¹z). We still need an attaining point.
z≠0 时 d>0，圆球中取 u*=w/d，换回得到下式。|||For z≠0, d>0. Choose u*=w/d on the disk and transform back as below.
代回原约束和原目标，分别验证可行与取等。|||Substitute into the original constraint and objective to verify feasibility and attainment.
z=0 时所有响应为零，取 x=0；此时 d=0，含除以 d 的构造不适用。|||For z=0 every response is zero; choose x=0. Since d=0, the formula dividing by d does not apply.
''')
put('quadratic-3','''
P=diag(1,0) 仅半正定：非零 (0,1) 的长度也为零，故不定义范数。可行集 |x₁|≤1 为无界条带。|||The PSD matrix diag(1,0) gives zero length to nonzero (0,1), so it does not define a norm. The feasible strip |x₁|≤1 is unbounded.
z=(0,1) 时目标沿 x₂ 无界，z=(1,0) 时最大值仍为 1。因此须检查目标是否沿零代价方向增长，不能直接套正定公式。|||For z=(0,1) the score is unbounded along x₂; for z=(1,0) its maximum is 1. Check response along zero-cost directions before applying a positive definite formula.
''')
put('practice-0','''
为什么同一 z=(3,−2) 在 ℓ∞、ℓ₁ 预算下最大值为 5、3？找到一个可行候选后，还缺哪一步才能证明最优？|||Why does z=(3,−2) give maxima 5 and 3 under ℓ∞ and ℓ₁ budgets? After finding a feasible candidate, what remains to prove optimality?
''')
put('practice-1','''
题 A：原范数 ℓ₁、z=(−2,5)。求对偶值，给出上界及取等向量。|||A: For primal ℓ₁ and z=(−2,5), find the dual value, prove an upper bound and exhibit an optimizer.
题 B：P=diag(9,4)、z=(3,4)。求对偶值与取等向量，代回原约束和目标核对。|||B: For P=diag(9,4),z=(3,4), find the dual value and optimizer, then check the original constraint and objective.
题 C：P≻0、z=0。求上确界，说明为何不能用除以 d 的公式。|||C: For P≻0,z=0, find the supremum and explain why the formula dividing by d fails.
''')
put('advanced-0','''
对 1<p<∞，取 q=p/(p−1)，满足 1/p+1/q=1。Hölder 不等式给单位 ℓp 球上的目标上界 ‖z‖q。|||For 1<p<∞, set q=p/(p−1), so 1/p+1/q=1. Hölder bounds the response on the unit ℓp ball by ‖z‖q.
z≠0 时，选同符号、大小与 |zᵢ|ᑫ⁻¹ 成比例的分量，再归一化：|||For z≠0, match signs, allocate magnitudes proportional to |zᵢ|ᑫ⁻¹, and normalize:
由 (q−1)p=q，下式直接验证单位长度和上界取等。|||Since (q−1)p=q, the following identities verify unit length and attainment.
因此 ℓp 对偶为 ℓq。z=0 取零；p=1、∞ 使用前面的坐标构造，不能代入有限幂公式。|||Thus ℓp has dual ℓq. Use zero when z=0; endpoints p=1,∞ use the earlier coordinate constructions, not the finite-power formula.
''')
put('advanced-1','''
矩阵内积为 tr(ZᵀX)，即对应元素乘积之和；迹 tr 是对角元素之和。固定 Z，同样可问单位矩阵预算下的最大响应。|||Matrix inner product tr(ZᵀX) sums matching entry products; trace sums diagonal entries. Fix Z and maximize response under a matrix norm budget.
谱范数取最大奇异值，核范数加全部奇异值，Frobenius 范数为元素平方和的根。diag(3,2) 的三者为 3、5、√13。|||Spectral norm is the largest singular value, nuclear norm their sum, and Frobenius norm the root sum of squared entries. For diag(3,2), these give 3,5,√13.
谱范数的对偶是核范数。例如 Z=diag(3,2)，谱单位球内取 X=I，迹响应为 5。|||The spectral norm's dual is the nuclear norm. For Z=diag(3,2), X=I is spectral-unit feasible and gives trace response 5.
奇异值是正交输入方向的放大倍数，分解同时给出对应正交输出方向。|||Singular values are amplification factors along orthogonal input directions, with corresponding orthogonal output directions.
薄 SVD 为 Z=Σᵢσᵢuᵢvᵢᵀ，仅保留正奇异值。谱单位预算保证 ‖Xvᵢ‖₂≤1，故 |uᵢᵀXvᵢ|≤1，得下式上界。|||A thin SVD writes Z=Σᵢσᵢuᵢvᵢᵀ using positive singular values. Spectral-unit feasibility gives ‖Xvᵢ‖₂≤1 and hence |uᵢᵀXvᵢ|≤1, proving the bound below.
取 X=UVᵀ，把每个 vᵢ 映为 uᵢ，谱范数为 1 且各项取等。Z=0 取零。Frobenius 则由元素的欧氏对偶性得自对偶。|||Choose X=UVᵀ, mapping each vᵢ to uᵢ with spectral norm 1 and equality in every term. Use zero for Z=0. Frobenius is self-dual by Euclidean duality on entries.
''')
put('advanced-2','''
‖z‖*≤1 表示原球中每个 x 都有 zᵀx≤1，因此对偶单位球就是极集 B°：|||The condition ‖z‖*≤1 means zᵀx≤1 for every primal-ball point x. Thus the dual ball is the polar B°:
有限维闭凸集 B 含原点时，分离定理给 B°°=B。范数单位球符合条件，故双对偶恢复原球与原范数。|||For finite-dimensional closed convex B containing zero, separation gives B°°=B. Norm unit balls satisfy these conditions, so biduality restores the ball and norm.
例如菱形与正方形互为极集。一般结论将在凸集课用分离定理解释。|||The diamond and square are mutual polars. The general result uses the separation theorem from the convex-set lecture.
''')
put('advanced-3','''
范数锥 K={(x,t):‖x‖≤t} 把 t 看作预算。其对偶锥要求 zᵀx+st≥0 对所有 (x,t)∈K 成立。|||The norm cone K={(x,t):‖x‖≤t} uses t as budget. Its dual cone requires zᵀx+st≥0 for every (x,t)∈K.
若 ‖z‖*≤s，内积界给 zᵀx+st≥−‖z‖*t+st≥0，故属于对偶。|||If ‖z‖*≤s, the inner-product bound gives zᵀx+st≥−‖z‖*t+st≥0, proving dual membership.
若 s<‖z‖*，选单位球内 u 使 zᵀu>s，则 (−u,1)∈K 给负内积。因此 K*={(z,s):‖z‖*≤s}。|||If s<‖z‖*, choose unit-ball u with zᵀu>s. Then (−u,1)∈K gives negative pairing. Hence K*={(z,s):‖z‖*≤s}.
ℓ₂ 自对偶，所以二阶锥自对偶，连接作业 5(b)。K* 是集合，‖z‖* 是数，需分清对象。|||Since ℓ₂ is self-dual, its SOC is self-dual, connecting to HW1 5(b). Distinguish the set K* from the scalar ‖z‖*.
''')
put('advanced-4','''
共轭 f*(z)=supₓ(zᵀx−f(x)) 在内积收益中扣除函数代价。对 f(x)=‖x‖，结果取决于收益能否超过长度。|||The conjugate f*(z)=supₓ(zᵀx−f(x)) subtracts function cost from linear reward. For f(x)=‖x‖, the result depends on whether reward can exceed length cost.
‖z‖*≤1 时，目标≤(‖z‖*−1)‖x‖≤0，取 x=0 达零。否则选单位 u 使 zᵀu>1，令 x=tu，正收益随 t→∞ 无界。|||For ‖z‖*≤1, the objective≤(‖z‖*−1)‖x‖≤0, attained at zero. Otherwise choose unit u with zᵀu>1; scaling x=tu makes positive reward unbounded.
因此范数的共轭是对偶单位球的示性函数：球内零、球外 +∞。它与对偶范数、对偶锥各有不同定义。|||Thus the norm's conjugate is the dual-ball indicator: zero inside and +∞ outside. It differs in definition from a dual norm or dual cone.
''')

def apply_sample(soup):
    for key,pairs in TEXT.items():
        layer=soup.find(id=key)
        paragraphs=layer.find_all('p',recursive=False)
        assert len(paragraphs)==len(pairs),(key,len(paragraphs),len(pairs))
        # Reuse the source term buttons at their first matching term in the new prose.
        terms={b['data-term']:b for p in paragraphs for b in p.select('button.term')}
        used=set()
        for old,(z,e) in zip(paragraphs,pairs):
            fragment='<p><span class="zh" lang="zh-CN">'+html.escape(z)+'</span><span class="en" lang="en">'+html.escape(e)+'</span></p>'
            node=BeautifulSoup(fragment,'html.parser').p
            for lang in ['zh','en']:
                span=node.find('span',class_=lang,recursive=False)
                for term,button in terms.items():
                    label=button.find('span',class_=lang).get_text()
                    if label and label in span.get_text() and (term,lang) not in used:
                        text=str(span.contents[0]);before,after=text.split(label,1)
                        span.clear();span.append(before);span.append(BeautifulSoup(str(button),'html.parser').button);span.append(after)
                        used.add((term,lang));break
            old.replace_with(node)
    extras={
        '#definition .observe p':('选 ℓ₂、方向 0°，将直线位置从 0 调至 1、1.1，观察它经过中心、接触边界、离开圆盘。再选方向 45°，切换三种球，比较最大值。','Choose ℓ₂ at 0° and move the line from 0 to 1 to 1.1: center, boundary contact, then no contact. At 45°, switch balls and compare maxima.'),
        '#common .note p':('证明最大值须给出适用于全部可行点的上界，再找可行点达到；x* 是向量，‖z‖* 是数。','Prove a bound for all feasible points, then exhibit attainment. The optimizer x* is a vector; ‖z‖* is a scalar.'),
        '#quadratic .observe p':('先取 p₁=p₂=1、方向 45°，再将 p₁ 增至 4。观察椭圆变窄、x* 与 z 分离；核对 x*ᵀPx*=1、zᵀx*=对偶值。','Start with p₁=p₂=1 at 45°, then increase p₁ to 4. Watch the ellipse narrow and x* turn away from z. Check x*ᵀPx*=1 and response=dual value.'),
        '#quadratic .note p':('作业证明保留正定条件、可逆换元、上界、取等验证和 z=0 的单独处理。','Retain positive definiteness, invertible substitution, an upper bound, attainment checks and the zero case.'),
        '#concept-answer p':('ℓ∞ 的各坐标独立用预算，ℓ₁ 则共享预算，故原来的 (1,−1) 不再可行。可行候选只给最大值下界，还需证明没有更大值。','ℓ∞ budgets are independent; ℓ₁ shares a budget, excluding (1,−1). A feasible candidate only bounds the maximum from below; an upper bound is still needed.'),
        '#hint-a p':('先界为 5(|x₁|+|x₂|)，再把预算给系数绝对值更大的第二坐标。','Bound by 5(|x₁|+|x₂|), then give the budget to the larger second coefficient.'),
        '#answer-a p':('取 x*=(0,1)，ℓ₁ 长度为 1、响应为 5，达到上界。','Choose x*=(0,1), with ℓ₁ length 1 and response 5, attaining the bound.'),
        '#hint-b1 p':('P⁻¹=diag(1/9,1/4)，故 d²=3²/9+4²/4。','P⁻¹=diag(1/9,1/4), so d²=3²/9+4²/4.'),
        '#hint-b2 p':('先求 P⁻¹z=(1/3,1)，再除以 d；核对原椭圆约束。','Compute P⁻¹z=(1/3,1), divide by d, and check the original ellipsoid constraint.'),
        '#answer-b p':('该向量满足原约束并取得上界 √5，故最优。','The vector satisfies the original constraint and attains bound √5, proving optimality.'),
        '#answer-c p':('目标处处零，取 x=0。因 d=0，含分母的公式无定义。','The objective is identically zero; choose x=0. The formula dividing by d is undefined because d=0.'),
        '#practice .note p':('合上答案重写题 B，注明换元与不等式的依据。','Close the answer and rewrite B, explaining the substitution and inequalities.')
    }
    for selector,(z,e) in extras.items():
        old=soup.select_one(selector);assert old is not None,selector
        node=BeautifulSoup('<p><span class="zh" lang="zh-CN">'+html.escape(z)+'</span><span class="en" lang="en">'+html.escape(e)+'</span></p>','html.parser').p
        old.replace_with(node)
