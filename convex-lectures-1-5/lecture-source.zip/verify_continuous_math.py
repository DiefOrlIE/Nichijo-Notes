"""Independent checks of the numerical examples; these do not replace proofs."""
import json
from pathlib import Path
import numpy as np
import sympy as sp
R=Path(__file__).parent
checks=[]
def check(name,value):
    assert value,name
    checks.append(name)

u,v,t=sp.symbols('u v t',real=True)
check('Schur square completion',sp.expand(4*(u+v/2)**2+(t-1)*v*v-(4*u*u+4*u*v+t*v*v))==0)
check('Gradient example exact change',np.isclose((1.01**2+3*.98**2)-4,-.0987))
P=np.array([[2.,1.],[1.,2.]]);z=np.array([1.,-1.]);d=np.sqrt(z@np.linalg.solve(P,z));x=np.linalg.solve(P,z)/d
check('Quadratic dual value and original feasibility',np.isclose(d,np.sqrt(2)) and np.isclose(x@P@x,1) and np.isclose(z@x,d))
P=np.diag([9.,1.]);z=np.array([3.,2.]);d=np.sqrt(z@np.linalg.solve(P,z));x=np.array([1/(3*np.sqrt(5)),2/np.sqrt(5)])
check('Diagonal quadratic example sqrt5',np.isclose(d,np.sqrt(5)) and np.isclose(x@P@x,1) and np.isclose(z@x,d))
A=np.array([[1.,-3.,2.],[-2.,0.,1.]]);x=np.array([1.,-1.,1.])
check('Rectangular row norm attainment',np.max(np.sum(abs(A),axis=1))==6 and np.allclose(A@x,[6,-1]))
check('Pseudoinverse example',np.allclose(np.linalg.pinv(np.diag([3.,1.,0.]))@np.array([6.,2.,5.]),[2,2,0]))
coeff=np.array([[1.,0.],[-1.,0.],[0.,1.]])
def lse(x):
    s=coeff@x;p=np.exp(s-s.max());p/=p.sum();mean=p@coeff
    return s.max()+np.log(np.exp(s-s.max()).sum()),mean,(coeff.T*p)@coeff-np.outer(mean,mean)
rng=np.random.default_rng(20261016)
for x in rng.normal(size=(10,2)):
    _,g,H=lse(x);eps=1e-5
    gn=np.array([(lse(x+eps*e)[0]-lse(x-eps*e)[0])/(2*eps) for e in np.eye(2)])
    Hn=np.column_stack([(lse(x+eps*e)[1]-lse(x-eps*e)[1])/(2*eps) for e in np.eye(2)])
    assert np.allclose(g,gn,atol=1e-7) and np.allclose(H,Hn,atol=1e-7) and np.min(np.linalg.eigvalsh(H))>0
check('LSE gradient/Hessian finite differences at ten points',np.allclose(lse(np.zeros(2))[2],np.diag([2/3,2/9])))
check('SOC exterior certificate',np.isclose(np.dot([3,4],[-3/5,-4/5])+4,-1))
check('Distance halfspace coefficients',np.allclose(2*(np.array([3,0])-np.array([-1,2])),[8,-4]) and 9-5==4)
check('Perspective inverse mixture',np.isclose((2/3)/(4/3),.5))
a,b,theta=sp.symbols('a b theta',real=True)
check('Strict square convexity gap',sp.expand((1-theta)*a*a+theta*b*b-((1-theta)*a+theta*b)**2-theta*(1-theta)*(a-b)**2)==0)
check('Partial minimization square',sp.expand((u-v)**2+v*v-2*(v-u/2)**2-u*u/2)==0)
xx=sp.symbols('x',real=True);yn=sp.symbols('y',negative=True)
check('Negative log conjugate',sp.simplify((yn*xx+sp.log(xx)).subs(xx,-1/yn)-(-1-sp.log(-yn)))==0)
gauss=sp.exp(-(xx-2)**2/2)+sp.exp(-(xx+2)**2/2)
check('Sum of log-concave counterexample',sp.simplify(sp.diff(sp.log(gauss),xx,2).subs(xx,0))==3)
check('Conjugate translated quadratic',sp.expand((a*xx-(xx-2)**2/2-3).subs(xx,a+2)-(a*a/2+2*a-3))==0)
for _ in range(10):
    a=rng.normal(size=(3,2));b=rng.normal(size=(3,2));theta=.37;c=(1-theta)*a+theta*b
    assert np.allclose((1-theta)*a@a.T+theta*b@b.T-c@c.T,theta*(1-theta)*(a-b)@(a-b).T)
check('Matrix convex outer-product gaps at ten pairs',True)
xp=sp.symbols('xp',positive=True)
check('Transfer scalar second derivatives',sp.diff(sp.exp(-2*xx),xx,2)==4*sp.exp(-2*xx) and sp.simplify(sp.diff(-sp.log(2*xx+1),xx,2)-4/(2*xx+1)**2)==0 and sp.simplify(sp.diff((xx+1)*sp.log(xx+1),xx,2)-1/(xx+1))==0)
H=2*np.array([[1.,2.],[2.,4.]])
check('Rank-deficient least-squares null direction',np.allclose(H@np.array([-2.,1.]),[0,0]) and np.min(np.linalg.eigvalsh(H))>=-1e-12)
check('Weighted infinity allowance near interior point',2*.25<1-.25)
for y in rng.normal(size=(10,3)):
    point=-np.sign(y)
    assert np.max(abs(point))<=1 and np.isclose(y@point,-sum(abs(y)))
check('Infinity norm cone dual test signs',True)
(R/'完整讲义/continuous-math-verification.json').write_text(json.dumps({'checks':checks,'limits':'Numerical samples and symbolic identities supplement, rather than establish, general proofs.'},ensure_ascii=False,indent=2),encoding='utf8')
print('Independent numerical/symbolic checks:',len(checks))
