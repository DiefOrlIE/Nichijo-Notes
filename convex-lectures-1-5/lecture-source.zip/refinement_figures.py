"""Numerical, equal-scale geometry for the specification's three replacements."""
import io,re
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Ellipse,Polygon
PAPER='#faf6ee';BLUE='#315b78';RED='#a54b3d';GREEN='#757e6d'
CAPTIONS={
'geometry-pair':('左图横纵轴是变换后的坐标 Au，蓝色单位圆供比较，红椭圆为 A=diag(3,2) 的线性像，半轴 3、2。右图坐标是预算变量 x，红椭圆满足 4x₁²+x₂²≤1，半轴 1/2、1。两图各自横纵等比例；矩阵、变量及尺度不同，请分别读刻度。','Left: output coordinates Au. A blue unit circle is compared with the red image under A=diag(3,2), with radii 3,2. Right: budget coordinates x. The red ellipse satisfies 4x₁²+x₂²≤1, with radii 1/2,1. Each panel uses equal axis scaling; their matrices, variables and numerical ranges differ.'),
'simplex':('二维参数图的轴为 θ₁、θ₂，蓝色三角形满足 θ₁≥0、θ₂≥0、θ₁+θ₂≤1。第三项由 θ₃=1−θ₁−θ₂ 恢复。红点 (1/4,1/4) 对应三维权重 (1/4,1/4,1/2)。这是 R³ 中平面 θ₁+θ₂+θ₃=1 的参数图，三角形的三维环境内部为空。','This two-dimensional parameter plot uses axes θ₁,θ₂ and triangle θ₁≥0,θ₂≥0,θ₁+θ₂≤1. Recover θ₃=1−θ₁−θ₂. The red point (1/4,1/4) represents weights (1/4,1/4,1/2) in R³. It parameterizes the plane θ₁+θ₂+θ₃=1, whose ambient three-dimensional interior is empty.'),
'exp-conjugate':('两图横轴都是被优化的 x，纵轴是 yx−eˣ，颜色表示固定斜率 y。左图 y=1 在 x=0 达到最大 −1；y=0 的红线始终低于 0，向左仅逼近 0。右图 y=−1，向左目标持续增大，表明上确界为 +∞。图只画有限窗口；无穷处的结论由正文极限证明。','Both panels plot the optimized variable x against yx−exp(x), with colors indicating fixed y. Left: y=1 attains maximum −1 at x=0; red y=0 stays below 0 and only approaches it to the left. Right: for y=−1 the objective grows without bound to the left. Finite plot windows illustrate the limits proved in the text.')}
def figure(kind):
    fig,axes=plt.subplots(1,2 if kind!='simplex' else 1,figsize=(8.2,3.5),facecolor=PAPER)
    axs=np.atleast_1d(axes)
    for ax in axs:
        ax.set_facecolor(PAPER);ax.spines[['right','top']].set_visible(False);ax.grid(alpha=.15);ax.tick_params(labelsize=9)
    if kind=='geometry-pair':
        for ax in axs:
            ax.set_aspect('equal');ax.add_patch(Ellipse((0,0),2,2,fill=False,edgecolor=BLUE,ls='--',label='unit circle'))
        axs[0].add_patch(Ellipse((0,0),6,4,facecolor=RED,alpha=.15,edgecolor=RED));axs[0].set(xlim=(-3.5,3.5),ylim=(-2.5,2.5),xlabel='(Au)1',ylabel='(Au)2',title='Linear image: A = diag(3,2)')
        axs[1].add_patch(Ellipse((0,0),1,2,facecolor=RED,alpha=.25,edgecolor=RED));axs[1].set(xlim=(-1.25,1.25),ylim=(-1.25,1.25),xlabel='x1',ylabel='x2',title='Budget: P = diag(4,1)');axs[1].set_xticks([-.5,0,.5])
        for ax in axs:ax.legend(frameon=False,fontsize=8)
    elif kind=='simplex':
        ax=axs[0];ax.add_patch(Polygon([(0,0),(1,0),(0,1)],facecolor='#dce5e7',edgecolor=BLUE));ax.scatter([.25],[.25],color=RED);ax.annotate('(1/4,1/4; third = 1/2)',(.25,.25),xytext=(.35,.38),fontsize=10);ax.set(aspect='equal',xlim=(-.08,1.1),ylim=(-.08,1.1),xlabel='theta1',ylabel='theta2');ax.text(.46,.55,'theta3 = 0',rotation=-45,fontsize=9);ax.text(.05,.06,'theta3 = 1 - theta1 - theta2',fontsize=9)
    else:
        x=np.linspace(-6,2,500)
        axs[0].plot(x,x-np.exp(x),color=BLUE,label='y = 1');axs[0].plot(x,-np.exp(x),color=RED,label='y = 0');axs[0].axhline(0,color=GREEN,ls='--');axs[0].scatter([0],[-1],color=BLUE);axs[0].set(ylim=(-7,1),xlabel='x',ylabel='y*x - exp(x)');axs[0].legend(frameon=False)
        axs[1].plot(x,-x-np.exp(x),color=GREEN,label='y = -1');axs[1].set(xlabel='x',ylabel='y*x - exp(x)');axs[1].legend(frameon=False)
    fig.tight_layout();out=io.StringIO();fig.savefig(out,format='svg',facecolor=PAPER);plt.close(fig)
    s=out.getvalue();return re.sub(r'<metadata>.*?</metadata>','',s[s.index('<svg'):],flags=re.S)
