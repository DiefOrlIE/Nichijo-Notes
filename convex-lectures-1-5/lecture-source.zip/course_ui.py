"""Shared reading UI simplifications, applied to source builds and existing HTML."""
from bs4 import BeautifulSoup
from pathlib import Path

UI_CSS='\n/* Keep reading-depth headings quiet and original-slide boxes half width. */\ndetails[id$="-original"]{width:50%;box-sizing:border-box}\n'

def simplify_headings(soup):
    labels={'速通':'速通','复习':'速通','了解':'了解','掌握':'掌握','深入':'深入'}
    english={'Quick':'Quick','Review':'Quick','Understand':'Understand','Mastery':'Mastery','In depth':'In depth'}
    changed=0
    for heading in soup.select('.layer > h3'):
        z=heading.select_one('.zh');e=heading.select_one('.en')
        if z is None or e is None:continue
        prefix=z.get_text(strip=True).split('·',1)[0].strip()
        if prefix not in labels:continue
        z.clear();z.append(labels[prefix])
        heading['class']=list(dict.fromkeys(heading.get('class',[])+['reading-level-label']))
        eprefix=e.get_text(strip=True).split('·',1)[0].strip()
        e.clear();e.append(english.get(eprefix,{'速通':'Quick','了解':'Understand','掌握':'Mastery','深入':'In depth'}[labels[prefix]]))
        for badge in heading.select('.new'):badge.decompose()
        changed+=1
    return changed

def apply_to_existing(path):
    soup=BeautifulSoup(path.read_text(encoding='utf8'),'html.parser')
    changed=simplify_headings(soup)
    style=soup.find(id='course-ui-refinement')
    if style is None:
        style=soup.new_tag('style',id='course-ui-refinement');soup.head.append(style)
    style.string=UI_CSS+(Path(__file__).parent/'reader_controls.css').read_text(encoding='utf8')
    aside=soup.find('aside');aside['id']='course-contents'
    if soup.find(id='sidebar-toggle') is None:
        for id,label in [('sidebar-toggle','目录 / Contents'),('theme-toggle','夜间模式 / Dark mode')]:
            button=soup.new_tag('button',id=id,attrs={'type':'button'});button.string=label
            soup.select_one('header .tools').insert(0,button)
    if soup.find(id='sidebar-close') is None:
        close=soup.new_tag('button',id='sidebar-close',attrs={'type':'button','aria-label':'收起目录','title':'收起目录'})
        aside.insert(0,close)
    # A geometric icon avoids font-dependent baseline offsets in the close buttons.
    for close in [soup.find(id='sidebar-close'),soup.find(id='term-close')]:
        if close is None:continue
        close.clear()
        icon=BeautifulSoup('<svg class="close-icon" width="14" height="14" viewBox="0 0 24 24" fill="none" aria-hidden="true" focusable="false"><path d="M6 6L18 18M18 6L6 18" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>','html.parser').svg
        close.append(icon)
    if soup.find(id='keyboard-hint') is None:
        hint=soup.new_tag('p',id='keyboard-hint',attrs={'class':'keyboard-hint'})
        aside.append(hint)
    back=soup.select_one('a.home-back')
    if back is None:
        back=soup.new_tag('a',attrs={'class':'home-back'});soup.body.insert(0,back)
    back['id']='parent-directory';back['href']='../'
    back['aria-label']='返回上级目录';back['title']='返回 Nichijo Notes 笔记目录'
    back.clear()
    for lang,label in [('zh','← 返回上级目录'),('en','← Notes directory')]:
        span=soup.new_tag('span',attrs={'class':lang,'lang':'zh-CN' if lang=='zh' else 'en'})
        span.string=label;back.append(span)
    if soup.find(id='reader-theme-init') is None:
        initial=soup.new_tag('script',id='reader-theme-init')
        initial.string="try{const s=JSON.parse(localStorage.getItem('convex-reading-ui-v1')||'{}');document.documentElement.dataset.theme=s.theme==='dark'||(!s.theme&&matchMedia('(prefers-color-scheme: dark)').matches)?'dark':'light';document.documentElement.dataset.sidebar=s.sidebarHidden?'hidden':'shown';}catch(e){}"
        soup.head.insert(1,initial)
    script=soup.find(id='reader-controls')
    if script is None:script=soup.new_tag('script',id='reader-controls');soup.body.append(script)
    script.string=(Path(__file__).parent/'reader_controls.js').read_text(encoding='utf8')
    path.write_text(str(soup),encoding='utf8')
    return changed
