"""Combine the new chapters and preserve all original anchors and source pages."""
from pathlib import Path
if (Path(__file__).parent / "讲稿修订_2026-10-23/修订任务表.md").exists():
    from generate_review_revision import build
    build()
    raise SystemExit(0)
import copy,base64,hashlib,html,json,os
from bs4 import BeautifulSoup
from fontTools.ttLib import TTFont
from fontTools.varLib.instancer import instantiateVariableFont
from fontTools import subset
from chapter2_content import p,m,bi,extra

R=Path(__file__).parent;OUT=R/'完整讲义';old=BeautifulSoup((R/'结构重写前来源快照.html').read_text(encoding='utf8'),'html.parser')
pages={k:BeautifulSoup((OUT/f'chapter-{k}.html').read_text(encoding='utf8'),'html.parser') for k in [2,3,4,5]}
mainpage=copy.deepcopy(pages[2]);holder=mainpage.select_one('.reading-width');holder.clear()
hero=BeautifulSoup('<div class="hero"><p class="eyebrow">CONVEX OPTIMIZATION / LECTURES 01–05</p><h1>'+bi('凸优化 · 自学讲义','Convex optimization · A self-study handbook')+'</h1><p>'+bi('按概念、例题与证明连续阅读。第二至五讲为本轮重写正文；第一讲保留此前版本，并补清已指出的模型与公式引入。','Read definitions, examples and proofs in sequence. Lectures 2–5 have been rewritten; Lecture 1 retains earlier material with the identified model and formula introductions clarified.')+'</p><p class="meta">'+bi('中英切换 · 47个知识单元 · 280页原课件','Two languages · 47 units · 280 original slides')+'</p><p><a href="chapter-2.html">'+bi('单独阅读第二章','Read Chapter 2 separately')+'</a> · <a href="hw1-route.html">'+bi('HW1连续路线','Continuous HW1 route')+'</a> · <a href="chapter-rewrite-review.md">'+bi('审阅与修订记录','Review and revisions')+'</a></p></div>','html.parser')
holder.append(hero)
units={}
for uid in [f'{i:02}' for i in range(1,6)]:
    source=old.find(id='u'+uid);u=BeautifulSoup('<section id="u'+uid+'"><h2></h2><div class="full-copy"></div></section>','html.parser').section
    u.h2.append(copy.deepcopy(source.h2));u.h2.h2.unwrap();full=u.select_one('.full-copy')
    for layer in source.select('.layer'):
        level=layer.get('data-level')
        if level not in ['2','3','4']:continue
        if level=='4':
            content=''.join(str(n) for n in layer.contents if getattr(n,'name',None)!='h3')
            full.append(BeautifulSoup(extra('进一步联系','Further connections',content),'html.parser'));continue
        clone=copy.deepcopy(layer)
        if clone.h3:clone.h3.decompose()
        clone.name='div';clone.attrs={}
        full.append(clone)
    original=source.find('details',id='u'+uid+'-original')
    if original:original=copy.deepcopy(original);original['class']=['original'];full.append(original)
    for n in u.select('[data-level],[data-threshold]'):
        n.attrs.pop('data-level',None);n.attrs.pop('data-threshold',None)
    units[uid]=u

def insert_before_para(uid,needle,content):
    target=next(n.find_parent('p') for n in units[uid].select('p .zh') if needle in n.get_text());target.insert_before(BeautifulSoup(content,'html.parser'))
def replace_para(uid,needle,content):
    target=next(n.find_parent('p') for n in units[uid].select('p .zh') if needle in n.get_text());target.replace_with(BeautifulSoup(content,'html.parser'))
insert_before_para('04','照明模型中',p('照明设计的任务是：几盏灯的位置固定，调节每盏灯的功率，让若干测量点的亮度尽量接近指定值。我们要选的是灯的功率，测量点的位置以及灯到各点的影响已知。于是先建立“功率怎样决定亮度”的关系，再选择衡量偏差的目标函数。','In illumination design, lamp positions are fixed. Choose each lamp power so that brightness at several measurement points approaches a target. Powers are decision variables; measurement locations and each lamp contribution are known. First model brightness from powers, then choose a deviation objective.'))
replace_para('05','凸松弛扩大',p('凸松弛先把难处理的非凸可行集放宽成一个包含它的凸集，再解决放宽后的问题。例如原约束 x∈{−1,1}，放宽为 −1≤x≤1。若目标为最小化 x²，原问题最小值是1，放宽后可选 x=0，最小值变为0。新增了选择，最小费用便可能更低；这个0是原最优值的下界，却不是原问题的可行解。','A convex relaxation replaces a difficult nonconvex feasible set by a containing convex set. For example relax x∈{−1,1} to −1≤x≤1 while minimizing x². The original minimum is one; the relaxation allows x=0 with minimum zero. More choices can lower the minimum. Zero is a lower bound, but x=0 is not an original feasible solution.'))
replace_para('05','若原可行集 C',extra('一般下界的写法','The general lower-bound relation',p('用 C 表示原可行集、D 表示放宽后的集合，C⊆D。原目标 f 定义在 C 上，放宽目标 g 定义在 D 上；若原可行点处总有 g(x)≤f(x)，则下面两个比较依次来自扩大选择集、逐点压低目标。只放宽约束时，目标保持相同。','Let C be the original feasible set and D its relaxation, C⊆D. Let f be the original cost on C and g a cost on D satisfying g(x)≤f(x) on C. The two comparisons below follow from enlarging the choice set and lowering costs pointwise. A constraint-only relaxation keeps the same cost.')+m(r'\inf_{x\in D}g(x)\leq\inf_{x\in C}g(x)\leq\inf_{x\in C}f(x).')))
replace_para('05','f″(x)=12',p('继续分析前面的 f(x)=(x²−1)²。我们已由一阶导数找到驻点 −1、0、1，现在用二阶导数判断它们附近的弯曲方向：二阶导正给严格局部极小，负给严格局部极大。先求导再逐点代入：','Continue with f(x)=(x²−1)². The first derivative gave stationary points −1,0,1. We now use the second derivative to classify their local curvature: positive gives a strict local minimum and negative a strict local maximum. Differentiate and evaluate:')+m(r'f\prime(x)=4x(x^2-1),\quad f\prime\prime(x)=12x^2-4,\quad f\prime\prime(\pm1)=8,\quad f\prime\prime(0)=-4.')+p('因此 ±1 为严格局部极小、0 为严格局部极大。全局结论另外由 f(x)≥0 且 f(±1)=0 得到；局部二阶判断本身没有比较远处所有点。','Thus ±1 are strict local minima and zero a strict local maximum. Global optimality follows separately from f(x)≥0 and f(±1)=0; the local second-derivative test does not compare all distant points.'))
hints={
'01':('把候选点代入新的等式约束；原最优点只有仍满足等式才可保留。','Substitute into the new equality; an old optimizer remains eligible only if it satisfies it.'),
'02':('先把三项误差平方相加，再围绕观测平均值配方。','Sum the three squared errors and complete the square around their mean.'),
'03':('给两个绝对值各设一个上界变量，并分别用两条线性不等式约束。','Introduce one upper-bound variable for each absolute value and constrain it by two linear inequalities.'),
'04':('分别写出三个集合，再取 −1、1 检查中点 0 是否保留。','Write the three sets and test whether they retain midpoint zero between −1 and one.'),
'05':('局部极小要求附近所有点费用不低于零点；试取一个任意小的负输入。','A local minimum requires nearby values no smaller than the value at zero; test a small negative input.')}
steps={
'01':('把“至少4”改写为“等于4”，先检查 (0,5) 是否恰好提供4；再把原最优点代回新等式。','Replace “at least four” by equality. Check whether (0,5) supplies exactly four, then substitute the previous optimizer into the equality.'),
'02':('平方和为 c²+(c−2)²+(c−4)²=3(c−2)²+8。','The squared error is c²+(c−2)²+(c−4)²=3(c−2)²+8.'),
'03':('设 u≥x−2、u≥2−x，v≥x+1、v≥−x−1，最小化 u+v；两绝对值之和至少为 |(x−2)−(x+1)|=3。','Use u≥x−2, u≥2−x, v≥x+1, v≥−x−1 and minimize u+v. The absolute-value triangle inequality gives the lower bound three.'),
'04':('三个集合分别为 [−1,1]、(−∞,−1]∪[1,∞)、{−1,1}。对后两者，中点0都被排除。','The sets are [−1,1], (−∞,−1]∪[1,∞), and {−1,1}. The last two exclude midpoint zero.'),
'05':('任意 ε>0 都有 f(−ε)=−ε³<0=f(0)，而 −ε 可以任意接近0。','For every ε>0, f(−ε)=−ε³<0=f(0), with −ε arbitrarily close to zero.')}
for uid,u in units.items():
    for suffix in ['hint','steps']:
        detail=u.find(id='u'+uid+'-'+suffix)
        if detail:
            summary=detail.summary.extract();detail.clear();detail.append(summary)
            detail.append(BeautifulSoup(p(*(hints[uid] if suffix=='hint' else steps[uid])),'html.parser'))

for lid,page in pages.items():
    for u in page.select('section[id^="u"]'):units[u['id'][1:]]=copy.deepcopy(u)

# Stable semantic anchors for homework evidence and old shared links.
semantic={'09':{'输入、输出都用':'induced-method','连续经过':'induced-proof'},'13':{'例：指数':'lse-gradient'},'14':{'继续计算':'lse-hessian'},'16':{'用已有工具':'quadratic-method'},'19':{'例：线性':'sets-method'},'25':{'例：二阶':'soc-proof'},'29':{'二阶锥为何':'soc-dual-method'},'31':{'严格凸能':'strict-definition'},'33':{'三个一元':'scalar-curvature','例：最小二乘':'least-squares-hessian'},'36':{'归纳到':'jensen-proof'}}
for uid,needles in semantic.items():
    for needle,ident in needles.items():
        match=next((n for n in units[uid].select('h3') if needle in n.get_text()),None)
        if match:match['id']=ident
global_ids={n['id'] for u in units.values() for n in u.select('[id]')}|{u['id'] for u in units.values()}
for uid in units:
    have={n.get('id') for n in units[uid].select('[id]')}|{units[uid]['id']}
    oldunit=old.find(id='u'+uid)
    aliases=[]
    for n in oldunit.select('[id]'):
        ident=n['id']
        if ident not in global_ids:
            aliases.append('<span class="anchor-alias" id="'+html.escape(ident,quote=True)+'"></span>');have.add(ident);global_ids.add(ident)
    units[uid].h2.insert_before(BeautifulSoup(''.join(aliases),'html.parser'))

nav=mainpage.nav;nav.clear()
for lid in range(1,6):
    if lid==1:
        heading=BeautifulSoup('<div class="chapter-opening" id="lecture-1"><h2>'+bi('第一讲 · 建模与凸优化概览','Lecture 1 · Modeling and convex optimization')+'</h2></div>','html.parser');holder.append(heading)
    else:
        opening=BeautifulSoup('<div class="chapter-opening" id="lecture-'+str(lid)+'"><h2>'+bi('第'+str(lid)+'讲','Lecture '+str(lid))+'</h2></div>','html.parser')
        intro=copy.deepcopy(pages[lid].select_one('.intro-copy'));opening.div.append(intro);holder.append(opening)
    for uid,u in sorted(units.items()):
        row=next(v for v in json.loads((R/'内容地图.json').read_text(encoding='utf8'))['units'] if v['id']==uid)
        if row['lecture']!=lid:continue
        holder.append(u)
        nav.append(BeautifulSoup('<a href="#u'+uid+'">'+''.join(str(x) for x in u.h2.contents)+'</a>','html.parser'))

terms={}
for page in [old,*pages.values()]:
    script=next(s.get_text() for s in page.find_all('script') if s.get_text().startswith('const TERMS='))
    if ';const TERM_NOTES=' in script:
        data=json.loads(script.split('const TERMS=')[1].split(';const TERM_NOTES=')[0]);notes=json.loads(script.split(';const TERM_NOTES=')[1].rstrip(';'))
        terms.update({k:[*v[:6],*notes.get(k,['',''])] for k,v in data.items()})
    else:terms.update(json.loads(script[len('const TERMS='):].rstrip(';')))
# Remap every term to the new location, including terms not used in any one chapter.
locations={'norm':'07','ball':'07','inner':'06','sup':'11','max':'11','dual':'10','support':'38','holder':'10','cs':'06','pd':'16','psd':'16','quad':'16','sqrt':'16','argmax':'10','ellipsoid':'16','polar':'29','conjugate':'41','spectral':'17','nuclear':'17','frobenius':'09','svd':'17','cone':'25','sign':'10','diag':'16','trace':'06','basis':'09'}
for k,uid in locations.items():
    if k in terms:terms[k][5]='u'+uid
script=next(s for s in mainpage.find_all('script') if s.get_text().startswith('const TERMS='));script.string='const TERMS='+json.dumps(terms,ensure_ascii=False)+';'
gloss=copy.deepcopy(pages[2].find(id='glossary'));tbody=gloss.tbody;tbody.clear()
for key,t in terms.items():tbody.append(BeautifulSoup('<tr><td><button class="term" data-term="'+key+'">'+html.escape(t[0])+'</button></td><td>'+html.escape(t[1])+'</td><td>'+html.escape(t[2])+p(t[3],t[4])+'<a href="#'+t[5]+'">'+bi('正文','Read')+'</a></td></tr>','html.parser'))
holder.append(gloss)
for ident in ['source-map']:
    source=copy.deepcopy(old.find(id=ident))
    for layer in source.select('.layer'):layer.unwrap()
    for label in source.select('.reading-level-label'):label.decompose()
    holder.append(source)
holder.append(BeautifulSoup('<section id="homework"><h2>'+bi('作业1 · 本轮阅读入口','Homework 1 · Reading entries')+'</h2><p><a href="hw1-route.html">'+bi('按所需工具连续阅读','Read the tools in sequence')+'</a> · <a href="hw1-coverage.md">'+bi('17项方法、例题、练习对应表','17-item method, example and exercise map')+'</a></p></section>','html.parser'))
nav.append(BeautifulSoup('<a href="#glossary">'+bi('名词对照表','Terminology')+'</a><a href="#homework">HW1</a><a href="#source-map">'+bi('来源地图','Source map')+'</a>','html.parser'))
holder.append(BeautifulSoup('<footer>'+bi('2026-10-16 · 阅读偏好保存在当前浏览器。','2026-10-16 · Preferences stay in this browser.')+' <a href="lecture-source.zip">'+bi('源文件包','Source archive')+'</a></footer>','html.parser'))
existing={n['id'] for n in mainpage.select('[id]')}
aliases=[]
for n in old.main.select('[id]'):
    if n['id'] not in existing and n['id']!='hw1-ready':aliases.append('<span class="anchor-alias" id="'+html.escape(n['id'],quote=True)+'"></span>');existing.add(n['id'])
if 'guide' not in existing:aliases.append('<span class="anchor-alias" id="guide"></span>')
holder.select_one('.hero').insert(0,BeautifulSoup(''.join(aliases),'html.parser'))
mainpage.title.string='凸优化 · 前五讲连续自学讲义'
brand=mainpage.select_one('.brand');brand.clear();brand.append(BeautifulSoup(bi('凸优化','Convex optimization')+'<small>'+bi('前五讲 · 完整讲义','Lectures 1–5 · Full text')+'</small>','html.parser'))
mainpage.select_one('.eyebrow').string='CONVEX OPTIMIZATION / LECTURES 01–05'
for n in mainpage.select('.math'):
    n['data-tex']=n['data-tex'].replace(r'\prime\prime',r'^{\prime\prime}').replace(r'\prime(',r'^{\prime}(')
style=mainpage.new_tag('style');style.string='.anchor-alias{display:block;height:0}.chapter-opening{padding-top:45px}.chapter-opening>h2{font-size:31px}.chapter-opening .intro-copy{border-left:2px solid var(--line);padding-left:22px}.original img{width:100%;height:auto}';mainpage.head.append(style)

# A union font covers the new prose from all chapters, including the retained introduction.
font_text=mainpage.get_text()+str(mainpage.nav)+json.dumps(terms,ensure_ascii=False)+(R/'chapter_reader.js').read_text(encoding='utf8')
chars=''.join(sorted(set(font_text)))
css=''
for weight in [400,700]:
    cache=R/('continuous-all-font-'+hashlib.sha256((str(weight)+chars).encode()).hexdigest()[:12]+'.woff2')
    if not cache.exists():
        font=instantiateVariableFont(TTFont(os.environ.get('CONVEX_CJK_FONT','C:/Windows/Fonts/NotoSerifSC-VF.ttf')),{'wght':weight},inplace=True);opts=subset.Options();sub=subset.Subsetter(options=opts);sub.populate(text=chars);sub.subset(font);font.flavor='woff2';font.save(cache)
    css+='@font-face{font-family:ChapterSerif;src:url(data:font/woff2;base64,'+base64.b64encode(cache.read_bytes()).decode()+');font-weight:'+str(weight)+';font-display:swap}'
fontstyle=mainpage.new_tag('style');fontstyle.string=css;mainpage.head.append(fontstyle)
(OUT/'index.html').write_text(str(mainpage),encoding='utf8')

# The homework route reuses the same unit DOM, including complete proofs and exercises.
route=copy.deepcopy(mainpage);rh=route.select_one('.reading-width')
for section in list(rh.select('section[id^="u"]')):section.extract()
for opening in list(rh.select('.chapter-opening')):opening.decompose()
intro=rh.find('div',class_='hero');intro.h1.clear();intro.h1.append(BeautifulSoup(bi('HW1 · 连续阅读路线','HW1 · A continuous reading route'),'html.parser'))
stages=[('证明、向量与长度','Proofs, vectors and length',['06','07','11','08']),('矩阵放大与对偶范数','Matrix amplification and dual norms',['09','10','15','16']),('一阶与二阶变化','First- and second-order changes',['12','13','14']),('凸集的定义证明','Convex set proofs',['19','20','21']),('凸函数与Jensen','Convex functions and Jensen',['31','32','33','36']),('锥与自对偶','Cones and self-duality',['25','29','30'])]
insert=BeautifulSoup('<div id="route-content"></div>','html.parser').div;intro.insert_after(insert);used=set()
for i,(z,e,ids) in enumerate(stages,1):
    insert.append(BeautifulSoup('<div class="chapter-opening"><h2>'+bi(str(i)+' · '+z,str(i)+' · '+e)+'</h2></div>','html.parser'))
    for uid in ids:
        if uid=='16':insert.append(BeautifulSoup('<div class="route-tool-note">'+p('阅读路线提示：下面用到对称矩阵P的二次型。对每个v都有vᵀPv≥0称半正定；对每个非零v都有vᵀPv>0称正定。正文节号仍按课件章节保留；本路线将Hessian放在下一阶段介绍。','Route note: for a symmetric P, positive semidefinite means vᵀPv≥0 for every v; positive definite means strict positivity for every nonzero v. Section numbers retain the ordinary chapter order; this route introduces Hessians in the following stage.')+'</div>','html.parser'))
        insert.append(copy.deepcopy(mainpage.find(id='u'+uid)));used.add(uid)
insert.append(BeautifulSoup('<div id="hw1-ready" class="chapter-opening"><h2>'+bi('主要作业工具已读完','The main HW1 tools are now covered')+'</h2>'+p('到这里，作业1所需的范数、导数、集合、凸函数与二阶锥工具均已出现。请合上例题，独立写对应练习，再回到原题检验。以下继续保留其他课件内容，便于完整学习。','The required norm, derivative, set, convex-function and second-order-cone tools have appeared. Close the worked examples and attempt the related exercises independently before returning to the homework. Remaining lecture material follows for further study.')+'</div>','html.parser'))
for uid in sorted(units):
    if uid not in used:insert.append(copy.deepcopy(mainpage.find(id='u'+uid)))
# Preserve old lecture links without pretending that this route follows slide order.
for lid in range(1,6):
    target=next(row['id'] for row in json.loads((R/'内容地图.json').read_text(encoding='utf8'))['units'] if row['lecture']==lid)
    route.find(id='u'+target).insert(0,BeautifulSoup('<span class="anchor-alias" id="lecture-'+str(lid)+'"></span>','html.parser'))
route.title.string='凸优化 · HW1连续阅读路线'
rnav=route.nav;rnav.clear()
for u in route.select('section[id^="u"]'):
    rnav.append(BeautifulSoup('<a href="#'+u['id']+'">'+''.join(str(n) for n in u.h2.contents)+'</a>','html.parser'))
rnav.append(BeautifulSoup('<a href="#glossary">'+bi('名词对照表','Terminology')+'</a><a href="#homework">HW1</a><a href="#source-map">'+bi('来源地图','Source map')+'</a>','html.parser'))
(OUT/'hw1-route.html').write_text(str(route),encoding='utf8')
print('Assembled:',len(units),'units,',len(terms),'terms; full handbook and HW1 route')
