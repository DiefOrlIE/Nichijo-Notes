# 连续版本重建

原始教材/课件PDF不包含在包内。保留现有完整讲义/pages目录，或先用既有build_course.py从本地课件导出原图。

依赖Python、beautifulsoup4、numpy、matplotlib、fonttools[woff]、PyMuPDF；测试另需Playwright、SymPy、Chrome。CONVEX_CJK_FONT可指定中文字体，CONVEX_KATEX_DIST可指定KaTeX dist；包内vendor/katex作为默认可移植资源。

依次运行build_continuous_chapters.py --chapter 2（再分别为3、4、5），最后运行assemble_continuous_handbook.py。完整讲义默认生成在完整讲义/。结构重写前来源快照.html仅供抽取原图与原锚点，不是当前正文。

review_continuous_html.py仅在主动调用时访问DeepSeek，密钥从环境变量读取，包内无密钥。第三方审稿目录保留已发生的审读。
