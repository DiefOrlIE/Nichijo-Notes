# 构建与维护

双语新增正文在 refinement_content.py，组装和路线在 task_revision.py，原有精简稿在精简重写/content.json。修改生成源后运行 build_course.py，勿只修改生成HTML。

Python依赖：beautifulsoup4、fonttools[woff]、brotli、PyMuPDF、numpy、matplotlib；验证另需sympy与playwright（Chrome）。KaTeX运行资源已随包提供vendor/katex。中文字体默认使用Windows的NotoSerifSC-VF.ttf，可通过CONVEX_CJK_FONT指定同款变量字体路径。

将CONVEX_MATERIALS设为Lecture_1.pdf至Lecture_5.pdf所在目录，运行python build_course.py。输出完整讲义/index.html和hw1-route.html；来源图片首次从课件渲染。如果完整讲义/pages已有完整280张图片，可以不提供原PDF。教材和HW1仅用于编辑核对，验证脚本默认在源目录上两层寻找材料，可按实际位置调整WORK。

python verify_task_revision.py验证数学例子、来源和两个页面；原界面/键盘验证分别见相应脚本。验收记录写入输出目录。write_revision_delivery.py整理交付文档及本源包，需保留本轮原始材料、验证JSON和字体/KaTeX输入。

本包不含教材和原课件PDF，也不含GitHub凭据或上传脚本。仅修改文字可在原工作区重建，或配置上述材料目录后重建。
