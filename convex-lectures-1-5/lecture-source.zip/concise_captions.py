CAPTIONS={}
ROWS='''
least-squares|左：观测编号与读数，红线预测为 3，竖线为偏差。右：候选 x 与平方和 F(x)，最低点 (3,14)。|Left: readings versus observation index, with prediction 3 and vertical discrepancies. Right: score F versus candidate x, minimized at (3,14).
model|阴影为营养约束下的非负可行区。费用虚线向降低方向移动，最后接触红点 (2,0)，费用为 6。|Shading is the nonnegative nutrition-feasible region. Lowering dashed cost levels gives final contact (2,0), costing 6.
projection|蓝线为列空间，观测 b=(1,2) 投影到 p=(1,0)，红色残差与蓝线正交。此图使用独立二维数据。|Blue is the column space; b=(1,2) projects to p=(1,0) with perpendicular red residual. This uses a separate two-dimensional example.
lp|红色上包络 max(2x+1,−x+4) 在 (1,3) 最低，向两侧移动都会升高。|The red envelope max(2x+1,−x+4) is minimized at (1,3) and rises in either direction.
convex|x² 在 −1、3 间的红弦高于曲线；中点 1 处，两高度为 5、1。|The red chord of x² between −1 and 3 lies above the curve; at midpoint 1 their heights are 5 and 1.
nonconvex|曲线 (x²−1)² 的三个标记点均驻定；红点 ±1 全局极小，灰点 0 局部极大。|All marked points of (x²−1)² are stationary. Red ±1 are global minima; gray 0 is a local maximum.
inner|蓝向量 (3,4) 沿绿色单位方向 (1,0) 的红色投影长度为 3。|The blue vector (3,4) has red projection length 3 along green unit direction (1,0).
balls|依次为 ℓ₁、ℓ₂、ℓ∞ 单位球，轴比例相同。沿 (1,1) 比较边界距离，即可比较预算。|The ℓ₁,ℓ₂,ℓ∞ unit balls share axis scales. Compare boundary distances along (1,1) to compare budgets.
ellipse|此图用 diag(3,2) 将蓝色单位圆映为红椭圆，两轴放大 3、2 倍；其他矩阵须另算。|This uses diag(3,2), mapping the blue unit circle to a red ellipse with radii 3,2. Other matrices require separate calculation.
topology|区间 (0,1] 左空右实。绿色邻域留在区间内，红色邻域超出，说明边界点可属于集合而非内点。|The interval (0,1] excludes its left endpoint. Green stays inside; red extends outside, distinguishing boundary membership from interior.
tangent|蓝线 x² 与红切线 2x−1 的差为 (x−1)²≥0，接触点外严格为正。|The gap between blue x² and red tangent 2x−1 is (x−1)²≥0, positive away from contact.
affine|蓝点的仿射包是整条黑线 x₁+x₂=1，凸包只有红色线段；原点不在线上。|The blue points' affine hull is the full black line x₁+x₂=1; their convex hull is the red segment. Zero is off the line.
hull|阴影为三点的凸包。红点 (1/2,1/2) 使用权重 (1/2,1/4,1/4)。|Shading is the three-point convex hull. Red (1/2,1/2) uses weights (1/2,1/4,1/4).
halfspace|蓝线 x₁=1 平分 a=(0,0)、b=(2,0)；左侧阴影中点离 a 不比离 b 远。|Blue x₁=1 bisects a=(0,0),b=(2,0). Shaded points on the left are no farther from a.
intersection|深色重叠区同时满足圆盘与 x₁≤1/2，红色线段仍留在交集中。|The darker overlap satisfies both the disk and x₁≤1/2; the red joining segment remains inside.
perspective|横轴 z、纵轴 t。输入中点 (1,1.5) 沿射线投到 t=1 的 2/3，显示混合权重改变。|Horizontal z and vertical t: midpoint (1,1.5) projects along its ray to 2/3 at t=1, changing mixture weights.
soc|横轴 x、纵轴预算 t，阴影 |x|≤t；绿点 (0,1) 在内部，原点为锥顶。这是高维锥的二维截面。|Horizontal x, vertical budget t: shading satisfies absolute x≤t. Green (0,1) is interior and zero the vertex; this is a 2D section.
pareto|费用、误差均越小越好。蓝点互不支配，红点 (3,3) 被 (2,2) 支配；连线不表示中间方案可行。|Both cost and error prefer smaller values. Blue points are incomparable; (2,2) dominates red (3,3). Lines do not assert intermediate feasibility.
separation|红线 x₁=0 严格分离两个半径 1 的圆盘，各侧间隙为 1；一般弱分离不保证这种间隙。|Red x₁=0 strictly separates the radius-one disks with unit gaps; weak separation need not give a gap.
support|红线 x₁=1 在 (1,0) 支撑蓝圆盘，绿色为法向；圆盘全部留在线左侧。|Red x₁=1 supports the blue disk at (1,0), with green normal. The entire disk stays left.
dualcone|锥内绿点 (−1,1) 与锥外红点 (2,1) 内积为 −1，证明红点不在对偶锥。|Green cone point (−1,1) pairs with exterior red (2,1) to give −1, excluding the red point from the dual cone.
chord|红弦连接 x² 上的 −1、3；输入均值 1 的函数值 1，低于输出均值 5。|The red chord joins x² at −1 and 3. Mean input 1 gives value 1, below mean output 5.
epigraph|浅色为上图集 t≥x²；连接两图像点的红弦仍在区域内。|Shading is the epigraph t≥x²; the red chord between graph points stays inside.
jensen|输入 1、3 的均值为 2，平方为 4；平方均值为 5。绿色间隙 1 就是方差。|Inputs 1,3 have mean 2 and squared mean 4; their mean square is 5. The green gap 1 is variance.
max|红色上包络在 x=1 切换主导项，形成尖角，仍保持凸性。|The red upper envelope switches active terms at x=1, creating a corner while remaining convex.
perspective-function|蓝、红曲线分别为 t=1、2 的 x²/t。截面展示费用下降，联合凸性还需同时混合 x、t。|Blue and red show x²/t at t=1,2. Sections illustrate lower cost; joint convexity must mix both x and t.
conjugate|蓝线 x²/2 的斜率 2 支撑线为 2x−2，接触 (2,2)；截距 −2 对应共轭值 2。|The slope-2 support of blue x²/2 is 2x−2, touching at (2,2). Intercept −2 corresponds to conjugate value 2.
logconcave|左为高斯形状 exp(−x²/2)，右为其凹对数 −x²/2；原函数尾部仍可非凹。|Left is exp(−x²/2), right its concave logarithm −x²/2. The original tails need not be concave.
'''
for row in ROWS.strip().splitlines():
    key,z,e=row.split('|',2) if not row.startswith('soc|') else ('soc',*row[4:].rsplit('|',1))
    CAPTIONS[key]=(z,e)
